import { fetchModelApiJson, modelApiUrl } from '../lib/model-api.js';

export default async function handler(request, response) {
  if (request.method !== 'POST') {
    response.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const payload = request.body || {};
  const upstream = modelApiUrl('/predict');

  if (upstream) {
    try {
      const result = await fetchModelApiJson('/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      response.status(result.status).json(result.data);
    } catch (error) {
      response.status(502).json({
        error: `No se pudo conectar con el backend del modelo. Revisa MODEL_API_URL y /health. Detalle: ${error.message}`,
      });
    }
    return;
  }

  const momentum = Number(payload.ret_7d || 0);
  const volatility = Number(payload.volatility_30d || 0);
  const arbitrageReturn = Number(payload.arbitrage_return || 0);
  const sales = Number(payload.sales || 0);
  const liquidityPenalty = sales < 5 ? 0.18 : sales < 20 ? 0.06 : 0;
  const down = Math.max(
    0.02,
    Math.min(0.98, 0.32 - momentum * 2.4 + volatility * 3.2 + liquidityPenalty),
  );
  const up = Math.max(0.02, Math.min(0.98, 0.48 + momentum * 3.2 - volatility * 1.6));
  const hold = Math.max(0, 1 - down - up);
  const total = down + hold + up;
  const probabilities = {
    down: down / total,
    hold: hold / total,
    up: up / total,
  };
  const expectedReturn = (probabilities.up - probabilities.down) * 0.07;
  const decision =
    probabilities.down >= 0.75
      ? 'reject'
      : arbitrageReturn > 0 && probabilities.up >= 0.6
        ? 'buy'
        : 'review';
  const confidence = Math.max(
    0.35,
    Math.min(0.94, decision === 'buy' ? probabilities.up : decision === 'reject' ? probabilities.down : probabilities.hold),
  );

  response.status(200).json({
    decision,
    direction: decision === 'buy' ? 'up' : decision === 'reject' ? 'down' : 'hold',
    confidence,
    expected_return: expectedReturn,
    arbitrage_return: arbitrageReturn,
    down_risk: probabilities.down,
    expected_price_cents: Math.round(Number(payload.steam_price_cents || payload.price_cents || 0) * (1 + expectedReturn)),
    probabilities,
    reason: upstream
      ? 'Prediccion servida por el modelo remoto.'
      : 'Recomendacion demo basada en probabilidad de subida a 7 dias, margen, volatilidad y liquidez. Define MODEL_API_URL para usar el modelo real.',
  });
}
