import { MODEL_API_TIMEOUT_MS, fetchModelApiJson, modelApiUrl } from '../lib/model-api.js';

function authorized(request) {
  if (!process.env.CRON_SECRET) return true;
  const header = request.headers.authorization || request.headers.Authorization;
  return header === `Bearer ${process.env.CRON_SECRET}`;
}

export default async function handler(request, response) {
  if (request.method !== 'GET') {
    response.status(405).json({ error: 'Method not allowed' });
    return;
  }

  if (!authorized(request)) {
    response.status(401).json({ error: 'Unauthorized' });
    return;
  }

  const startedAt = Date.now();
  if (!modelApiUrl('/health')) {
    response.status(200).json({
      ok: false,
      mode: 'demo',
      message: 'MODEL_API_URL no esta configurada; no hay backend remoto que mantener activo.',
    });
    return;
  }

  try {
    const result = await fetchModelApiJson('/health', {}, MODEL_API_TIMEOUT_MS);
    response.status(result.ok ? 200 : 502).json({
      ok: result.ok,
      upstream_status: result.status,
      elapsed_ms: Date.now() - startedAt,
      health: result.data,
    });
  } catch (error) {
    response.status(502).json({
      ok: false,
      elapsed_ms: Date.now() - startedAt,
      error: `Keepalive no pudo llamar a /health: ${error.message}`,
    });
  }
}
