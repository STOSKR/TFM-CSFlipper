import { MODEL_API_TIMEOUT_MS, fetchModelApiJson, modelApiUrl } from '../lib/model-api.js';

export default async function handler(request, response) {
  if (request.method !== 'GET') {
    response.status(405).json({ error: 'Method not allowed' });
    return;
  }

  if (!modelApiUrl('/health')) {
    response.status(200).json({
      ok: false,
      mode: 'demo',
      configured: false,
      message: 'MODEL_API_URL no esta configurada. La web usara respuestas demo hasta conectar el backend del modelo.',
    });
    return;
  }

  try {
    const result = await fetchModelApiJson('/health', {}, MODEL_API_TIMEOUT_MS);
    response.status(200).json({
      ...result.data,
      ok: result.ok && result.data?.ok !== false,
      mode: result.ok ? 'remote' : 'offline',
      configured: true,
      upstream_status: result.status,
      message: result.ok
        ? 'Backend del modelo disponible.'
        : 'El backend remoto respondio, pero el healthcheck no fue correcto.',
    });
  } catch (error) {
    response.status(200).json({
      ok: false,
      mode: 'offline',
      configured: true,
      message: `No se pudo comprobar /health del backend del modelo: ${error.message}`,
    });
  }
}
