import { fetchModelApiJson, modelApiUrl } from '../lib/model-api.js';

function demoItems(limit, sort = 'hybrid') {
  const base = [
    ['smg_mac_10_classic_crate', 'MAC-10 | Classic Crate', 'mac_10', 'WW', 0, 173, 23, 0.66, 0.341],
    ['smg_mac_10_carnivore', 'MAC-10 | Carnivore', 'mac_10', 'BS', 0, 230, 7, 0.635, 0.648],
    ['shotgun_mag_7_magnitude', 'MAG-7 | MAGnitude', 'mag_7', 'WW', 1, 221, 16, 0.613, 0.131],
    ['sniper_awp_acheron', 'AWP | Acheron', 'awp', 'BS', 0, 493, 219, 0.611, 0.089],
    ['rifle_aug_trigger_discipline', 'AUG | Trigger Discipline', 'aug', 'WW', 0, 102, 169, 0.606, 0.029],
    ['rifle_famas_halftone_wash', 'FAMAS | Halftone Wash', 'famas', 'WW', 0, 200, 5, 0.613, 0.13],
    ['heavy_m249_hypnosis', 'M249 | Hypnosis', 'm249', 'MW', 0, 402, 39, 0.619, 0.037],
    ['rifle_ak_47_safari_mesh', 'AK-47 | Safari Mesh', 'ak_47', 'MW', 0, 242, 16, 0.479, -0.062],
    ['smg_mac_10_acid_hex', 'MAC-10 | Acid Hex', 'mac_10', 'MW', 0, 120, 35, 0.571, -0.008],
    ['heavy_m249_bock_blocks', 'M249 | Bock Blocks', 'm249', 'FT', 0, 271, 6, 0.387, 0.102],
  ];
  return base.map((row) => {
    const pctUp = Number(row[8]);
    const probUp = Number(row[7]);
    return {
      variant_id: `${row[0]}__${row[3]}_st${row[4]}`,
      item_key: row[0],
      skin_name: row[1],
      weapon_key: row[2],
      wear: row[3],
      st: row[4],
      price_cents: row[5],
      sales: row[6],
      prob_up: probUp,
      pct_up: pctUp,
      pct_up_source: 'realized_forward',
      score: probUp * Math.max(0, pctUp),
    };
  }).sort((a, b) => {
    if (sort === 'probability') return b.prob_up - a.prob_up;
    if (sort === 'pct_up') return b.pct_up - a.pct_up;
    return b.score - a.score || b.prob_up - a.prob_up;
  }).slice(0, Math.max(10, Number(limit || 10)));
}

function demoResponse(request, message = '') {
  return {
    date: request.query?.date || 'demo',
    horizon_days: Number(request.query?.horizon_days || 7),
    sort_by: request.query?.sort || 'hybrid',
    limit: Number(request.query?.limit || 10),
    total_candidates: 10,
    model_id: 'demo-fallback',
    mode: 'demo',
    message,
    items: demoItems(request.query?.limit, request.query?.sort),
  };
}

export default async function handler(request, response) {
  if (request.method !== 'GET') {
    response.status(405).json({ error: 'Method not allowed' });
    return;
  }

  const upstream = modelApiUrl('/recommendations');
  const query = request.url.includes('?') ? request.url.slice(request.url.indexOf('?')) : '';
  const remoteRecommendationsEnabled = process.env.ENABLE_REMOTE_RECOMMENDATIONS === '1';

  if (upstream && remoteRecommendationsEnabled) {
    try {
      const result = await fetchModelApiJson(`/recommendations${query}`);
      if (!result.ok) {
        response.status(200).json(demoResponse(request, `Backend remoto no disponible para calendario (HTTP ${result.status}).`));
        return;
      }
      response.status(result.status).json(result.data);
    } catch (error) {
      response.status(200).json(demoResponse(request, `Backend remoto no disponible para calendario. Detalle: ${error.message}`));
    }
    return;
  }

  response.status(200).json(
    demoResponse(
      request,
      upstream
        ? 'Calendario remoto desactivado para evitar saturar el backend; usando oportunidades demo.'
        : '',
    ),
  );
}
