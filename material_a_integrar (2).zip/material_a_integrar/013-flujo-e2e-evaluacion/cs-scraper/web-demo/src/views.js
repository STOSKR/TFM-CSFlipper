import { buildFeatures, chartPoints, historySummary } from './history.js';
import { DEMO_MARKETS } from './demo-data.js';

function money(cents) {
  return new Intl.NumberFormat('es-ES', {
    style: 'currency',
    currency: 'EUR',
  }).format(Number(cents || 0) / 100);
}

function pct(value) {
  return `${(Number(value || 0) * 100).toFixed(2)}%`;
}

function signedPct(value) {
  const number = Number(value || 0);
  const sign = number > 0 ? '+' : '';
  return `${sign}${pct(number)}`;
}

function euroInputValue(cents) {
  return (Number(cents || 0) / 100).toFixed(2);
}

function metric(label, value, tone = '', meta = '') {
  return `
    <div class="metric ${tone}">
      <span>${label}</span>
      <strong>${value}</strong>
      ${meta ? `<small>${meta}</small>` : ''}
    </div>
  `;
}

function chart(rows) {
  if (rows.length < 2) {
    return '<div class="empty compact">Necesitas al menos dos puntos historicos.</div>';
  }

  const width = 760;
  const height = 280;
  const pad = 24;
  const { points, minPrice, maxPrice } = chartPoints(rows, width, height, pad);
  const lastPoint = points.split(' ').at(-1).split(',');
  const areaPoints = `${points} ${width - pad},${height - pad} ${pad},${height - pad}`;

  return `
    <svg class="chart" viewBox="0 0 ${width} ${height}" role="img" aria-label="Historico de precio">
      <defs>
        <linearGradient id="area-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="var(--primary-btn)" stop-opacity="0.3" />
          <stop offset="100%" stop-color="var(--primary-btn)" stop-opacity="0.0" />
        </linearGradient>
      </defs>
      <g class="chart-grid">
        <line x1="${pad}" y1="${pad}" x2="${width - pad}" y2="${pad}" />
        <line x1="${pad}" y1="${height / 2}" x2="${width - pad}" y2="${height / 2}" />
        <line x1="${pad}" y1="${height - pad}" x2="${width - pad}" y2="${height - pad}" />
      </g>
      <polygon points="${areaPoints}" fill="url(#area-grad)" />
      <polyline class="curve" points="${points}" />
      <circle class="last-point" cx="${lastPoint[0]}" cy="${lastPoint[1]}" r="4" />
      <text x="${pad}" y="14">${money(maxPrice)}</text>
      <text x="${pad}" y="${height - 8}">${money(minPrice)}</text>
      <text x="${width - 90}" y="${height - 8}">${rows.at(-1).day}</text>
    </svg>
  `;
}

function decisionClass(decision) {
  if (decision === 'buy') return 'up';
  if (decision === 'reject') return 'down';
  return 'hold';
}

function renderProbabilities(probabilities) {
  if (!probabilities) return '';

  const labels = {
    buy: 'Subida',
    reject: 'Bajada',
    hold: 'Lateral',
  };

  return `
    <div class="probabilities" aria-label="Probabilidades por clase">
      ${['buy', 'reject', 'hold']
        .map((label) => {
          const key = label === 'buy' ? 'up' : label === 'reject' ? 'down' : 'hold';
          const value = Number(probabilities[key] || 0);
          return `
            <div>
              <span>${labels[label]}</span>
              <strong>${pct(value)}</strong>
              <meter min="0" max="1" value="${value}">${pct(value)}</meter>
            </div>
          `;
        })
        .join('')}
    </div>
  `;
}

function renderResult(result) {
  if (!result) {
    return `
      <section class="workspace-panel signal-panel neutral">
        <div>
          <span class="eyebrow">Oportunidad sin evaluar</span>
          <h2>Aun no hay decision</h2>
          <p>Introduce precios y estado del item para estimar margen neto, momentum y riesgo antes de comprar.</p>
        </div>
      </section>
    `;
  }

  if (result.error) {
    return `<section class="workspace-panel signal-panel down"><div class="empty compact error-box">${result.error}</div></section>`;
  }

  const label = {
    buy: 'Comprar',
    reject: 'No comprar',
    review: 'Revisar manualmente',
  }[result.decision] || 'Revisar manualmente';

  const detail = {
    buy: 'El modelo ve subida probable a 7 dias y el margen neto es positivo.',
    reject: 'El modelo ve demasiado riesgo de bajada a 7 dias.',
    review: 'Hay senales mixtas; revisa precio, liquidez e historico antes de operar.',
  }[result.decision] || 'Hay senales mixtas; revisa precio, liquidez e historico antes de operar.';
  const margin = Number(result.arbitrage_return ?? result.expected_return ?? 0);

  return `
    <section class="workspace-panel signal-panel ${decisionClass(result.decision)}">
      <div class="signal-copy">
        <span class="eyebrow">Resultado del modelo</span>
        <h2>${label}</h2>
        <p>${detail}</p>
      </div>
      <div class="signal-metrics">
        ${metric('Confianza', pct(result.confidence))}
        ${metric('Prediccion 7d', signedPct(result.expected_return), Number(result.expected_return || 0) >= 0 ? 'up' : 'down')}
        ${metric('Margen neto', signedPct(margin), margin >= 0 ? 'up' : 'down')}
      </div>
      ${renderProbabilities(result.probabilities)}
    </section>
  `;
}

export function renderDashboard(rows, state) {
  const summary = historySummary(rows);
  const features = buildFeatures(rows, state);
  const momentumTone = features.ret_7d >= 0 ? 'up' : 'down';
  const marginTone = features.arbitrage_return >= 0 ? 'up' : 'down';
  const currentName = (state.skin_name || state.item_key.replace(/_/g, ' ')).toUpperCase();

  return `
    <div class="terminal-grid">
      <aside class="workspace-panel control-panel">
        <div class="panel-head">
          <div>
            <span class="eyebrow">Simulador</span>
            <h2>Datos de la oportunidad</h2>
          </div>
        </div>
        <form id="predict-form" class="control-form">
          <label>
            Mercado de ejemplo
            <select id="demo-market" name="demo_market">
              ${DEMO_MARKETS.map((market) => `<option value="${market.id}" ${market.id === state.activeDemoId ? 'selected' : ''}>${market.label}</option>`).join('')}
            </select>
          </label>
          <label>
            Identificador del item
            <input name="item_key" value="${state.item_key}" />
          </label>
          <div class="grid">
            <label>
              Estado del item
              <select name="wear">
                ${['FN', 'MW', 'FT', 'WW', 'BS'].map((wear) => `<option ${wear === state.wear ? 'selected' : ''}>${wear}</option>`).join('')}
              </select>
            </label>
            <label class="toggle-field">
              <span>StatTrak</span>
              <span class="toggle-control">
                <input name="stattrak" type="checkbox" ${state.stattrak ? 'checked' : ''} />
                <span class="toggle-track"><span></span></span>
              </span>
            </label>
          </div>
          <div class="grid">
            <label>
              Precio compra externo (€)
              <input name="external_price_eur" type="number" min="0.01" step="0.01" value="${euroInputValue(state.external_price_cents)}" />
            </label>
            <label>
              Precio venta Steam (€)
              <input name="steam_price_eur" type="number" min="0.01" step="0.01" value="${euroInputValue(state.steam_price_cents)}" />
            </label>
          </div>
          <label>
            Comision de Steam (0.13 = 13%)
            <input name="fee_pct" type="number" min="0" max="1" step="0.01" value="${state.fee_pct}" />
          </label>
          <button type="submit">Evaluar oportunidad</button>
        </form>
        <div class="demo-source">
          <span>Historial usado</span>
          <strong>${state.source_path || 'Historial manual'}</strong>
        </div>
        <details class="history-config">
          <summary>Editar historial de precios</summary>
          <textarea id="history-input" rows="8">${state.history}</textarea>
          <button id="refresh-history" type="button">Aplicar historial</button>
        </details>
      </aside>

      <section class="workspace-main">
        ${renderResult(state.result)}
        <section class="workspace-panel market-panel">
          <div class="panel-head">
            <div>
              <span class="eyebrow">Resumen del mercado</span>
              <h2>${currentName}</h2>
            </div>
            <div class="market-meta">
              <span>${rows.length} puntos</span>
              <strong>${rows.at(-1)?.day || 'Sin fecha'}</strong>
            </div>
          </div>
          <div class="metrics">
            ${metric('Ultimo precio Steam', money(summary.current), '', 'Historico')}
            ${metric('Variacion total', signedPct(summary.totalReturn))}
            ${metric('Cambio 7 dias', signedPct(features.ret_7d), momentumTone)}
            ${metric('Volatilidad 30 dias', pct(features.volatility_30d))}
            ${metric('Margen neto estimado', signedPct(features.arbitrage_return), marginTone)}
          </div>
          ${chart(rows)}
        </section>

        <section class="workspace-panel feature-panel">
          <div class="panel-head">
            <div>
              <span class="eyebrow">Senales tecnicas</span>
              <h2>Indicadores usados por el modelo</h2>
            </div>
          </div>
          <div class="feature-grid">
            ${metric('RSI 14D', features.rsi_14d.toFixed(1))}
            ${metric('Precio vs MA7', signedPct(features.price_vs_ma_7d), features.price_vs_ma_7d >= 0 ? 'up' : 'down')}
            ${metric('Precio vs MA30', signedPct(features.price_vs_ma_30d), features.price_vs_ma_30d >= 0 ? 'up' : 'down')}
            ${metric('Ventas 7D z-score', features.sales_z_7d.toFixed(2), features.sales_z_7d >= 0 ? 'up' : 'down')}
          </div>
        </section>
      </section>
    </div>
  `;
}
