export const DEMO_MARKETS = [
  {
    id: 'ak-redline-ft',
    label: 'AK-47 Redline FT',
    item_key: 'rifle_ak_47_redline',
    skin_name: 'AK-47 | Redline',
    wear: 'FT',
    stattrak: false,
    external_price_cents: 23188,
    steam_price_cents: 32504,
    fee_pct: 0.13,
    source_path: 'notebooks/data/rifle/ak/rifle_ak_47_redline.json',
    history: `2026-03-10,341.84,70
2026-03-11,344.09,93
2026-03-12,357.85,124
2026-03-13,342.84,115
2026-03-14,344.28,131
2026-03-15,342.63,124
2026-03-16,335.18,110
2026-03-17,332.55,111
2026-03-18,331.05,124
2026-03-19,334.02,134
2026-03-20,318.45,153
2026-03-21,316.71,137
2026-03-22,314.35,133
2026-03-23,312.52,156
2026-03-24,314.17,100
2026-03-25,310.80,122
2026-03-26,308.75,103
2026-03-27,320.30,108
2026-03-28,307.93,124
2026-03-29,310.72,113
2026-03-30,327.05,98
2026-03-31,314.23,109
2026-04-01,328.99,112
2026-04-02,316.15,120
2026-04-03,327.03,126
2026-04-04,322.75,108
2026-04-05,331.22,94
2026-04-06,318.24,95
2026-04-07,314.24,85
2026-04-08,325.04,28`,
  },
  {
    id: 'ak-slate-mw',
    label: 'AK-47 Slate MW',
    item_key: 'rifle_ak_47_slate',
    skin_name: 'AK-47 | Slate',
    wear: 'MW',
    stattrak: false,
    external_price_cents: 6055,
    steam_price_cents: 7648,
    fee_pct: 0.13,
    source_path: 'notebooks/data/rifle/ak/rifle_ak_47_slate.json',
    history: `2026-03-10,75.08,273
2026-03-11,73.68,273
2026-03-12,77.30,495
2026-03-13,82.52,477
2026-03-14,85.27,535
2026-03-15,84.69,492
2026-03-16,87.16,400
2026-03-17,83.44,366
2026-03-18,83.24,409
2026-03-19,80.91,474
2026-03-20,75.79,551
2026-03-21,74.60,532
2026-03-22,73.99,514
2026-03-23,74.47,436
2026-03-24,72.61,425
2026-03-25,71.68,464
2026-03-26,72.66,415
2026-03-27,73.18,442
2026-03-28,76.36,469
2026-03-29,75.19,450
2026-03-30,75.14,368
2026-03-31,76.84,304
2026-04-01,76.22,380
2026-04-02,75.43,395
2026-04-03,78.03,410
2026-04-04,79.32,363
2026-04-05,79.33,405
2026-04-06,77.46,399
2026-04-07,75.46,336
2026-04-08,76.48,103`,
  },
  {
    id: 'deagle-code-red-ft',
    label: 'Desert Eagle Code Red FT',
    item_key: 'pistol_desert_eagle_code_red',
    skin_name: 'Desert Eagle | Code Red',
    wear: 'FT',
    stattrak: false,
    external_price_cents: 36918,
    steam_price_cents: 44203,
    fee_pct: 0.13,
    source_path: 'notebooks/data/pistol/desert/pistol_desert_eagle_code_red.json',
    history: `2026-03-10,447.39,21
2026-03-11,442.02,12
2026-03-12,442.79,21
2026-03-13,431.28,21
2026-03-14,441.16,28
2026-03-15,451.47,21
2026-03-16,432.52,21
2026-03-17,436.92,18
2026-03-18,445.75,21
2026-03-19,452.08,38
2026-03-20,436.73,13
2026-03-21,443.55,20
2026-03-22,430.88,28
2026-03-23,428.60,18
2026-03-24,416.14,20
2026-03-25,436.43,19
2026-03-26,419.61,12
2026-03-27,402.68,29
2026-03-28,427.77,38
2026-03-29,431.66,29
2026-03-30,435.47,20
2026-03-31,453.13,20
2026-04-01,453.45,18
2026-04-02,435.78,18
2026-04-03,422.22,18
2026-04-04,428.64,26
2026-04-05,447.92,17
2026-04-06,446.58,18
2026-04-07,434.97,21
2026-04-08,442.03,5`,
  },
  {
    id: 'mac10-classic-crate-ww',
    label: 'MAC-10 Classic Crate WW',
    item_key: 'smg_mac_10_classic_crate',
    skin_name: 'MAC-10 | Classic Crate',
    wear: 'WW',
    stattrak: false,
    external_price_cents: 132,
    steam_price_cents: 173,
    fee_pct: 0.13,
    source_path: 'data/prices/items/smg/mac/smg_mac_10_classic_crate.json',
    history: `2025-12-03,1.64,7
2025-12-04,1.97,25
2025-12-05,2.09,17
2025-12-06,1.56,13
2025-12-07,1.96,53
2025-12-08,1.84,16
2025-12-09,1.66,12
2025-12-10,1.93,31
2025-12-11,2.07,45
2025-12-12,2.01,18
2025-12-13,1.94,47
2025-12-14,1.95,28
2025-12-15,2.07,30
2025-12-16,1.97,13
2025-12-17,1.91,35
2025-12-18,1.91,41
2025-12-19,1.84,23
2025-12-20,1.65,28
2025-12-21,1.78,18
2025-12-22,2.11,53
2025-12-23,2.05,33
2025-12-24,1.84,15
2025-12-25,1.91,16
2025-12-26,1.86,17
2025-12-27,1.85,47
2025-12-28,1.80,22
2025-12-29,1.86,48
2025-12-30,1.79,23
2025-12-31,1.77,23
2026-01-01,1.73,23`,
  },
  {
    id: 'mac10-carnivore-bs',
    label: 'MAC-10 Carnivore BS',
    item_key: 'smg_mac_10_carnivore',
    skin_name: 'MAC-10 | Carnivore',
    wear: 'BS',
    stattrak: false,
    external_price_cents: 175,
    steam_price_cents: 230,
    fee_pct: 0.13,
    source_path: 'data/prices/items/smg/mac/smg_mac_10_carnivore.json',
    history: `2025-12-06,2.50,35
2025-12-07,2.65,12
2025-12-08,3.10,29
2025-12-09,4.13,5
2025-12-10,3.15,26
2025-12-11,2.57,55
2025-12-12,2.69,10
2025-12-13,2.60,46
2025-12-14,2.48,7
2025-12-15,2.54,9
2025-12-16,2.52,41
2025-12-17,2.43,13
2025-12-18,2.19,25
2025-12-19,2.28,37
2025-12-20,2.20,10
2025-12-21,2.22,10
2025-12-22,2.29,53
2025-12-23,2.41,5
2025-12-24,2.24,10
2025-12-25,2.67,24
2025-12-26,2.34,6
2025-12-27,2.36,19
2025-12-28,2.23,5
2025-12-29,2.21,7
2025-12-30,2.40,33
2025-12-31,2.28,9
2026-01-01,2.29,40
2026-01-02,2.38,22
2026-01-03,2.41,17
2026-01-04,2.30,7`,
  },
  {
    id: 'mag7-magnitude-ww-st',
    label: 'MAG-7 MAGnitude WW ST',
    item_key: 'shotgun_mag_7_magnitude',
    skin_name: 'MAG-7 | MAGnitude',
    wear: 'WW',
    stattrak: true,
    external_price_cents: 169,
    steam_price_cents: 221,
    fee_pct: 0.13,
    source_path: 'data/prices/items/shotgun/mag/shotgun_mag_7_magnitude.json',
    history: `2025-12-27,2.27,42
2025-12-28,2.27,43
2025-12-29,2.38,38
2025-12-30,2.40,21
2025-12-31,2.38,45
2026-01-01,2.42,67
2026-01-02,2.29,41
2026-01-03,2.26,32
2026-01-04,2.25,51
2026-01-05,2.66,36
2026-01-06,2.40,19
2026-01-07,2.47,33
2026-01-08,2.32,34
2026-01-09,2.25,33
2026-01-10,2.40,39
2026-01-11,2.54,41
2026-01-12,3.45,27
2026-01-13,2.35,18
2026-01-14,2.50,25
2026-01-15,2.26,35
2026-01-16,2.52,22
2026-01-17,2.36,26
2026-01-18,2.40,37
2026-01-19,2.36,23
2026-01-20,2.43,20
2026-01-21,2.32,36
2026-01-22,2.35,54
2026-01-23,2.40,35
2026-01-24,2.27,41
2026-01-25,2.21,16`,
  },
  {
    id: 'mp9-hot-rod-fn',
    label: 'MP9 Hot Rod FN',
    item_key: 'smg_mp9_hot_rod',
    skin_name: 'MP9 | Hot Rod',
    wear: 'FN',
    stattrak: false,
    external_price_cents: 237895,
    steam_price_cents: 260422,
    fee_pct: 0.13,
    source_path: 'notebooks/data/smg/mp9/smg_mp9_hot_rod.json',
    history: `2026-03-11,3307.06,1
2026-03-14,2334.58,1
2026-03-15,3433.17,8
2026-03-16,3867.16,1
2026-03-17,3615.45,3
2026-03-18,3410.22,4
2026-03-19,3481.13,1
2026-03-20,2994.71,3
2026-03-22,2736.61,1
2026-03-24,3426.44,1
2026-03-26,2829.85,3
2026-03-27,2855.60,1
2026-03-28,2992.46,2
2026-03-29,3029.52,2
2026-03-31,2982.49,1
2026-04-01,2291.66,1
2026-04-02,3014.35,1
2026-04-03,3014.31,1
2026-04-04,3124.22,1
2026-04-06,2977.69,1
2026-04-07,2903.32,1
2026-04-08,2889.45,1
2026-04-09,2930.58,3
2026-04-10,3157.00,2
2026-04-12,2850.31,2
2026-04-13,2748.00,1
2026-04-14,2860.41,1
2026-04-15,2846.36,1
2026-04-16,2684.76,1
2026-04-17,2604.22,1`,
  },
];

export function getDemoMarket(id) {
  return DEMO_MARKETS.find((market) => market.id === id) || DEMO_MARKETS[0];
}

const DEMO_RECOMMENDATION_ITEMS = [
  ['smg_mac_10_classic_crate', 'MAC-10 | Classic Crate', 'mac_10', 'WW', 0, 173, 23, 0.66, 0.341],
  ['smg_mac_10_carnivore', 'MAC-10 | Carnivore', 'mac_10', 'BS', 0, 230, 7, 0.635, 0.648],
  ['shotgun_mag_7_magnitude', 'MAG-7 | MAGnitude', 'mag_7', 'WW', 1, 221, 16, 0.613, 0.131],
  ['sniper_awp_acheron', 'AWP | Acheron', 'awp', 'BS', 0, 493, 219, 0.611, 0.089],
  ['rifle_aug_trigger_discipline', 'AUG | Trigger Discipline', 'aug', 'WW', 0, 102, 169, 0.606, 0.029],
  ['rifle_famas_halftone_wash', 'FAMAS | Halftone Wash', 'famas', 'WW', 0, 200, 5, 0.613, 0.13],
  ['heavy_m249_hypnosis', 'M249 | Hypnosis', 'm249', 'MW', 0, 402, 39, 0.619, 0.037],
  ['rifle_ak_47_safari_mesh', 'AK-47 | Safari Mesh', 'ak_47', 'MW', 0, 242, 16, 0.479, -0.062],
  ['smg_mac_10_acid_hex', 'MAC-10 | Acid Hex', 'mac_10', 'MW', 0, 120, 35, 0.571, -0.008],
  ['heavy_m249_bock_blocks', 'M249 | Bock Blocks', 'm249', 'FT', 0, 271, 6, 0.387, 0.102],
];

export function buildDemoRecommendations({ date = 'demo', limit = 20, sort = 'hybrid', horizonDays = 7 } = {}) {
  const items = DEMO_RECOMMENDATION_ITEMS.map((row) => {
    const [itemKey, skinName, weaponKey, wear, st, priceCents, sales, probUp, pctUp] = row;
    const positiveReturn = Math.max(Number(pctUp), 0);
    const score = sort === 'probability'
      ? Number(probUp)
      : sort === 'pct_up'
        ? Number(pctUp)
        : Number(probUp) * positiveReturn;
    return {
      variant_id: `${itemKey}__${wear}_st${st}`,
      item_key: itemKey,
      skin_name: skinName,
      weapon_key: weaponKey,
      wear,
      st,
      price_cents: priceCents,
      sales,
      prob_up: probUp,
      pct_up: pctUp,
      pct_up_source: 'realized_forward',
      score,
    };
  }).sort((a, b) => b.score - a.score || b.prob_up - a.prob_up);

  return {
    date,
    horizon_days: Number(horizonDays || 7),
    sort_by: sort || 'hybrid',
    limit: Number(limit || 20),
    total_candidates: items.length,
    model_id: 'demo-fallback',
    mode: 'demo',
    items: items.slice(0, Number(limit || 20)),
  };
}
