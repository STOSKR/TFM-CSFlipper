import './styles.css';
import { fetchModelHealth, fetchRecommendations } from './api.js';
import { renderCalendarTab } from './calendar.js';
import { DEMO_MARKETS, buildDemoRecommendations, getDemoMarket } from './demo-data.js';
import { buildFeatures, parseHistory } from './history.js';
import { renderDashboard } from './views.js';

const app = document.querySelector('#app');
const initialMarket = DEMO_MARKETS[0];
const MODEL_PING_INTERVAL_MS = 5 * 60 * 1000;
let modelPingTimer = null;

const state = {
  activeTab: 'dashboard',
  activeDemoId: initialMarket.id,
  item_key: initialMarket.item_key,
  skin_name: initialMarket.skin_name,
  wear: initialMarket.wear,
  stattrak: initialMarket.stattrak,
  external_price_cents: initialMarket.external_price_cents,
  steam_price_cents: initialMarket.steam_price_cents,
  fee_pct: initialMarket.fee_pct,
  history: initialMarket.history,
  source_path: initialMarket.source_path,
  result: null,
  recommendationDate: '2026-04-14',
  recommendationLimit: 20,
  recommendationHorizon: 7,
  recommendationSort: 'hybrid',
  recommendations: null,
  recommendationsError: '',
  recommendationsLoading: false,
  modelStatus: {
    state: 'checking',
    label: 'Comprobando modelo',
    detail: 'Consultando /api/health.',
  },
};

function setModelStatus(nextStatus) {
  state.modelStatus = {
    ...state.modelStatus,
    ...nextStatus,
  };
}

function modelStatusFromHealth(health) {
  if (health.ok) {
    return {
      state: 'online',
      label: 'Modelo activo',
      detail: health.model_id ? `Modelo remoto listo: ${health.model_id}` : 'Backend remoto listo.',
    };
  }

  if (health.mode === 'demo') {
    return {
      state: 'demo',
      label: 'Modo demo',
      detail: health.message || 'MODEL_API_URL no esta configurada; se usaran respuestas de demostracion.',
    };
  }

  return {
    state: 'offline',
    label: 'Modelo no disponible',
    detail: health.message || 'El backend remoto no paso el healthcheck.',
  };
}

async function updateModelStatus({ showChecking = false } = {}) {
  if (showChecking) {
    setModelStatus({
      state: 'checking',
      label: 'Comprobando modelo',
      detail: 'Consultando /api/health.',
    });
    render();
  }

  try {
    const health = await fetchModelHealth();
    setModelStatus(modelStatusFromHealth(health));
  } catch (error) {
    setModelStatus({
      state: 'offline',
      label: 'Modelo no disponible',
      detail: error.message,
    });
  }

  render();
}

function startModelPing() {
  if (modelPingTimer) return;
  updateModelStatus({ showChecking: true });
  modelPingTimer = window.setInterval(() => updateModelStatus(), MODEL_PING_INTERVAL_MS);
}

function render() {
  const rows = parseHistory(state.history);
  const activeView = state.activeTab === 'dashboard' ? renderDashboard(rows, state) : renderCalendarTab(state);

  app.innerHTML = `
    <section class="shell">
      <header class="topbar">
        <div class="brand">
          <span class="eyebrow">CS2 Market Arbitrage</span>
          <h1>Panel de arbitraje CS2</h1>
          <p>Compara precio externo, precio de Steam y senales del modelo para priorizar oportunidades.</p>
        </div>
        <div class="topbar-actions">
          <div class="system-status status-${state.modelStatus.state}" title="${state.modelStatus.detail}">
            <span></span>
            ${state.modelStatus.label}
          </div>
          <nav class="tabbar" aria-label="Vistas principales">
            <button class="${state.activeTab === 'dashboard' ? 'active' : ''}" data-tab="dashboard" type="button">Oportunidades</button>
            <button class="${state.activeTab === 'calendar' ? 'active' : ''}" data-tab="calendar" type="button">Calendario</button>
          </nav>
        </div>
      </header>
      ${activeView}
    </section>
  `;

  document.querySelectorAll('[data-tab]').forEach((button) => {
    button.addEventListener('click', () => {
      state.activeTab = button.dataset.tab;
      render();
    });
  });

  const historyInput = document.querySelector('#history-input');
  if (historyInput) {
    historyInput.addEventListener('input', (event) => {
      state.history = event.currentTarget.value;
      state.result = null;
    });
  }

  const demoSelector = document.querySelector('#demo-market');
  if (demoSelector) {
    demoSelector.addEventListener('change', (event) => {
      applyDemoMarket(event.currentTarget.value);
      render();
    });
  }

  const refreshHistory = document.querySelector('#refresh-history');
  if (refreshHistory) {
    refreshHistory.addEventListener('click', () => {
      const currentInput = document.querySelector('#history-input');
      if (currentInput) state.history = currentInput.value;
      render();
    });
  }

  const form = document.querySelector('#predict-form');
  if (form) form.addEventListener('submit', onSubmit);

  const recommendationsForm = document.querySelector('#recommendations-form');
  if (recommendationsForm) recommendationsForm.addEventListener('submit', onRecommendationsSubmit);
}

function applyDemoMarket(id) {
  const market = getDemoMarket(id);
  state.activeDemoId = market.id;
  state.item_key = market.item_key;
  state.skin_name = market.skin_name;
  state.wear = market.wear;
  state.stattrak = market.stattrak;
  state.external_price_cents = market.external_price_cents;
  state.steam_price_cents = market.steam_price_cents;
  state.fee_pct = market.fee_pct;
  state.history = market.history;
  state.source_path = market.source_path;
  state.result = null;
}

async function readApiResponse(response, fallbackMessage) {
  const text = await response.text();
  let data = {};

  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { error: fallbackMessage };
    }
  }

  if (!response.ok) {
    return { ok: false, data: { error: data.detail || data.error || fallbackMessage } };
  }

  return { ok: true, data };
}

const MODEL_WAKE_TIMEOUT_MS = 55000;

async function fetchWithTimeout(url, options = {}, timeoutMs = MODEL_WAKE_TIMEOUT_MS) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    window.clearTimeout(timeout);
  }
}

function eurosToCents(value) {
  return Math.round(Number(value || 0) * 100);
}

function forecastReturnFromProbabilities(result) {
  const probabilities = result?.probabilities;
  if (!probabilities) return null;
  const up = Number(probabilities.up);
  const down = Math.max(Number(probabilities.down), Number(result.down_risk || 0));
  if (!Number.isFinite(up) || !Number.isFinite(down)) return null;
  return (up - down) * 0.07;
}

function normalizePredictionResult(data, payload) {
  if (!data || data.error) return data;

  const fallbackForecast = forecastReturnFromProbabilities(data);
  const hasArbitrageReturn = data.arbitrage_return !== undefined && data.arbitrage_return !== null;
  const arbitrageReturn = hasArbitrageReturn ? Number(data.arbitrage_return) : Number(payload.arbitrage_return || 0);
  const expectedReturn = hasArbitrageReturn
    ? Number(data.expected_return || 0)
    : Number(fallbackForecast ?? data.expected_return ?? 0);
  const basePrice = Number(payload.steam_price_cents || payload.price_cents || 0);

  return {
    ...data,
    expected_return: expectedReturn,
    arbitrage_return: arbitrageReturn,
    expected_price_cents: Math.round(basePrice * (1 + expectedReturn)),
  };
}

function localPrediction(payload) {
  const momentum = Number(payload.ret_7d || 0);
  const volatility = Number(payload.volatility_30d || 0);
  const arbitrageReturn = Number(payload.arbitrage_return || 0);
  const sales = Number(payload.sales || 0);
  const liquidityPenalty = sales < 5 ? 0.18 : sales < 20 ? 0.06 : 0;
  const down = Math.max(0.02, Math.min(0.98, 0.32 - momentum * 2.4 + volatility * 3.2 + liquidityPenalty));
  const up = Math.max(0.02, Math.min(0.98, 0.48 + momentum * 3.2 - volatility * 1.6));
  const hold = Math.max(0, 1 - down - up);
  const total = down + hold + up;
  const probabilities = {
    down: down / total,
    hold: hold / total,
    up: up / total,
  };
  const expectedReturn = forecastReturnFromProbabilities({ probabilities }) || 0;
  const decision = probabilities.down >= 0.75
    ? 'reject'
    : arbitrageReturn > 0 && probabilities.up >= 0.6
      ? 'buy'
      : 'review';
  const confidence = decision === 'buy'
    ? probabilities.up
    : decision === 'reject'
      ? probabilities.down
      : Math.max(probabilities.hold, Math.min(0.62, 1 - Math.abs(probabilities.up - probabilities.down)));
  const basePrice = Number(payload.steam_price_cents || payload.price_cents || 0);

  return {
    decision,
    direction: decision === 'buy' ? 'up' : decision === 'reject' ? 'down' : 'hold',
    confidence,
    expected_return: expectedReturn,
    arbitrage_return: arbitrageReturn,
    down_risk: probabilities.down,
    expected_price_cents: Math.round(basePrice * (1 + expectedReturn)),
    probabilities,
    reason: 'Prediccion demo local.',
  };
}

async function onSubmit(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  state.item_key = form.get('item_key');
  state.skin_name = '';
  state.wear = form.get('wear');
  state.stattrak = form.get('stattrak') === 'on';
  state.external_price_cents = eurosToCents(form.get('external_price_eur'));
  state.steam_price_cents = eurosToCents(form.get('steam_price_eur'));
  state.fee_pct = Number(form.get('fee_pct'));

  const payload = buildFeatures(parseHistory(state.history), state);
  const resultPanel = document.querySelector('.signal-panel');
  if (resultPanel) {
    resultPanel.innerHTML = '<div class="empty compact">Analizando la oportunidad con el modelo...</div>';
  }

  try {
    const response = await fetchWithTimeout('/api/predict', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const { ok, data } = await readApiResponse(response, 'No se pudo calcular la prediccion.');
    if (ok) {
      state.result = normalizePredictionResult(data, payload);
      setModelStatus({
        state: data.model_id ? 'online' : 'demo',
        label: data.model_id ? 'Modelo activo' : 'Modo demo',
        detail: data.model_id ? `Modelo remoto listo: ${data.model_id}` : 'Prediccion generada con la regla demo.',
      });
    } else {
      state.result = localPrediction(payload);
      setModelStatus({
        state: 'demo',
        label: 'Modo demo',
        detail: data.error || 'Prediccion local generada sin backend.',
      });
    }
  } catch (error) {
    const message = error.name === 'AbortError'
      ? 'El backend del modelo tardo demasiado; usando prediccion demo local.'
      : `Prediccion demo local. Detalle backend: ${error.message}`;
    state.result = localPrediction(payload);
    setModelStatus({
      state: 'demo',
      label: 'Modo demo',
      detail: message,
    });
  }
  render();
}

async function onRecommendationsSubmit(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  state.recommendationDate = form.get('date');
  state.recommendationLimit = Number(form.get('limit'));
  state.recommendationHorizon = Number(form.get('horizon_days'));
  state.recommendationSort = form.get('sort');
  state.recommendationsLoading = true;
  state.recommendationsError = '';
  render();

  try {
    state.recommendations = await fetchRecommendations({
      date: state.recommendationDate,
      limit: state.recommendationLimit,
      sort: state.recommendationSort,
      horizonDays: state.recommendationHorizon,
    });
    state.recommendationsError = state.recommendations.mode === 'demo' && state.recommendations.message
      ? state.recommendations.message
      : '';
  } catch (error) {
    state.recommendations = buildDemoRecommendations({
      date: state.recommendationDate,
      limit: state.recommendationLimit,
      sort: state.recommendationSort,
      horizonDays: state.recommendationHorizon,
    });
    state.recommendationsError = `El backend remoto no respondio; mostrando oportunidades demo. Detalle: ${error.message}`;
  }
  state.recommendationsLoading = false;
  render();
}

render();
startModelPing();
