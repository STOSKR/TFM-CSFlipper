export function parseHistory(text) {
  return text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line, index) => {
      const [dateRaw, priceRaw, salesRaw] = line.split(/[,\s;]+/);
      const price = Number(priceRaw);
      const sales = Number(salesRaw || 0);
      return {
        day: dateRaw || String(index + 1),
        price_cents: Number.isFinite(price) ? Math.round(price * 100) : 0,
        sales: Number.isFinite(sales) ? sales : 0,
      };
    })
    .filter((row) => row.price_cents > 0);
}

export function mean(values) {
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
}

export function std(values) {
  if (values.length < 2) return 0;
  const avg = mean(values);
  return Math.sqrt(mean(values.map((value) => (value - avg) ** 2)));
}

export function zScore(values) {
  if (values.length < 2) return 0;
  const sigma = std(values);
  return sigma > 0 ? (values.at(-1) - mean(values)) / sigma : 0;
}

export function ret(rows, days) {
  if (rows.length <= days) return 0;
  const current = rows.at(-1).price_cents;
  const previous = rows.at(-1 - days).price_cents;
  return previous > 0 ? current / previous - 1 : 0;
}

export function valueRet(values, days) {
  if (values.length <= days) return 0;
  const current = values.at(-1);
  const previous = values.at(-1 - days);
  return previous > 0 ? current / previous - 1 : 0;
}

export function rsi(prices, days = 14) {
  if (prices.length <= days) return 50;
  const deltas = [];
  for (let index = prices.length - days; index < prices.length; index += 1) {
    deltas.push(prices[index] - prices[index - 1]);
  }
  const gains = deltas.filter((value) => value > 0);
  const losses = deltas.filter((value) => value < 0).map((value) => Math.abs(value));
  const avgGain = mean(gains);
  const avgLoss = mean(losses);
  if (avgLoss === 0) return avgGain > 0 ? 100 : 50;
  const relativeStrength = avgGain / avgLoss;
  return 100 - 100 / (1 + relativeStrength);
}

export function ema(values, span) {
  if (!values.length) return 0;
  const alpha = 2 / (span + 1);
  return values.slice(1).reduce((current, value) => value * alpha + current * (1 - alpha), values[0]);
}

export function macdHist(prices) {
  if (prices.length < 26) return 0;
  const macd = [];
  for (let end = 26; end <= prices.length; end += 1) {
    const window = prices.slice(0, end);
    macd.push(ema(window, 12) - ema(window, 26));
  }
  return macd.at(-1) - ema(macd, 9);
}

export function dayParts(day) {
  const parsed = new Date(day);
  if (Number.isNaN(parsed.getTime())) {
    const now = new Date();
    return { dow: now.getDay() === 0 ? 6 : now.getDay() - 1, month: now.getMonth() + 1 };
  }
  return { dow: parsed.getDay() === 0 ? 6 : parsed.getDay() - 1, month: parsed.getMonth() + 1 };
}

export function buildFeatures(rows, state) {
  const prices = rows.map((row) => row.price_cents);
  const salesValues = rows.map((row) => row.sales);
  const recent = prices.slice(-30);
  const current = prices.at(-1) || Number(state.steam_price_cents || 0);

  const sales = rows.at(-1)?.sales || 0;
  const ma7 = mean(prices.slice(-7));
  const ma14 = mean(prices.slice(-14));
  const ma30 = mean(recent);
  const external = Number(state.external_price_cents || 0);
  const steam = Number(state.steam_price_cents || current || 0);
  const feePct = Number(state.fee_pct || 0);
  const netSale = steam * (1 - feePct);
  const arbitrageReturn = external > 0 ? netSale / external - 1 : 0;
  const { dow, month } = dayParts(rows.at(-1)?.day);
  const categoryRet7d = Number(state.category_ret_7d || 0);
  const weaponRet7d = Number(state.weapon_ret_7d || 0);

  return {
    item_key: state.item_key,
    wear: state.wear,
    stattrak: state.stattrak,
    st: state.stattrak ? 1 : 0,
    price_cents: current,
    external_price_cents: external,
    steam_price_cents: steam,
    fee_pct: feePct,
    arbitrage_return: arbitrageReturn,
    sales,
    history: rows,
    ret_1d: ret(rows, 1),
    sales_ret_1d: valueRet(salesValues, 1),
    ret_3d: ret(rows, 3),
    sales_ret_3d: valueRet(salesValues, 3),
    ret_7d: ret(rows, 7),
    sales_ret_7d: valueRet(salesValues, 7),
    ret_14d: ret(rows, 14),
    sales_ret_14d: valueRet(salesValues, 14),
    ret_30d: ret(rows, 30),
    sales_ret_30d: valueRet(salesValues, 30),
    price_vs_ma_7d: ma7 > 0 ? current / ma7 - 1 : 0,
    volatility_7d: std(prices.slice(-7).map((price, index, values) => (index > 0 && values[index - 1] > 0 ? price / values[index - 1] - 1 : 0)).slice(1)),
    sales_z_7d: zScore(salesValues.slice(-7)),
    price_vs_ma_14d: ma14 > 0 ? current / ma14 - 1 : 0,
    volatility_14d: std(prices.slice(-14).map((price, index, values) => (index > 0 && values[index - 1] > 0 ? price / values[index - 1] - 1 : 0)).slice(1)),
    sales_z_14d: zScore(salesValues.slice(-14)),
    price_vs_ma_30d: ma30 > 0 ? current / ma30 - 1 : 0,
    volatility_30d: std(prices.slice(-30).map((price, index, values) => (index > 0 && values[index - 1] > 0 ? price / values[index - 1] - 1 : 0)).slice(1)),
    sales_z_30d: zScore(salesValues.slice(-30)),
    rsi_14d: rsi(prices),
    macd_hist: macdHist(prices),
    category_ret_7d: categoryRet7d,
    weapon_ret_7d: weaponRet7d,
    rel_momentum_cat_7d: ret(rows, 7) - categoryRet7d,
    rel_momentum_weap_7d: ret(rows, 7) - weaponRet7d,
    log_price: Math.log1p(current),
    log_sales: Math.log1p(Math.max(sales, 0)),
    variant_age_days: Math.max(rows.length - 1, 0),
    dow,
    month,
    history_points: rows.length,
  };
}

export function historySummary(rows) {
  const current = rows.at(-1)?.price_cents || 0;
  const first = rows[0]?.price_cents || current;
  const maxPrice = Math.max(...rows.map((row) => row.price_cents), current);
  const minPrice = Math.min(...rows.map((row) => row.price_cents), current);
  return {
    current,
    totalReturn: first > 0 ? current / first - 1 : 0,
    ret7: ret(rows, 7),
    avgSales: mean(rows.slice(-7).map((row) => row.sales)),
    minPrice,
    maxPrice,
  };
}

export function chartPoints(rows, width, height, pad) {
  const prices = rows.map((row) => row.price_cents);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const span = Math.max(maxPrice - minPrice, 1);
  const points = rows
    .map((row, index) => {
      const x = pad + (index / (rows.length - 1)) * (width - pad * 2);
      const y = height - pad - ((row.price_cents - minPrice) / span) * (height - pad * 2);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
  return { points, minPrice, maxPrice };
}
