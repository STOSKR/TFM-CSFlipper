function money(cents) {
  return new Intl.NumberFormat('es-ES', {
    style: 'currency',
    currency: 'EUR',
  }).format(Number(cents || 0) / 100);
}

function pct(value) {
  return `${(Number(value || 0) * 100).toFixed(2)}%`;
}

function sourceLabel(source) {
  return source === 'realized_forward' ? 'Subida observada' : 'Momentum reciente';
}

export function renderRecommendationList(payload, loading, error) {
  if (loading) {
    return '<div class="empty compact">Buscando oportunidades con el modelo...</div>';
  }
  if (error && (!payload || !payload.items || payload.items.length === 0)) {
    return `<div class="empty compact error-box">${error}</div>`;
  }
  if (!payload || !payload.items || payload.items.length === 0) {
    return '<div class="empty compact">Elige una fecha y pulsa Buscar oportunidades.</div>';
  }

  return `
    ${error ? `<div class="empty compact warning-box">${error}</div>` : ''}
    <div class="recommendation-summary">
      <div>
        <span>Fecha</span>
        <strong>${payload.date}</strong>
      </div>
      <div>
        <span>Oportunidades evaluadas</span>
        <strong>${payload.total_candidates}</strong>
      </div>
      <div>
        <span>Motor</span>
        <strong>${payload.model_id || 'demo'}</strong>
      </div>
    </div>
    <div class="recommendation-list">
      ${payload.items
        .map((item, index) => {
          const stattrak = Number(item.st) === 1 ? 'StatTrak' : 'Normal';
          const scoreTone = Number(item.score || 0) >= 0.5 ? 'up' : 'hold';
          return `
            <article class="recommendation-row">
              <div class="rank">${index + 1}</div>
              <div class="recommendation-main">
                <strong>${item.skin_name || item.item_key}</strong>
                <span>${item.weapon_key} / ${item.wear} / ${stattrak}</span>
              </div>
              <div>
                <span>Precio Steam</span>
                <strong>${money(item.price_cents)}</strong>
              </div>
              <div>
                <span>Probabilidad subida</span>
                <strong>${pct(item.prob_up)}</strong>
              </div>
              <div>
                <span>${sourceLabel(item.pct_up_source)}</span>
                <strong>${pct(item.pct_up)}</strong>
              </div>
              <div>
                <span>Prioridad</span>
                <strong class="${scoreTone}">${pct(item.score)}</strong>
              </div>
            </article>
          `;
        })
        .join('')}
    </div>
  `;
}
