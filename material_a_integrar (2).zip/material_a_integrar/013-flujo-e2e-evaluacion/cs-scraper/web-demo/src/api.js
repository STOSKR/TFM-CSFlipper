const MODEL_WAKE_TIMEOUT_MS = 55000;

async function fetchWithTimeout(url, options = {}, timeoutMs = MODEL_WAKE_TIMEOUT_MS) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    window.clearTimeout(timeout);
  }
}

async function readJsonResponse(response, fallbackMessage) {
  const text = await response.text();
  let data = {};

  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = { error: fallbackMessage };
    }
  }

  if (!response.ok) {
    throw new Error(data.detail || data.error || fallbackMessage);
  }

  return data;
}

export async function fetchModelHealth() {
  let response;
  try {
    response = await fetchWithTimeout('/api/health');
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error('El backend del modelo no respondio al healthcheck. Puede estar arrancando.');
    }
    throw error;
  }

  return readJsonResponse(response, 'No se pudo comprobar el estado del modelo.');
}

export async function fetchRecommendations({ date, limit, sort, horizonDays }) {
  const params = new URLSearchParams({
    date,
    limit: String(limit),
    sort,
    horizon_days: String(horizonDays),
  });
  let response;
  try {
    response = await fetchWithTimeout(`/api/recommendations?${params.toString()}`);
  } catch (error) {
    if (error.name === 'AbortError') {
      throw new Error('El backend del modelo tardo demasiado en responder. Puede estar arrancando; espera unos segundos y vuelve a buscar oportunidades.');
    }
    throw error;
  }
  return readJsonResponse(response, 'No se pudieron cargar las oportunidades recomendadas.');
}
