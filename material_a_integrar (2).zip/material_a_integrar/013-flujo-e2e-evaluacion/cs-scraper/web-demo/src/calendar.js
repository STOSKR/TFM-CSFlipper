import { renderRecommendationList } from './recommendations.js';

export function renderCalendarTab(state) {
  return `
    <section class="calendar-layout terminal-grid">
      <aside class="workspace-panel control-panel">
        <div class="panel-head">
          <div>
            <span class="eyebrow">Busqueda diaria</span>
            <h2>Criterios</h2>
          </div>
        </div>
        <form id="recommendations-form" class="calendar-controls control-form">
          <label>
            Fecha a analizar
            <input name="date" type="date" value="${state.recommendationDate}" />
          </label>
          <div class="grid">
            <label>
              Maximo de resultados
              <input name="limit" type="number" min="10" max="50" step="5" value="${state.recommendationLimit}" />
            </label>
            <label>
              Dias de proyeccion
              <input name="horizon_days" type="number" min="1" max="30" value="${state.recommendationHorizon}" />
            </label>
          </div>
          <label>
            Ordenar por
            <select name="sort">
              ${[
                ['hybrid', 'Score combinado'],
                ['probability', 'Probabilidad de subida'],
                ['pct_up', 'Subida estimada'],
              ]
                .map(([value, label]) => `<option value="${value}" ${value === state.recommendationSort ? 'selected' : ''}>${label}</option>`)
                .join('')}
            </select>
          </label>
          <button type="submit">Buscar oportunidades</button>
        </form>
      </aside>
      <section class="workspace-panel recommendations-panel">
        <div class="panel-head">
          <div>
            <span class="eyebrow">Calendario de oportunidades</span>
            <h2>Recomendaciones para la fecha</h2>
          </div>
        </div>
        ${renderRecommendationList(state.recommendations, state.recommendationsLoading, state.recommendationsError)}
      </section>
    </section>
  `;
}
