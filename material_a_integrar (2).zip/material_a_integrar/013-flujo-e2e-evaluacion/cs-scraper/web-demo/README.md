# CS2 Market Arbitrage Demo

Demo web preparada para usar el modelo LightGBM entrenado en `notebooksV2/artifacts/scientific_v2`.

Incluye dos piezas:

- `web-demo`: frontend Vite que se puede subir a Vercel.
- `model_service`: API Python/FastAPI que carga los `.joblib` y responde `/predict` y `/recommendations`.

## Local

```bash
python -m pip install -r requirements.txt
cd web-demo && npm install
cd ..
bash scripts/run_web_demo.sh
```

Abre la URL que imprima Vite, normalmente:

```text
http://localhost:5173
```

Si prefieres arrancarlo en dos terminales:

```bash
uvicorn model_service.app:app --reload --host 0.0.0.0 --port 8000
```

```bash
cd web-demo
npm install
npm run dev
```

En desarrollo, Vite redirige `/api/*` a `http://127.0.0.1:8000`.

Si la maquina no tiene Node/npm instalado, puedes probar solo la API:

```bash
uvicorn model_service.app:app --reload --host 0.0.0.0 --port 8000
curl "http://127.0.0.1:8000/api/recommendations?date=2026-04-14&limit=20&sort=hybrid"
```

## Calendario de recomendaciones

La pestana `Calendario` llama a:

```text
GET /api/recommendations?date=YYYY-MM-DD&limit=20&sort=hybrid&horizon_days=7
```

Ordenes soportados:

- `hybrid`: combina probabilidad de subida y subida esperada/realizada.
- `probability`: ordena por probabilidad de subida.
- `pct_up`: ordena por porcentaje de subida.

El backend usa `data/prices` si hay historicos disponibles y, como fallback local,
`notebooks/data`. Puedes forzar otra carpeta con `RECOMMENDATIONS_DATA_DIR`.

## Vercel

El frontend llama a la funcion:

```text
/api/predict
```

Configura estas variables en Vercel, dentro del proyecto `web-demo`:

- `MODEL_API_URL`: URL base publica del backend Python, por ejemplo `https://cs2-market-model-api.onrender.com`.
- `MODEL_API_KEY`: token opcional para llamar al modelo.

Sin `MODEL_API_URL`, la API de Vercel devuelve una prediccion demo para poder enseñar la interfaz, pero no usa LightGBM.

## Hosting del modelo

### Render

Este repo ya incluye `render.yaml`. Crea un Blueprint/Web Service desde GitHub y Render usara:

```text
Build command: pip install -r requirements.txt
Start command: uvicorn model_service.app:app --host 0.0.0.0 --port $PORT
Health check: /health
```

Variables del backend:

- `ARTIFACTS_DIR=notebooksV2/artifacts/scientific_v2`
- `CORS_ORIGINS=*` para demo publica, o la URL de Vercel para restringirlo.
- `RECOMMENDATIONS_DATA_DIR=notebooks/data` solo si quieres forzarlo. Sin esta variable usa `data/prices` si existe y despues `notebooks/data`.

Pruebas despues del deploy:

```bash
curl https://cs2-market-model-api.onrender.com/health
curl "https://cs2-market-model-api.onrender.com/recommendations?date=2026-04-14&limit=20&sort=hybrid"
```

### Railway

Crea un servicio desde el repo y configura:

```text
Build command: pip install -r requirements.txt
Start command: uvicorn model_service.app:app --host 0.0.0.0 --port $PORT
```

Variables:

- `ARTIFACTS_DIR=notebooksV2/artifacts/scientific_v2`
- `CORS_ORIGINS=*`
- `RECOMMENDATIONS_DATA_DIR=notebooks/data` opcional.

Railway te dara una URL publica. Esa URL base es la que va en `MODEL_API_URL` en Vercel.

Otras opciones razonables:

- Hugging Face Spaces: crea un Space Docker/Python y usa el mismo comando de arranque.

El endpoint acepta JSON con historial y precios:

```json
{
  "external_price_cents": 1760,
  "steam_price_cents": 2010,
  "fee_pct": 0.13,
  "stattrak": false,
  "history": [
    { "day": "2026-04-01", "price_cents": 1810, "sales": 42 }
  ]
}
```

Y devuelve decision, probabilidades `down/hold/up`, threshold aplicado y features usadas.

## Subir todo

1. Sube el repo a GitHub.
2. En Render, crea un Blueprint desde el repo usando `render.yaml`.
3. Copia la URL publica base del backend, sin `/predict`.
4. En Vercel, importa el proyecto con root directory `web-demo`.
5. En Vercel, define `MODEL_API_URL` con la URL de Render.
6. Despliega y prueba `/health` en Render y la web en Vercel.
