# Registro de Experimentos

Este archivo es para apuntar cambios rapidamente antes de pasarlos a la memoria LaTeX.

## Estado base

- Dataset V2: 6,013,472 filas, 2,980 variantes.
- Rango temporal: 2013-09-12 a 2026-04-12.
- Target: direccion a 7 dias con banda +/- 3%.
- Mejor referencia historica: Random Forest, balanced accuracy 0.4673.

## Cambios

| Fecha | Cambio | Antes | Despues | Evidencia |
|---|---|---|---|---|
| 2026-05-13 | Dataset V2 auditable | Notebook 02 con riesgo de datos sinteticos | Notebook 02 solo usa datos reales y exporta metadata | `direction_dataset_metadata.json` |
| 2026-05-13 | Notebooks V2 en raiz | V2 dentro de `notebooks/modelos` | V2 en `notebooksV2` | `notebooksV2/run.sh` |
| 2026-05-13 | Prediccion de magnitud | Solo direccion/probabilidad | Notebook 10 predice `future_return` | `10_magnitude_return_model.ipynb` |
| 2026-05-13 | Demo web | Sin demo desplegable | `web-demo` listo para Vercel | `web-demo/api/predict.js` |
| 2026-05-21 | Ranking robusto accionable | `utility_score` dependia de media de retorno sensible a outliers | Se aplican filtros `price_cents >= 100`, `sales >= 5` y retorno firmado clipado para rankear | `analytics/policy_metrics.py`, `threshold_model_ranking.md` |

## Plantilla para nuevos experimentos

### Experimento: <nombre>

- Fecha:
- Notebook/script:
- Hipotesis:
- Datos usados:
- Parametros:
- Estado anterior:
- Resultado:
- Comparacion contra baseline:
- Decision:
- Siguiente paso:
