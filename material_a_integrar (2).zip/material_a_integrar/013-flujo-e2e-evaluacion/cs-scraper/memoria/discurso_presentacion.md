# Discurso breve para la presentación

Duración objetivo: 6-7 minutos.

## 1. Portada

Buenos días. Soy Shiyi y voy a presentar un sistema de análisis de arbitraje para artículos de CS2

## 2. Motivación

El arbitraje es como hacer una reventa del articulo entre diferentes plataformas. Y CS2 es un videojuego donde existen artículos cosméticos que se compran y venden entre diferentes plataformas. El problema es que el mercado es grande, cambia rápido y tiene mucho ruido.

Por eso el enfoque del proyecto no es actuar más, sino actuar mejor.

## 3. Objetivo

El objetivo es convertir históricos de mercado en decisiones.

Por la naturaleza del videojuego, para cada artículo se trabaja con un horizonte de siete días y enfocandose en la precisión.

## 5. Datos y almacenamiento

Como primer paso se ha construido un scraper para extraer el historial de precios y la información de contexto de los objetos.

El sistema guarda 830 JSON locales, cubre 2.980 variantes y trabaja con históricos entre 2013 y 2026.

## 6. Preprocesamiento

Para cada artículo y día se calculan señales de precio, actividad, tendencia y calendario. Después se etiqueta lo que ocurre siete días después. Así se obtienen 6,01 millones de filas supervisadas.

## 7. Diseño experimental

Después del preprocesamiento se define la partición experimental.

La separación se hace respetando el eje temporal: entrenamiento, validación y prueba. En números aproximados, son 3,63 millones de filas para entrenamiento, 1,15 millones para validación y 1,21 millones para prueba.

## 8. Pruebas realizadas

Con la partición ya fijada, se ejecutan las pruebas.

La parte experimental se agrupa por familias reales de prueba.

Primero están las referencias sencillas, como always hold, momentum y logística. Después están los tabulares: XGBoost, LightGBM, CatBoost y Random Forest. También hay pruebas de series temporales y deep learning, como N-HiTS, TCN y TFT.

Por último están las pruebas de selección y política: ensemble, calibración, umbrales, modelo de magnitud, sensibilidad de banda y ranking V2. No todos los experimentos se promocionan al resultado final, pero todos sirven para justificar la selección.

## 9. Comparación de modelos

Los modelos tabulares mejoran la referencia inicial, aunque el mercado sigue siendo ruidoso.

En la gráfica dejo la comparación principal entre modelos tabulares: XGBoost, LightGBM y CatBoost.

Hay otros resultados documentados, como Random Forest y variantes V2, pero pertenecen a otros experimentos o se usan como referencia histórica. La lectura es que hay señal, pero no suficiente para obligar al sistema a decidir siempre.

## 10. Políticas de decisión

La parte más accionable aparece al exigir confianza con umbrales.

Cuando el sistema actúa poco, la precisión sube: alrededor del 94,5 % para evitar y del 91,7 % para comprar. Aquí es donde la idea de filtro tiene más sentido.

## 11. Demo

Para que el resultado sea consumible, construí una demo.

El frontend llama a una API, la API carga el modelo y devuelve una decisión. La interfaz lo presenta como calendario, ranking y ficha de artículo.

## 12. Limitaciones

Hay tres límites principales.

La precisión global todavía es moderada, la cobertura baja cuando pedimos mucha precisión, y el arbitraje externo aún no entra completamente como variable del modelo.

## 13. Siguientes pruebas

Los siguientes pasos son medir mejor el equilibrio entre precisión y cobertura, simular una cartera con liquidez y capital limitado, y entrenar un modelo binario más alineado con comprar rentable frente a no comprar.

## 14. Conclusiones

El proyecto deja un pipeline completo: captura, dataset, modelos, política de decisión y demo.

La conclusión principal es que el sistema no intenta predecirlo todo. Intenta reducir ruido, actuar menos y decidir mejor.

Muchas gracias.
