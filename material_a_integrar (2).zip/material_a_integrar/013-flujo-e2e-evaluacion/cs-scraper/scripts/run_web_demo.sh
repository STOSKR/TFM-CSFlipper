#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v npm >/dev/null 2>&1; then
  cat >&2 <<'EOF'
Node/npm is not installed in this environment.

You can still test the recommendation API with:
  uvicorn model_service.app:app --reload --host 0.0.0.0 --port 8000

To run the web UI, ask the administrator to install Node.js/npm, then run:
  cd web-demo
  npm install
  cd ..
  bash scripts/run_web_demo.sh
EOF
  exit 127
fi

cd "$ROOT"
python -m uvicorn model_service.app:app --host 0.0.0.0 --port "${MODEL_PORT:-8000}" &
API_PID=$!

cleanup() {
  kill "$API_PID" >/dev/null 2>&1 || true
}
trap cleanup EXIT

cd web-demo
npm run dev
