from __future__ import annotations

import os
import time
from pathlib import Path

from auth import get_valid_session
from catalog import load_catalog
from core import session_from_payload
from scraper import run_incremental_update


def run_once(catalog_path: str | Path, prices_dir: str | Path) -> dict:
    session_payload = get_valid_session()
    session = session_from_payload(session_payload)
    catalog = load_catalog(catalog_path)
    return run_incremental_update(catalog, session, prices_dir)


def run_scheduler() -> None:
    catalog_path = Path(os.getenv("CS2_CATALOG_PATH", "data/catalog.json"))
    prices_dir = Path(os.getenv("CS2_PRICES_DIR", "data/prices"))
    interval_hours = float(os.getenv("CS2_SCRAPER_INTERVAL_HOURS", "6"))
    run_once_only = os.getenv("CS2_RUN_ONCE", "false").lower() in {"1", "true", "yes"}

    while True:
        result = run_once(catalog_path, prices_dir)
        print(
            f"Scrape finished: processed={result['processed']} written={result['written']}"
        )

        if run_once_only:
            return

        sleep_seconds = max(1, int(interval_hours * 3600))
        time.sleep(sleep_seconds)


if __name__ == "__main__":
    run_scheduler()
