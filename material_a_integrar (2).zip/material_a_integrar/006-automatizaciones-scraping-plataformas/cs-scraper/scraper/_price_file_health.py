from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def file_has_price_history(path: str | Path) -> bool:
    file_path = Path(path)
    if not file_path.exists():
        return False

    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False

    variants = payload.get("variants") if isinstance(payload, dict) else None
    if not isinstance(variants, dict):
        return False

    for variant in variants.values():
        if isinstance(variant, dict):
            series = variant.get("series")
            if isinstance(series, list) and series:
                return True
        elif isinstance(variant, list) and variant:
            # Legacy shape support.
            return True

    return False


def count_price_points(path: str | Path) -> int:
    file_path = Path(path)
    if not file_path.exists():
        return 0

    try:
        payload = json.loads(file_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return 0

    variants = payload.get("variants") if isinstance(payload, dict) else None
    if not isinstance(variants, dict):
        return 0

    total = 0
    for variant in variants.values():
        if isinstance(variant, dict):
            series = variant.get("series")
            if isinstance(series, list):
                total += len(series)
        elif isinstance(variant, list):
            total += len(variant)

    return total
