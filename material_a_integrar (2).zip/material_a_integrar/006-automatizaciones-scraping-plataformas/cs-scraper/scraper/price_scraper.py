from __future__ import annotations

import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

import requests

from catalog.builder import iter_catalog_items
from core import RateLimiter, session_from_payload
from ._price_storage import append_price_snapshot, build_price_file_path
from ._steam_market import (
    STEAM_TARGET_COUNTRY,
    STEAM_TARGET_CURRENCY,
    STEAM_TARGET_CURRENCY_CODE,
    build_steam_session,
    fetch_pricehistory,
    fetch_priceoverview,
    has_steam_login_cookie,
    resolve_variant_market_names,
)
from ._steam_playwright import (
    fetch_pricehistory_playwright,
    playwright_pricehistory_fallback_enabled,
)

WEAR_TO_FULL = {
    "FN": "Factory New",
    "MW": "Minimal Wear",
    "FT": "Field-Tested",
    "WW": "Well-Worn",
    "BS": "Battle-Scarred",
}

DEFAULT_CURRENCY = "UNK"


def _search_fallback_enabled() -> bool:
    raw = str(os.getenv("STEAM_ENABLE_SEARCH_FALLBACK", "0") or "0").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _priceoverview_fallback_enabled() -> bool:
    raw = (
        str(os.getenv("STEAM_ENABLE_PRICEOVERVIEW_FALLBACK", "1") or "1")
        .strip()
        .lower()
    )
    return raw in {"1", "true", "yes", "on"}


def _priceoverview_prefer_enabled() -> bool:
    raw = str(os.getenv("STEAM_PREFER_PRICEOVERVIEW", "0") or "0").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _playwright_fallback_enabled() -> bool:
    return playwright_pricehistory_fallback_enabled()


def _ensure_session(
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
) -> requests.Session:
    if isinstance(session, requests.Session):
        return session
    return session_from_payload(session)


def _skin_display_name(skin_key: str) -> str:
    return skin_key.replace("_", " ").title()


def _skin_lookup_name(skin_key: str, skin_payload: dict[str, Any]) -> str:
    value = skin_payload.get("n")
    if isinstance(value, str) and value.strip():
        return value.strip()
    return _skin_display_name(skin_key)


def build_item_meta(item_key: str, context: dict[str, Any]) -> dict[str, str]:
    skin_payload = context.get("skin_data")
    if not isinstance(skin_payload, dict):
        skin_payload = {}

    skin_key = str(context.get("skin_key") or "").strip()
    metadata = {
        "category": str(context.get("category") or "").strip(),
        "weapon_key": str(context.get("weapon_key") or "").strip(),
        "weapon_name": str(context.get("weapon_name") or "").strip(),
        "skin_key": skin_key,
        "skin_name": _skin_lookup_name(skin_key, skin_payload) if skin_key else "",
        "collection": str(skin_payload.get("col") or "").strip(),
        "rarity": str(skin_payload.get("r") or "").strip(),
    }

    if not metadata.get("category"):
        metadata["category"] = item_key.split("_", 1)[0].strip().lower()

    return {key: value for key, value in metadata.items() if value}


def _parse_price_to_cents(value: Any) -> int:
    text = str(value).strip()
    cleaned = re.sub(r"[^0-9,.-]", "", text)
    if cleaned.count(",") and cleaned.count("."):
        if cleaned.rfind(",") > cleaned.rfind("."):
            cleaned = cleaned.replace(".", "").replace(",", ".")
        else:
            cleaned = cleaned.replace(",", "")
    elif cleaned.count(","):
        cleaned = cleaned.replace(".", "").replace(",", ".")

    return int(round(float(cleaned) * 100))


def _parse_currency_code(value: Any) -> str:
    text = str(value)
    lowered = text.lower()

    checks = [
        (("rmb", "cny", "cn\xa5", "￥", "¥"), "CNY"),
        (("usd", "us$", "$"), "USD"),
        (("eur", "€"), "EUR"),
        (("gbp", "£"), "GBP"),
        (("rub", "₽"), "RUB"),
        (("krw", "₩"), "KRW"),
        (("jpy",), "JPY"),
    ]
    for tokens, code in checks:
        if any(token in lowered for token in tokens):
            return code
    return DEFAULT_CURRENCY


def _parse_volume(value: Any) -> int:
    if isinstance(value, int):
        return value
    digits = re.sub(r"[^0-9]", "", str(value))
    return int(digits or "0")


def _parse_steam_time(raw: str) -> int:
    value = " ".join(raw.split())
    formats = [
        "%b %d %Y %H:%M:%S",
        "%b %d %Y %H:%M",
        "%b %d %Y %H: +0",
        "%Y-%m-%d %H:%M:%S",
    ]
    for fmt in formats:
        try:
            parsed = datetime.strptime(value, fmt)
            return int(parsed.replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            continue

    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return int(parsed.timestamp())
    except ValueError as exc:
        raise ValueError(f"Unable to parse steam timestamp: {raw}") from exc


def _validate_snapshot(snapshot: dict[str, Any]) -> Optional[str]:
    required_keys = {"t", "w", "st", "p", "vol"}
    allowed_keys = required_keys | {"ccy"}
    key_set = set(snapshot.keys())
    if not required_keys.issubset(key_set):
        return "missing keys"
    if not key_set.issubset(allowed_keys):
        return "invalid keys"
    if not isinstance(snapshot["t"], int):
        return "invalid timestamp"
    if snapshot["w"] not in WEAR_TO_FULL:
        return "invalid wear"
    if snapshot["st"] not in (0, 1):
        return "invalid stattrak"
    if not isinstance(snapshot["p"], int) or snapshot["p"] < 0:
        return "invalid price"
    if not isinstance(snapshot["vol"], int) or snapshot["vol"] < 0:
        return "invalid volume"
    if "ccy" in snapshot:
        ccy = str(snapshot["ccy"]).strip().upper()
        if not ccy:
            return "invalid currency"
    return None


def scrape_item_prices(
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
    item_key: str,
    skin_data: dict[str, Any],
) -> list[dict[str, Any]]:
    del item_key
    session_obj = _ensure_session(session)
    steam_session = build_steam_session(session_obj)
    if not has_steam_login_cookie(steam_session):
        raise RuntimeError(
            "Steam authenticated session is required for pricehistory. "
            "Refresh manual login capture to include steamLoginSecure cookie."
        )

    weapon_name = skin_data["weapon_name"]
    skin_key = skin_data["skin_key"]
    skin_payload = skin_data["skin_data"]
    skin_name = _skin_lookup_name(skin_key, skin_payload)
    wears = skin_payload.get("w") or []
    has_st = bool(skin_payload.get("st"))

    snapshots: list[dict[str, Any]] = []

    for wear in wears:
        if wear not in WEAR_TO_FULL:
            continue
        wear_full = WEAR_TO_FULL[wear]
        for st in [0, 1] if has_st else [0]:
            prices: list[list[Any]] = []
            attempted_names: set[str] = set()
            attempted_order: list[str] = []
            last_request_error: Exception | None = None
            market_names = resolve_variant_market_names(
                steam_session,
                weapon_name=weapon_name,
                skin_name=skin_name,
                wear_full=wear_full,
                stattrak=st,
                include_search=False,
            )

            if _priceoverview_fallback_enabled() and _priceoverview_prefer_enabled():
                overview_timestamp = int(datetime.now(timezone.utc).timestamp())
                overview_added = False
                for market_name in market_names:
                    if market_name not in attempted_names:
                        attempted_names.add(market_name)
                        attempted_order.append(market_name)
                    try:
                        overview_payload = fetch_priceoverview(
                            steam_session, market_name
                        )
                    except requests.RequestException as exc:
                        last_request_error = exc
                        continue

                    if not bool(overview_payload.get("success")):
                        continue

                    price_text = str(
                        overview_payload.get("median_price")
                        or overview_payload.get("lowest_price")
                        or ""
                    ).strip()
                    if not price_text:
                        continue

                    try:
                        price_cents = _parse_price_to_cents(price_text)
                    except (TypeError, ValueError):
                        continue

                    volume = _parse_volume(overview_payload.get("volume") or "0")
                    currency = _parse_currency_code(price_text)
                    if currency == DEFAULT_CURRENCY:
                        currency = STEAM_TARGET_CURRENCY_CODE

                    snapshot = {
                        "t": overview_timestamp,
                        "w": wear,
                        "st": st,
                        "p": price_cents,
                        "vol": volume,
                        "ccy": currency,
                    }
                    error = _validate_snapshot(snapshot)
                    if error:
                        continue

                    snapshots.append(snapshot)
                    overview_added = True
                    break

                if overview_added:
                    continue

            for market_name in market_names:
                if market_name not in attempted_names:
                    attempted_names.add(market_name)
                    attempted_order.append(market_name)
                try:
                    payload = fetch_pricehistory(steam_session, market_name)
                except requests.RequestException as exc:
                    last_request_error = exc
                    continue
                prices = payload.get("prices") or []
                if prices:
                    break

            if not prices and _search_fallback_enabled():
                fallback_names = resolve_variant_market_names(
                    steam_session,
                    weapon_name=weapon_name,
                    skin_name=skin_name,
                    wear_full=wear_full,
                    stattrak=st,
                    include_search=True,
                )
                for market_name in fallback_names:
                    if market_name in attempted_names:
                        continue
                    attempted_names.add(market_name)
                    attempted_order.append(market_name)
                    try:
                        payload = fetch_pricehistory(steam_session, market_name)
                    except requests.RequestException as exc:
                        last_request_error = exc
                        continue
                    prices = payload.get("prices") or []
                    if prices:
                        break

            if not prices and _priceoverview_fallback_enabled() and attempted_order:
                overview_timestamp = int(datetime.now(timezone.utc).timestamp())
                overview_added = False
                for market_name in attempted_order:
                    try:
                        overview_payload = fetch_priceoverview(
                            steam_session, market_name
                        )
                    except requests.RequestException as exc:
                        last_request_error = exc
                        continue

                    if not bool(overview_payload.get("success")):
                        continue

                    price_text = str(
                        overview_payload.get("median_price")
                        or overview_payload.get("lowest_price")
                        or ""
                    ).strip()
                    if not price_text:
                        continue

                    try:
                        price_cents = _parse_price_to_cents(price_text)
                    except (TypeError, ValueError):
                        continue

                    volume = _parse_volume(overview_payload.get("volume") or "0")
                    currency = _parse_currency_code(price_text)
                    if currency == DEFAULT_CURRENCY:
                        currency = STEAM_TARGET_CURRENCY_CODE

                    snapshot = {
                        "t": overview_timestamp,
                        "w": wear,
                        "st": st,
                        "p": price_cents,
                        "vol": volume,
                        "ccy": currency,
                    }
                    error = _validate_snapshot(snapshot)
                    if error:
                        continue

                    snapshots.append(snapshot)
                    overview_added = True
                    break

                if overview_added:
                    continue

            if not prices and _playwright_fallback_enabled() and attempted_order:
                for market_name in attempted_order:
                    try:
                        payload = fetch_pricehistory_playwright(
                            steam_session,
                            market_name,
                            country=STEAM_TARGET_COUNTRY,
                            currency=STEAM_TARGET_CURRENCY,
                        )
                    except requests.RequestException as exc:
                        last_request_error = exc
                        continue
                    prices = payload.get("prices") or []
                    if prices:
                        break

            if not prices and last_request_error is not None:
                raise last_request_error

            for row in prices:
                if len(row) < 3:
                    continue
                raw_price = row[1]
                currency = _parse_currency_code(raw_price)
                if currency == DEFAULT_CURRENCY:
                    currency = STEAM_TARGET_CURRENCY_CODE
                snapshot = {
                    "t": _parse_steam_time(str(row[0])),
                    "w": wear,
                    "st": st,
                    "p": _parse_price_to_cents(raw_price),
                    "vol": _parse_volume(row[2]),
                    "ccy": currency,
                }
                error = _validate_snapshot(snapshot)
                if error:
                    raise ValueError(f"Invalid snapshot detected ({error}): {snapshot}")
                snapshots.append(snapshot)

    snapshots.sort(key=lambda value: (value["t"], value["w"], value["st"]))
    return snapshots


def run_full_scrape(
    catalog: dict[str, Any],
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
    prices_dir: str | Path,
    *,
    max_items: Optional[int] = None,
    min_delay: float = 1.0,
    max_delay: float = 2.2,
) -> dict[str, Any]:
    limiter = RateLimiter(min_delay, max_delay)

    processed = 0
    total_written = 0
    empty_items = 0
    errors: list[dict[str, Any]] = []

    for item_key, context in iter_catalog_items(catalog):
        if max_items is not None and processed >= max_items:
            break

        try:
            snapshots = scrape_item_prices(session, item_key, context)
            if not snapshots:
                empty_items += 1
                existing_file = build_price_file_path(item_key, prices_dir)
                if existing_file.exists():
                    append_price_snapshot(
                        item_key,
                        [],
                        prices_dir,
                        item_meta=build_item_meta(item_key, context),
                    )
                processed += 1
                limiter.sleep()
                continue

            result = append_price_snapshot(
                item_key,
                snapshots,
                prices_dir,
                item_meta=build_item_meta(item_key, context),
            )
            total_written += result["written"]
        except Exception as exc:  # pragma: no cover - network behavior varies
            errors.append({"item_key": item_key, "error": str(exc)})

        processed += 1
        limiter.sleep()

    return {
        "processed": processed,
        "written": total_written,
        "empty": empty_items,
        "errors": errors,
    }


def run_incremental_update(
    catalog: dict[str, Any],
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
    prices_dir: str | Path,
) -> dict[str, Any]:
    return run_full_scrape(catalog, session, prices_dir)


def backfill_item_metadata(
    catalog: dict[str, Any],
    prices_dir: str | Path,
) -> dict[str, Any]:
    processed = 0
    updated = 0
    missing_files = 0

    for item_key, context in iter_catalog_items(catalog):
        processed += 1
        file_path = build_price_file_path(item_key, prices_dir)
        if not file_path.exists():
            missing_files += 1
            continue

        result = append_price_snapshot(
            item_key,
            [],
            prices_dir,
            item_meta=build_item_meta(item_key, context),
        )
        if result.get("item_meta_updated"):
            updated += 1

    return {
        "processed": processed,
        "updated": updated,
        "missing_files": missing_files,
    }


def run_iterative_validation_workflow(
    catalog: dict[str, Any],
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
    prices_dir: str | Path,
    *,
    sample_item_key: Optional[str] = None,
) -> dict[str, Any]:
    items = list(iter_catalog_items(catalog))
    if not items:
        raise ValueError("Catalog does not contain items to scrape")

    selected_key, selected_context = items[0]
    if sample_item_key:
        for key, context in items:
            if key == sample_item_key:
                selected_key, selected_context = key, context
                break

    single_snapshots = scrape_item_prices(session, selected_key, selected_context)
    if not single_snapshots:
        raise RuntimeError(
            f"Single-item validation failed for {selected_key}: no snapshots found"
        )
    for row in single_snapshots:
        error = _validate_snapshot(row)
        if error:
            raise ValueError(
                f"Single-item validation failed for {selected_key}: {error}"
            )
    single_result = append_price_snapshot(
        selected_key,
        single_snapshots,
        prices_dir,
        item_meta=build_item_meta(selected_key, selected_context),
    )

    batch_result = run_full_scrape(
        catalog,
        session,
        prices_dir,
        max_items=50,
        min_delay=1.2,
        max_delay=3.0,
    )
    if batch_result["errors"]:
        raise RuntimeError(
            f"Batch-50 validation failed with {len(batch_result['errors'])} errors"
        )

    full_result = run_full_scrape(
        catalog, session, prices_dir, min_delay=1.0, max_delay=2.4
    )

    return {
        "stage_1_single": single_result,
        "stage_2_batch_50": {
            "processed": batch_result["processed"],
            "written": batch_result["written"],
            "empty": batch_result.get("empty", 0),
        },
        "stage_3_full": {
            "processed": full_result["processed"],
            "written": full_result["written"],
            "empty": full_result.get("empty", 0),
        },
    }
