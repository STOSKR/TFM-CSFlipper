from __future__ import annotations

import os
import random
import time
from typing import Any
from urllib.parse import quote

import requests

from core import request_json

STEAM_BASE = "https://steamcommunity.com"
STEAM_MARKET_SEARCH_URL = f"{STEAM_BASE}/market/search/render/"
STEAM_PRICE_HISTORY_URL = f"{STEAM_BASE}/market/pricehistory/"
STEAM_PRICE_OVERVIEW_URL = f"{STEAM_BASE}/market/priceoverview/"

DEFAULT_STEAM_COUNTRY = "DE"
DEFAULT_STEAM_CURRENCY = 3
DEFAULT_STEAM_TIMEOUT_SECONDS = 12
DEFAULT_STEAM_SEARCH_RETRIES = 2
DEFAULT_STEAM_PRICE_RETRIES = 1
STEAM_CURRENCY_ID_TO_CODE: dict[int, str] = {
    1: "USD",
    2: "GBP",
    3: "EUR",
    5: "RUB",
    23: "CNY",
    24: "JPY",
    25: "KRW",
}


def _env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    raw_value = raw.strip()
    if not raw_value:
        return default
    try:
        value = int(raw_value)
    except ValueError:
        return default
    return value if value > 0 else default


def _env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    raw_value = raw.strip()
    if not raw_value:
        return default
    try:
        value = float(raw_value)
    except ValueError:
        return default
    if value < 0:
        return default
    return value


STEAM_TARGET_COUNTRY = (
    str(os.getenv("STEAM_PRICE_HISTORY_COUNTRY", DEFAULT_STEAM_COUNTRY) or "")
    .strip()
    .upper()
    or DEFAULT_STEAM_COUNTRY
)
STEAM_TARGET_CURRENCY = _env_int("STEAM_PRICE_HISTORY_CURRENCY", DEFAULT_STEAM_CURRENCY)
STEAM_TARGET_CURRENCY_CODE = STEAM_CURRENCY_ID_TO_CODE.get(STEAM_TARGET_CURRENCY, "UNK")
STEAM_SEARCH_TIMEOUT_SECONDS = _env_int(
    "STEAM_SEARCH_TIMEOUT_SECONDS", DEFAULT_STEAM_TIMEOUT_SECONDS
)
STEAM_PRICE_TIMEOUT_SECONDS = _env_int(
    "STEAM_PRICE_HISTORY_TIMEOUT_SECONDS", DEFAULT_STEAM_TIMEOUT_SECONDS
)
STEAM_SEARCH_RETRIES = _env_int("STEAM_SEARCH_RETRIES", DEFAULT_STEAM_SEARCH_RETRIES)
STEAM_PRICE_RETRIES = _env_int(
    "STEAM_PRICE_HISTORY_RETRIES", DEFAULT_STEAM_PRICE_RETRIES
)
STEAM_REQUEST_DELAY_MIN_SECONDS = _env_float("STEAM_REQUEST_DELAY_MIN_SECONDS", 0.0)
STEAM_REQUEST_DELAY_MAX_SECONDS = _env_float("STEAM_REQUEST_DELAY_MAX_SECONDS", 0.0)

_LAST_STEAM_REQUEST_AT = 0.0


def _pace_steam_request() -> None:
    global _LAST_STEAM_REQUEST_AT

    min_delay = max(0.0, STEAM_REQUEST_DELAY_MIN_SECONDS)
    max_delay = max(min_delay, STEAM_REQUEST_DELAY_MAX_SECONDS)
    if max_delay <= 0:
        return

    target_gap = random.uniform(min_delay, max_delay)
    now = time.monotonic()
    elapsed = now - _LAST_STEAM_REQUEST_AT
    wait_seconds = target_gap - elapsed
    if wait_seconds > 0:
        time.sleep(wait_seconds)
    _LAST_STEAM_REQUEST_AT = time.monotonic()


def build_steam_session(source: requests.Session | None = None) -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Referer": f"{STEAM_BASE}/market/",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/123.0.0.0 Safari/537.36"
            ),
        }
    )

    if source is not None:
        for cookie in source.cookies:
            session.cookies.set(
                cookie.name,
                cookie.value,
                domain=cookie.domain,
                path=cookie.path or "/",
            )
    return session


def has_steam_login_cookie(session: requests.Session) -> bool:
    for cookie in session.cookies:
        if (cookie.domain or "").endswith(
            "steamcommunity.com"
        ) and cookie.name == "steamLoginSecure":
            return True
    return False


def _request_json_soft(
    session: requests.Session,
    method: str,
    url: str,
    **kwargs: Any,
) -> dict[str, Any]:
    _pace_steam_request()
    try:
        payload = request_json(session, method, url, **kwargs)
        return payload if isinstance(payload, dict) else {}
    except requests.HTTPError as exc:
        status = exc.response.status_code if exc.response is not None else None
        # 400/404 are common for unavailable market names; callers can try alternatives.
        if status in (400, 404):
            return {}
        raise
    except ValueError:
        return {}


def fetch_pricehistory(
    session: requests.Session,
    market_hash_name: str,
) -> dict[str, Any]:
    listing_ref = f"{STEAM_BASE}/market/listings/730/{quote(market_hash_name, safe='')}"
    params: dict[str, Any] = {
        "appid": 730,
        "market_hash_name": market_hash_name,
        "country": STEAM_TARGET_COUNTRY,
        "currency": STEAM_TARGET_CURRENCY,
    }
    return _request_json_soft(
        session,
        "GET",
        STEAM_PRICE_HISTORY_URL,
        params=params,
        headers={"Referer": listing_ref},
        retries=STEAM_PRICE_RETRIES,
        timeout=STEAM_PRICE_TIMEOUT_SECONDS,
    )


def fetch_priceoverview(
    session: requests.Session,
    market_hash_name: str,
) -> dict[str, Any]:
    listing_ref = f"{STEAM_BASE}/market/listings/730/{quote(market_hash_name, safe='')}"
    params: dict[str, Any] = {
        "appid": 730,
        "market_hash_name": market_hash_name,
        "currency": STEAM_TARGET_CURRENCY,
    }
    return _request_json_soft(
        session,
        "GET",
        STEAM_PRICE_OVERVIEW_URL,
        params=params,
        headers={"Referer": listing_ref},
        retries=max(1, STEAM_SEARCH_RETRIES),
        timeout=STEAM_SEARCH_TIMEOUT_SECONDS,
    )


def search_market_hash_names(
    session: requests.Session,
    query: str,
    *,
    count: int = 20,
) -> list[str]:
    payload = _request_json_soft(
        session,
        "GET",
        STEAM_MARKET_SEARCH_URL,
        params={
            "query": query,
            "start": 0,
            "count": max(1, min(count, 50)),
            "search_descriptions": 0,
            "sort_column": "popular",
            "sort_dir": "desc",
            "appid": 730,
            "norender": 1,
        },
        retries=STEAM_SEARCH_RETRIES,
        timeout=STEAM_SEARCH_TIMEOUT_SECONDS,
    )

    names: list[str] = []
    seen: set[str] = set()
    for row in payload.get("results") or []:
        if not isinstance(row, dict):
            continue
        name = str(row.get("hash_name") or row.get("market_hash_name") or "").strip()
        if not name or name in seen:
            continue
        seen.add(name)
        names.append(name)
    return names


def _matches_variant(name: str, wear_full: str, stattrak: int) -> bool:
    lowered = name.lower()
    if f"({wear_full.lower()})" not in lowered:
        return False
    has_stattrak = "stattrak" in lowered
    return has_stattrak if stattrak else not has_stattrak


def resolve_variant_market_names(
    session: requests.Session,
    *,
    weapon_name: str,
    skin_name: str,
    wear_full: str,
    stattrak: int,
    include_search: bool = False,
) -> list[str]:
    base = f"{weapon_name} | {skin_name} ({wear_full})"
    direct = (
        [
            f"StatTrak(TM) {base}",
            f"StatTrak\u2122 {base}",
        ]
        if stattrak
        else [base]
    )

    if not include_search:
        return direct

    discovered = search_market_hash_names(session, f"{weapon_name} | {skin_name}")
    filtered = [
        name for name in discovered if _matches_variant(name, wear_full, stattrak)
    ]

    if not filtered:
        discovered_wear = search_market_hash_names(
            session,
            f"{weapon_name} | {skin_name} ({wear_full})",
        )
        filtered = [
            name
            for name in discovered_wear
            if _matches_variant(name, wear_full, stattrak)
        ]

    ordered: list[str] = []
    seen: set[str] = set()
    for name in [*direct, *filtered]:
        if name in seen:
            continue
        seen.add(name)
        ordered.append(name)
    return ordered
