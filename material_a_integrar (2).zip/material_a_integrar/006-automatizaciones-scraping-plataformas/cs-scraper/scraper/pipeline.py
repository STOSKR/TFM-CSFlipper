from __future__ import annotations

import json
from pathlib import Path

from auth import get_cached_session
from auth.cookie_manager import SESSION_FILE_DEFAULT, load_cookies
from catalog import load_catalog, run_catalog_validation_workflow
from core import session_from_payload
from scraper.price_scraper import run_iterative_validation_workflow


def _load_scraping_session_payload() -> dict:
    try:
        return get_cached_session()
    except RuntimeError:
        # Price scraping only requires captured cookies; CSFloat API validity can
        # expire while Steam cookies remain usable for market pricehistory.
        payload = load_cookies(SESSION_FILE_DEFAULT)
        if not payload.get("cookies"):
            raise
        return payload


def run_development_pipeline(
    catalog_output: str | Path = "data/catalog.json",
    prices_dir: str | Path = "data/prices",
) -> dict:
    # Phase 2/3 must run from captured encrypted cookies without opening manual login.
    session_payload = _load_scraping_session_payload()
    session = session_from_payload(session_payload)

    catalog_report = run_catalog_validation_workflow(
        session_payload, output_path=catalog_output
    )
    catalog = load_catalog(catalog_output)

    prices_report = run_iterative_validation_workflow(catalog, session, prices_dir)

    return {
        "auth": {"status": "validated"},
        "catalog": catalog_report,
        "prices": prices_report,
    }


if __name__ == "__main__":
    report = run_development_pipeline()
    print(json.dumps(report, indent=2))
