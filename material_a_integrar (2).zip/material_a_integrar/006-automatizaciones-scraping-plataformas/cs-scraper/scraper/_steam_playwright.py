from __future__ import annotations

import atexit
import json
import os
from dataclasses import dataclass
from typing import Any
from urllib.parse import quote

import requests

STEAM_BASE = "https://steamcommunity.com"
STEAM_PRICE_HISTORY_URL = f"{STEAM_BASE}/market/pricehistory/"
_DEFAULT_TIMEOUT_MS = 15000


@dataclass
class _PlaywrightBridge:
    playwright: Any
    browser: Any
    context: Any


_BRIDGE: _PlaywrightBridge | None = None


def _env_flag(name: str, default: bool = False) -> bool:
    raw = str(os.getenv(name, "1" if default else "0") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def playwright_pricehistory_fallback_enabled() -> bool:
    return _env_flag("STEAM_ENABLE_PLAYWRIGHT_FALLBACK", False)


def _build_response(status: int) -> requests.Response:
    response = requests.Response()
    response.status_code = int(status)
    response.url = STEAM_PRICE_HISTORY_URL
    return response


def _context_cookie_payload(session: requests.Session) -> list[dict[str, Any]]:
    dedup: dict[tuple[str, str, str], dict[str, Any]] = {}
    for cookie in session.cookies:
        name = str(cookie.name or "").strip()
        value = str(cookie.value or "")
        if not name:
            continue

        domain = (
            str(cookie.domain or "steamcommunity.com").strip() or "steamcommunity.com"
        )
        path = str(cookie.path or "/").strip() or "/"
        key = (name, domain, path)
        dedup[key] = {
            "name": name,
            "value": value,
            "domain": domain,
            "path": path,
            "secure": bool(cookie.secure),
            "httpOnly": False,
        }

    return list(dedup.values())


def _close_bridge() -> None:
    global _BRIDGE
    bridge = _BRIDGE
    _BRIDGE = None
    if bridge is None:
        return

    try:
        bridge.context.close()
    except Exception:
        pass
    try:
        bridge.browser.close()
    except Exception:
        pass
    try:
        bridge.playwright.stop()
    except Exception:
        pass


def _ensure_bridge(session: requests.Session) -> _PlaywrightBridge:
    global _BRIDGE
    if _BRIDGE is None:
        from playwright.sync_api import sync_playwright

        headless = _env_flag("STEAM_PLAYWRIGHT_HEADLESS", True)
        timeout_ms = int(
            max(
                1000,
                float(os.getenv("STEAM_PLAYWRIGHT_TIMEOUT_MS", _DEFAULT_TIMEOUT_MS)),
            )
        )

        playwright = sync_playwright().start()
        browser = playwright.chromium.launch(headless=headless)
        context = browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/123.0.0.0 Safari/537.36"
            )
        )
        context.set_default_timeout(timeout_ms)
        _BRIDGE = _PlaywrightBridge(
            playwright=playwright, browser=browser, context=context
        )
        atexit.register(_close_bridge)

    payload = _context_cookie_payload(session)
    if payload:
        _BRIDGE.context.add_cookies(payload)

    return _BRIDGE


def fetch_pricehistory_playwright(
    session: requests.Session,
    market_hash_name: str,
    *,
    country: str,
    currency: int,
) -> dict[str, Any]:
    bridge = _ensure_bridge(session)
    page = bridge.context.new_page()
    listing_url = f"{STEAM_BASE}/market/listings/730/{quote(market_hash_name, safe='')}"
    query = (
        f"/market/pricehistory/?appid=730&market_hash_name={quote(market_hash_name, safe='')}"
        f"&country={quote(country, safe='')}&currency={int(currency)}"
    )

    try:
        page.goto(listing_url, wait_until="domcontentloaded")
        result = page.evaluate(
            """
            async ({ path }) => {
              try {
                const response = await fetch(path, {
                  credentials: 'include',
                  headers: {
                    'accept': 'application/json, text/javascript, */*; q=0.01',
                    'x-requested-with': 'XMLHttpRequest'
                  }
                });
                const text = await response.text();
                return { status: response.status, ok: response.ok, text };
              } catch (error) {
                return { status: -1, ok: false, error: String(error) };
              }
            }
            """,
            {"path": query},
        )
    finally:
        page.close()

    status = int(result.get("status") or -1)
    if status < 0:
        raise requests.RequestException(
            str(result.get("error") or "Playwright fetch failed")
        )

    if status in (400, 404):
        return {}

    if status == 429:
        raise requests.HTTPError(response=_build_response(status))

    if status >= 400:
        raise requests.HTTPError(response=_build_response(status))

    text = str(result.get("text") or "").strip()
    if not text:
        return {}

    payload = json.loads(text)
    return payload if isinstance(payload, dict) else {}
