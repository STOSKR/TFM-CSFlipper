from __future__ import annotations

import random
import time
from datetime import datetime, timezone
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from typing import Any, Optional

import requests

RETRIABLE_STATUSES = {429, 500, 502, 503, 504}


def _retry_after_seconds(response: requests.Response) -> float:
    raw = str(response.headers.get("Retry-After") or "").strip()
    if not raw:
        return 0.0

    try:
        return max(0.0, float(raw))
    except ValueError:
        pass

    try:
        retry_at = parsedate_to_datetime(raw)
    except (TypeError, ValueError):
        return 0.0

    if retry_at.tzinfo is None:
        retry_at = retry_at.replace(tzinfo=timezone.utc)
    return max(0.0, (retry_at - datetime.now(timezone.utc)).total_seconds())


@dataclass
class RateLimiter:
    min_delay: float = 0.5
    max_delay: float = 1.2

    def sleep(self) -> None:
        if self.max_delay <= 0:
            return
        delay = random.uniform(
            max(0.0, self.min_delay), max(self.min_delay, self.max_delay)
        )
        time.sleep(delay)


def session_from_payload(
    payload: dict[str, Any] | list[dict[str, Any]],
) -> requests.Session:
    if isinstance(payload, list):
        payload = {"cookies": payload}

    base_url = str(payload.get("base_url") or "https://csfloat.com").rstrip("/")
    referer = f"{base_url}/search"

    session = requests.Session()
    session.headers.update(
        {
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            "Origin": base_url,
            "Referer": referer,
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/123.0.0.0 Safari/537.36"
            ),
        }
    )

    authorization = payload.get("authorization")
    if authorization:
        session.headers["Authorization"] = authorization

    for cookie in payload.get("cookies", []):
        name = cookie.get("name")
        value = cookie.get("value")
        if not name or value is None:
            continue
        session.cookies.set(
            name,
            value,
            domain=cookie.get("domain"),
            path=cookie.get("path") or "/",
        )

    return session


def request_json(
    session: requests.Session,
    method: str,
    url: str,
    *,
    params: Optional[dict[str, Any]] = None,
    headers: Optional[dict[str, str]] = None,
    json_body: Optional[dict[str, Any]] = None,
    timeout: int = 30,
    retries: int = 4,
    backoff_seconds: float = 1.5,
) -> dict[str, Any]:
    if retries < 1:
        retries = 1

    last_error: Optional[Exception] = None

    for attempt in range(1, retries + 1):
        try:
            response = session.request(
                method=method.upper(),
                url=url,
                params=params,
                headers=headers,
                json=json_body,
                timeout=timeout,
            )

            if response.status_code in RETRIABLE_STATUSES and attempt < retries:
                wait_seconds = backoff_seconds * attempt + random.uniform(0.2, 1.0)
                if response.status_code == 429:
                    wait_seconds = max(wait_seconds, _retry_after_seconds(response))
                time.sleep(wait_seconds)
                continue

            response.raise_for_status()
            if not response.text.strip():
                return {}
            return response.json()
        except (requests.RequestException, ValueError) as exc:
            last_error = exc
            if attempt >= retries:
                break
            wait_seconds = backoff_seconds * attempt + random.uniform(0.2, 1.0)
            time.sleep(wait_seconds)

    if last_error is None:
        raise RuntimeError("request_json failed without an explicit exception")
    raise last_error
