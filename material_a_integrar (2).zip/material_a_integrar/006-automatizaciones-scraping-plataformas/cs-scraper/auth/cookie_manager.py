from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

import requests
from cryptography.fernet import Fernet, InvalidToken

from ._internals import (
    ensure_parent,
    extract_auth_header,
    load_cookie_key,
    normalize_session_payload,
    now_ts,
)

CSFLOAT_BASE_URL = "https://csfloat.com"
SESSION_FILE_DEFAULT = Path("data/cookies/session.enc.json")
ENV_FILE_DEFAULT = Path(".env")
ENV_KEY_NAME = "CS2_COOKIE_KEY"
VALIDATION_ENDPOINT = "/api/v1/me"
MANUAL_LOGIN_TIMEOUT_SECONDS = 600
REQUEST_TIMEOUT_SECONDS = 20


def request_manual_login(
    base_url: str = CSFLOAT_BASE_URL,
    login_timeout_seconds: int = MANUAL_LOGIN_TIMEOUT_SECONDS,
    headless: bool = False,
    save_path: str | Path | None = None,
) -> dict[str, Any]:
    from playwright.sync_api import sync_playwright

    observed_authorization: list[str] = []

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=headless)
        context = browser.new_context()
        page = context.new_page()
        close_flags = {"page": False, "browser": False}

        def capture_request(request: Any) -> None:
            authorization = request.headers.get("authorization") or request.headers.get(
                "Authorization"
            )
            if authorization:
                observed_authorization.append(authorization)

        def mark_page_closed(_page: Any) -> None:
            close_flags["page"] = True

        def mark_browser_disconnected(_browser: Any) -> None:
            close_flags["browser"] = True

        context.on("request", capture_request)
        page.on("close", mark_page_closed)
        browser.on("disconnected", mark_browser_disconnected)
        page.goto(f"{base_url}/search", wait_until="domcontentloaded")

        print("Complete manual login in the opened browser window.")
        print(
            "After login is detected, close the browser window manually to finish capture."
        )

        deadline = time.time() + login_timeout_seconds
        captured_candidate: dict[str, Any] | None = None
        last_seen_candidate: dict[str, Any] | None = None
        last_checkpoint_at = 0.0

        def page_closed() -> bool:
            if close_flags["page"] or close_flags["browser"]:
                return True
            try:
                if page.is_closed():
                    return True
            except Exception:
                return True
            try:
                if not browser.is_connected():
                    return True
            except Exception:
                return True
            try:
                if len(context.pages) == 0:
                    return True
            except Exception:
                pass
            return False

        while time.time() < deadline:
            if page_closed():
                break

            cookies: list[dict[str, Any]] = []
            local_storage: dict[str, str] = {}
            session_storage: dict[str, str] = {}

            try:
                cookies = context.cookies()
            except Exception:
                cookies = []

            try:
                local_storage = page.evaluate(
                    "() => Object.fromEntries(Object.keys(localStorage).map(k => [k, localStorage.getItem(k)]))"
                )
            except Exception:
                local_storage = {}

            try:
                session_storage = page.evaluate(
                    "() => Object.fromEntries(Object.keys(sessionStorage).map(k => [k, sessionStorage.getItem(k)]))"
                )
            except Exception:
                session_storage = {}

            authorization = (
                observed_authorization[-1]
                if observed_authorization
                else extract_auth_header(local_storage, session_storage)
            )
            candidate = {
                "cookies": cookies,
                "authorization": authorization,
                "storage": {"local": local_storage, "session": session_storage},
                "captured_at": now_ts(),
                "base_url": base_url,
            }
            if cookies:
                last_seen_candidate = candidate

            has_csfloat_cookie = any(
                str(cookie.get("domain") or "").endswith("csfloat.com")
                for cookie in cookies
            )
            now = time.time()
            if (
                save_path is not None
                and has_csfloat_cookie
                and now - last_checkpoint_at >= 3.0
            ):
                try:
                    save_cookies(candidate, save_path)
                    last_checkpoint_at = now
                except Exception:
                    pass

            current_url = page.url.lower()

            # Never force navigation while the user is in the OpenID flow.
            if "steamcommunity.com" in current_url or "openid" in current_url:
                time.sleep(1.5)
                continue

            if "csfloat.com" not in current_url and "csgofloat.com" not in current_url:
                time.sleep(1.5)
                continue

            sign_in_visible = False
            try:
                sign_in_visible = page.locator("button:has-text('Sign in')").count() > 0
            except Exception:
                # During redirects/transitions, locator checks can fail briefly.
                time.sleep(1.5)
                continue

            api_status = -1
            try:
                api_status = page.evaluate(
                    """
                    () => Promise.race([
                      fetch('/api/v1/me', { credentials: 'include' })
                        .then((response) => response.status)
                        .catch(() => -1),
                      new Promise((resolve) => setTimeout(() => resolve(-2), 5000))
                    ])
                    """
                )
            except Exception:
                api_status = -1

            if api_status == 200 or is_session_valid(candidate):
                captured_candidate = candidate
                if save_path is not None:
                    try:
                        save_cookies(candidate, save_path)
                        print(f"Session checkpoint saved to {save_path}.")
                    except Exception as exc:
                        print(f"Warning: could not save session checkpoint: {exc}")
                print("Login detected. Close the browser window to complete capture.")
                break

            if sign_in_visible:
                time.sleep(2)
                continue

            time.sleep(2)

        if (
            captured_candidate is None
            and page_closed()
            and last_seen_candidate is not None
        ):
            captured_candidate = last_seen_candidate
            if save_path is not None:
                try:
                    save_cookies(captured_candidate, save_path)
                    print(
                        f"Browser closed. Saved latest session candidate to {save_path}."
                    )
                except Exception as exc:
                    print(f"Warning: could not save latest session candidate: {exc}")

        if captured_candidate is None:
            try:
                browser.close()
            except Exception:
                pass
            if page_closed():
                raise TimeoutError(
                    "Browser was closed before a valid session was detected"
                )
            raise TimeoutError(
                "Manual login timed out before a valid session was detected"
            )

        while time.time() < deadline:
            if page_closed():
                try:
                    browser.close()
                except Exception:
                    pass
                return captured_candidate
            time.sleep(0.5)

        try:
            browser.close()
        except Exception:
            pass
        # Last-resort safeguard: keep the detected session instead of losing capture
        # when close signals are not propagated reliably in mixed host environments.
        return captured_candidate


def save_cookies(cookies: Any, path: str | Path = SESSION_FILE_DEFAULT) -> Path:
    file_path = Path(path)
    ensure_parent(file_path)

    payload = normalize_session_payload(cookies, base_url=CSFLOAT_BASE_URL)
    key = load_cookie_key(
        key_name=ENV_KEY_NAME, allow_generate=True, env_path=ENV_FILE_DEFAULT
    )

    token = Fernet(key.encode("utf-8")).encrypt(
        json.dumps(payload, separators=(",", ":")).encode("utf-8")
    )
    envelope = {"v": 1, "saved_at": now_ts(), "token": token.decode("utf-8")}
    file_path.write_text(json.dumps(envelope, separators=(",", ":")), encoding="utf-8")
    return file_path


def load_cookies(path: str | Path = SESSION_FILE_DEFAULT) -> dict[str, Any]:
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"Cookie file not found: {file_path}")

    envelope = json.loads(file_path.read_text(encoding="utf-8"))
    token = envelope.get("token")
    if not token:
        raise ValueError("Encrypted cookie file does not contain a token")

    key = load_cookie_key(
        key_name=ENV_KEY_NAME, allow_generate=False, env_path=ENV_FILE_DEFAULT
    )
    decrypted = Fernet(key.encode("utf-8")).decrypt(token.encode("utf-8"))
    payload = json.loads(decrypted.decode("utf-8"))
    return normalize_session_payload(payload, base_url=CSFLOAT_BASE_URL)


def is_session_valid(cookies: Any) -> bool:
    try:
        payload = normalize_session_payload(cookies, base_url=CSFLOAT_BASE_URL)
    except ValueError:
        return False

    session = requests.Session()
    session.headers.update(
        {"Accept": "application/json", "User-Agent": "cs2-scraper/1.0"}
    )

    authorization = payload.get("authorization")
    if authorization:
        session.headers["Authorization"] = authorization

    for cookie in payload["cookies"]:
        name = cookie.get("name")
        value = cookie.get("value")
        if not name or value is None:
            continue
        session.cookies.set(
            name, value, domain=cookie.get("domain"), path=cookie.get("path") or "/"
        )

    base_url = payload.get("base_url") or CSFLOAT_BASE_URL
    try:
        response = session.get(
            f"{base_url}{VALIDATION_ENDPOINT}", timeout=REQUEST_TIMEOUT_SECONDS
        )
        return response.status_code == 200
    except requests.RequestException:
        return False


def get_valid_session(
    path: str | Path = SESSION_FILE_DEFAULT,
    base_url: str = CSFLOAT_BASE_URL,
    login_timeout_seconds: int = MANUAL_LOGIN_TIMEOUT_SECONDS,
    headless: bool = False,
) -> dict[str, Any]:
    file_path = Path(path)
    if file_path.exists():
        try:
            cached = load_cookies(file_path)
            if is_session_valid(cached):
                return cached
        except (
            FileNotFoundError,
            ValueError,
            InvalidToken,
            RuntimeError,
            json.JSONDecodeError,
        ):
            pass

    fresh = request_manual_login(
        base_url=base_url,
        login_timeout_seconds=login_timeout_seconds,
        headless=headless,
        save_path=file_path,
    )
    if is_session_valid(fresh):
        save_cookies(fresh, file_path)
        return fresh

    # Fallback for environments where direct HTTP validation can fail despite
    # a valid browser-authenticated session.
    if fresh.get("cookies"):
        save_cookies(fresh, file_path)
        return fresh

    raise RuntimeError("Manual login completed, but no usable session was captured")
