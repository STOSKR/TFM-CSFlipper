from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Any, Optional

from cryptography.fernet import Fernet


TOKEN_KEY_HINTS = (
    "authorization",
    "api_key",
    "apikey",
    "token",
    "access_token",
    "id_token",
    "refresh_token",
    "jwt",
    "bearer",
)


def now_ts() -> int:
    return int(time.time())


def ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


def read_env_map(env_path: Path) -> dict[str, str]:
    if not env_path.exists():
        return {}

    values: dict[str, str] = {}
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def upsert_env_key(env_path: Path, key_name: str, key_value: str) -> None:
    lines = []
    if env_path.exists():
        lines = env_path.read_text(encoding="utf-8").splitlines()

    pattern = re.compile(rf"^\s*{re.escape(key_name)}\s*=")
    replaced = False
    updated: list[str] = []

    for line in lines:
        if pattern.match(line):
            updated.append(f"{key_name}={key_value}")
            replaced = True
        else:
            updated.append(line)

    if not replaced:
        updated.append(f"{key_name}={key_value}")

    env_path.write_text("\n".join(updated).strip() + "\n", encoding="utf-8")


def validate_fernet_key(key: str, key_name: str) -> None:
    try:
        Fernet(key.encode("utf-8"))
    except Exception as exc:  # pragma: no cover - defensive branch
        raise ValueError(f"{key_name} is not a valid Fernet key") from exc


def _looks_like_token_value(value: str) -> bool:
    if len(value) < 24:
        return False
    if any(char.isspace() for char in value):
        return False

    lowered = value.lower()
    if "://" in lowered or "/" in value or "@" in value:
        return False
    if value.isdigit():
        return False

    jwt_pattern = r"[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}"
    if re.fullmatch(jwt_pattern, value):
        return True

    opaque_pattern = r"[A-Za-z0-9._~-]{24,}"
    if not re.fullmatch(opaque_pattern, value):
        return False

    return any(char.isalpha() for char in value)


def _normalize_auth_candidate(value: str) -> Optional[str]:
    trimmed = value.strip().strip('"').strip("'")
    if not trimmed:
        return None

    if trimmed.lower().startswith("bearer "):
        _, token_value = trimmed.split(" ", 1)
        token_value = token_value.strip()
        if _looks_like_token_value(token_value):
            return f"Bearer {token_value}"
        return None

    if _looks_like_token_value(trimmed):
        return f"Bearer {trimmed}"

    return None


def load_cookie_key(*, key_name: str, allow_generate: bool, env_path: Path) -> str:
    key = os.getenv(key_name)
    if key:
        validate_fernet_key(key, key_name)
        return key

    env_values = read_env_map(env_path)
    key_from_file = env_values.get(key_name)
    if key_from_file:
        validate_fernet_key(key_from_file, key_name)
        os.environ[key_name] = key_from_file
        return key_from_file

    if not allow_generate:
        raise RuntimeError(f"{key_name} is not available in environment or .env")

    generated = Fernet.generate_key().decode("utf-8")
    ensure_parent(env_path)
    upsert_env_key(env_path, key_name, generated)
    os.environ[key_name] = generated
    return generated


def recursive_find_token(value: Any) -> Optional[str]:
    if isinstance(value, str):
        return _normalize_auth_candidate(value)

    if isinstance(value, dict):
        for key in TOKEN_KEY_HINTS:
            if key in value:
                token = recursive_find_token(value[key])
                if token:
                    return token

        for key, nested in value.items():
            lowered = str(key).lower()
            if not any(hint in lowered for hint in TOKEN_KEY_HINTS):
                continue
            token = recursive_find_token(nested)
            if token:
                return token

    if isinstance(value, list):
        for nested in value:
            token = recursive_find_token(nested)
            if token:
                return token

    return None


def extract_auth_header(
    local_storage: dict[str, str], session_storage: dict[str, str]
) -> Optional[str]:
    merged = {**local_storage, **session_storage}
    for raw in merged.values():
        if not raw:
            continue

        token: Optional[str] = None
        try:
            token = recursive_find_token(json.loads(raw))
        except json.JSONDecodeError:
            token = recursive_find_token(raw)

        if not token:
            continue

        return token

    return None


def normalize_session_payload(payload: Any, *, base_url: str) -> dict[str, Any]:
    if isinstance(payload, list):
        payload = {"cookies": payload}

    if not isinstance(payload, dict):
        raise ValueError("Session payload must be a dict or a list of cookies")

    cookies = payload.get("cookies")
    if not isinstance(cookies, list):
        raise ValueError("Session payload must include a 'cookies' list")

    authorization = payload.get("authorization")
    normalized_auth = (
        recursive_find_token(authorization) if isinstance(authorization, str) else None
    )

    return {
        "cookies": cookies,
        "authorization": normalized_auth,
        "storage": payload.get("storage") or {"local": {}, "session": {}},
        "captured_at": int(payload.get("captured_at") or now_ts()),
        "base_url": payload.get("base_url") or base_url,
    }
