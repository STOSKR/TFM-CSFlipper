from __future__ import annotations

from pathlib import Path
from typing import Any

from .cookie_manager import SESSION_FILE_DEFAULT, is_session_valid, load_cookies


def get_cached_session(path: str | Path = SESSION_FILE_DEFAULT) -> dict[str, Any]:
    payload = load_cookies(path)
    if not is_session_valid(payload):
        raise RuntimeError(
            "Cached session is invalid for API access. "
            "Refresh cookies in auth phase before running phase 2/3."
        )
    return payload
