from __future__ import annotations

from pathlib import Path

from cryptography.fernet import Fernet
import pytest

from auth import cookie_manager
from auth import session_cache
from auth import _internals


SAMPLE_SESSION = {
    "cookies": [
        {
            "name": "sessionid",
            "value": "abc123",
            "domain": "csfloat.com",
            "path": "/",
            "secure": True,
            "httpOnly": True,
        }
    ],
    "authorization": "Bearer token_12345678901234567890",
    "storage": {"local": {"token": "token_12345678901234567890"}, "session": {}},
    "captured_at": 1700000000,
    "base_url": "https://csfloat.com",
}


def test_save_and_load_cookies_roundtrip(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv(
        cookie_manager.ENV_KEY_NAME, Fernet.generate_key().decode("utf-8")
    )

    out = tmp_path / "data" / "cookies" / "session.enc.json"
    cookie_manager.save_cookies(SAMPLE_SESSION, out)
    loaded = cookie_manager.load_cookies(out)

    assert loaded["cookies"][0]["name"] == "sessionid"
    assert loaded["authorization"].startswith("Bearer ")
    assert loaded["base_url"] == "https://csfloat.com"


def test_save_generates_env_key_on_first_use(tmp_path: Path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv(cookie_manager.ENV_KEY_NAME, raising=False)

    out = tmp_path / "data" / "cookies" / "session.enc.json"
    cookie_manager.save_cookies(SAMPLE_SESSION, out)

    env_text = (tmp_path / ".env").read_text(encoding="utf-8")
    assert cookie_manager.ENV_KEY_NAME in env_text


def test_get_valid_session_uses_cached_session(tmp_path: Path, monkeypatch) -> None:
    session_file = tmp_path / "data" / "cookies" / "session.enc.json"
    session_file.parent.mkdir(parents=True, exist_ok=True)
    session_file.write_text("{}", encoding="utf-8")

    called = {"manual": False}

    def fake_load(_path):
        return SAMPLE_SESSION

    def fake_manual(**_kwargs):
        called["manual"] = True
        return SAMPLE_SESSION

    monkeypatch.setattr(cookie_manager, "load_cookies", fake_load)
    monkeypatch.setattr(cookie_manager, "request_manual_login", fake_manual)
    monkeypatch.setattr(
        cookie_manager, "is_session_valid", lambda payload: payload is SAMPLE_SESSION
    )

    result = cookie_manager.get_valid_session(path=session_file)

    assert result is SAMPLE_SESSION
    assert called["manual"] is False


def test_get_valid_session_refreshes_invalid_cache(tmp_path: Path, monkeypatch) -> None:
    session_file = tmp_path / "data" / "cookies" / "session.enc.json"
    session_file.parent.mkdir(parents=True, exist_ok=True)
    session_file.write_text("{}", encoding="utf-8")

    old_session = {"cookies": []}
    new_session = {
        "cookies": [
            {"name": "fresh", "value": "1", "domain": "csfloat.com", "path": "/"}
        ],
        "authorization": "Bearer refreshed_token_123456789012345",
        "storage": {"local": {}, "session": {}},
        "captured_at": 1700001111,
        "base_url": "https://csfloat.com",
    }

    saved = {"value": None}

    monkeypatch.setattr(cookie_manager, "load_cookies", lambda _path: old_session)
    monkeypatch.setattr(
        cookie_manager,
        "is_session_valid",
        lambda payload: payload is new_session,
    )
    monkeypatch.setattr(
        cookie_manager, "request_manual_login", lambda **_kwargs: new_session
    )
    monkeypatch.setattr(
        cookie_manager,
        "save_cookies",
        lambda payload, _path: saved.update({"value": payload}),
    )

    result = cookie_manager.get_valid_session(path=session_file)

    assert result is new_session
    assert saved["value"] is new_session


def test_get_cached_session_returns_valid_payload(monkeypatch) -> None:
    monkeypatch.setattr(session_cache, "load_cookies", lambda _path: SAMPLE_SESSION)
    monkeypatch.setattr(
        session_cache, "is_session_valid", lambda payload: payload is SAMPLE_SESSION
    )

    result = session_cache.get_cached_session("data/cookies/session.enc.json")

    assert result is SAMPLE_SESSION


def test_get_cached_session_raises_when_invalid(monkeypatch) -> None:
    monkeypatch.setattr(session_cache, "load_cookies", lambda _path: SAMPLE_SESSION)
    monkeypatch.setattr(session_cache, "is_session_valid", lambda _payload: False)

    with pytest.raises(RuntimeError):
        session_cache.get_cached_session("data/cookies/session.enc.json")


def test_extract_auth_header_ignores_avatar_url_values() -> None:
    local_storage = {
        "user": '{"avatar":"https://avatars.steamstatic.com/avatar_full.jpg"}'
    }
    session_storage = {}

    token = _internals.extract_auth_header(local_storage, session_storage)

    assert token is None


def test_extract_auth_header_reads_access_token_from_json_blob() -> None:
    jwt = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcDEF123_-xyz987"
    local_storage = {"auth": f'{{"access_token":"{jwt}"}}'}
    session_storage = {}

    token = _internals.extract_auth_header(local_storage, session_storage)

    assert token == f"Bearer {jwt}"


def test_normalize_session_payload_drops_invalid_authorization() -> None:
    payload = {
        "cookies": [],
        "authorization": "Bearer https://avatars.steamstatic.com/avatar_full.jpg",
    }

    normalized = _internals.normalize_session_payload(
        payload, base_url="https://csfloat.com"
    )

    assert normalized["authorization"] is None
