from __future__ import annotations

import json
from datetime import date
from typing import Any, Optional

from ._parsing import WEAR_ORDER, WEAPON_BUCKET_MAP, normalize_key
from ._schema import add_entry, count_items, empty_catalog, validate_catalog_structure

WEAR_FLOAT_RANGES: list[tuple[str, float, float]] = [
    ("FN", 0.00, 0.07),
    ("MW", 0.07, 0.15),
    ("FT", 0.15, 0.38),
    ("WW", 0.38, 0.45),
    ("BS", 0.45, 1.00),
]

UNMAPPED_WEAPON_BUCKETS = {
    "zeus x27": "pistol",
    "p2000": "pistol",
    "r8 revolver": "pistol",
}

SCHEMA_SECTION_TO_GROUP = {
    "containers": "cases",
    "agents": "agents",
    "stickers": "stickers",
}

GROUP_PRIORITY = {
    "weapons": 0,
    "knives": 1,
    "gloves": 2,
    "cases": 3,
    "agents": 4,
    "stickers": 5,
}


def _float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _derive_wears(min_float: float, max_float: float) -> list[str]:
    lower = min(min_float, max_float)
    upper = max(min_float, max_float)

    wears: list[str] = []
    for wear, wear_min, wear_max in WEAR_FLOAT_RANGES:
        # Use inclusive overlap to avoid dropping edge-boundary finishes.
        if upper < wear_min or lower > wear_max:
            continue
        wears.append(wear)

    return [wear for wear in WEAR_ORDER if wear in wears]


def _load_item_schema(payload: dict[str, Any]) -> dict[str, Any]:
    storage = payload.get("storage") or {}
    session_storage = storage.get("session") or {}
    raw_schema = session_storage.get("ITEM_SCHEMA_V2")
    if not raw_schema:
        raise ValueError("ITEM_SCHEMA_V2 is missing from captured session storage")

    parsed = json.loads(raw_schema) if isinstance(raw_schema, str) else raw_schema
    schema = parsed.get("schema") if isinstance(parsed, dict) else None
    if not isinstance(schema, dict):
        raise ValueError("ITEM_SCHEMA_V2 does not contain a valid schema object")
    return schema


def _find_weapon_schema(schema: dict[str, Any], weapon_name: str) -> dict[str, Any]:
    weapons = schema.get("weapons") or {}
    target = weapon_name.strip().lower()

    for weapon in weapons.values():
        if not isinstance(weapon, dict):
            continue
        name = str(weapon.get("name") or "").strip().lower()
        if name == target:
            return weapon

    raise ValueError(f"Weapon '{weapon_name}' was not found in ITEM_SCHEMA_V2")


def _build_collection_map(schema: dict[str, Any]) -> dict[str, str]:
    mapping: dict[str, str] = {}
    for row in schema.get("collections") or []:
        if not isinstance(row, dict):
            continue
        key = str(row.get("key") or "").strip()
        if not key:
            continue
        name = str(row.get("name") or key)
        mapping[key] = normalize_key(name)
    return mapping


def _normalize_rarity_key(value: Any) -> str:
    normalized = normalize_key(str(value or "").strip())
    return normalized or "unknown"


def _build_rarity_map(schema: dict[str, Any]) -> dict[Any, str]:
    mapping: dict[Any, str] = {}
    for row in schema.get("rarities") or []:
        if not isinstance(row, dict):
            continue

        rarity_key = _normalize_rarity_key(
            row.get("name") or row.get("key") or row.get("value")
        )

        value = row.get("value")
        if isinstance(value, int):
            mapping[value] = rarity_key
        else:
            try:
                mapping[int(value)] = rarity_key
            except (TypeError, ValueError):
                pass

        key_name = str(row.get("key") or "").strip().lower()
        if key_name:
            mapping[key_name] = rarity_key

    return mapping


def _resolve_rarity_key(raw: Any, rarity_map: dict[Any, str]) -> str | None:
    if isinstance(raw, dict):
        for candidate in (raw.get("name"), raw.get("key"), raw.get("value")):
            resolved = _resolve_rarity_key(candidate, rarity_map)
            if resolved:
                return resolved
        return None

    if isinstance(raw, bool):
        return None

    if isinstance(raw, int):
        return rarity_map.get(raw, f"rarity_{raw}")

    text = str(raw or "").strip()
    if not text:
        return None

    lowered = text.lower()
    if lowered in rarity_map:
        return rarity_map[lowered]

    try:
        parsed_int = int(text)
    except ValueError:
        return _normalize_rarity_key(text)

    return rarity_map.get(parsed_int, f"rarity_{parsed_int}")


def _weapon_group_and_bucket(
    weapon_name: str, weapon_type: str
) -> tuple[str, Optional[str]]:
    lowered_type = weapon_type.lower().strip()
    if lowered_type == "knives":
        return "knives", None
    if lowered_type == "gloves":
        return "gloves", None

    lowered_name = weapon_name.lower().strip()
    bucket = WEAPON_BUCKET_MAP.get(lowered_name) or UNMAPPED_WEAPON_BUCKETS.get(
        lowered_name, "rifle"
    )
    return "weapons", bucket


def _display_weapon_name(name: str, group: str) -> str:
    clean = name.strip()
    if group in {"knives", "gloves"} and not clean.startswith("\u2605"):
        return f"\u2605 {clean}"
    return clean


def _iter_weapon_rows(
    schema: dict[str, Any],
    collection_map: dict[str, str],
    rarity_map: dict[Any, str],
    *,
    target_weapon: Optional[str],
) -> list[dict[str, Any]]:
    target = (target_weapon or "").strip().lower()
    rows: list[dict[str, Any]] = []

    for weapon in (schema.get("weapons") or {}).values():
        if not isinstance(weapon, dict):
            continue

        weapon_name = str(weapon.get("name") or "").strip()
        if not weapon_name:
            continue
        if target and weapon_name.lower() != target:
            continue

        weapon_type = str(weapon.get("type") or "")
        group, bucket = _weapon_group_and_bucket(weapon_name, weapon_type)
        display_name = _display_weapon_name(weapon_name, group)
        weapon_key = normalize_key(weapon_name.replace("\u2605", ""))

        paints = weapon.get("paints") or {}
        if not isinstance(paints, dict):
            continue

        for paint in paints.values():
            if not isinstance(paint, dict):
                continue

            skin_name = str(paint.get("name") or "").strip()
            if not skin_name:
                continue

            collection_keys = paint.get("collections") or []
            col = "unknown"
            if isinstance(collection_keys, list) and collection_keys:
                first_key = str(collection_keys[0])
                col = collection_map.get(first_key, normalize_key(first_key))

            rows.append(
                {
                    "group": group,
                    "bucket": bucket,
                    "weapon_name": display_name,
                    "weapon_key": weapon_key,
                    "skin_key": normalize_key(skin_name),
                    "skin_name": skin_name,
                    "wears": _derive_wears(
                        _float(paint.get("min"), 0.0), _float(paint.get("max"), 1.0)
                    ),
                    "st": bool(paint.get("stattrak")),
                    "col": col,
                    "r": _resolve_rarity_key(paint.get("rarity"), rarity_map),
                }
            )

    return rows


def _iter_simple_section_rows(
    schema: dict[str, Any], section: str
) -> list[dict[str, Any]]:
    group = SCHEMA_SECTION_TO_GROUP[section]
    rows: list[dict[str, Any]] = []

    for payload in (schema.get(section) or {}).values():
        if not isinstance(payload, dict):
            continue

        market_name = str(
            payload.get("market_hash_name") or payload.get("name") or ""
        ).strip()
        if not market_name:
            continue

        key = normalize_key(market_name.replace("\u2605", ""))
        rows.append(
            {
                "group": group,
                "bucket": None,
                "weapon_name": market_name,
                "weapon_key": key,
                "skin_key": key,
                "skin_name": market_name,
                "wears": [],
                "st": False,
                "col": "unknown",
            }
        )

    return rows


def _build_rows_from_schema(
    schema: dict[str, Any],
    *,
    target_weapon: Optional[str],
) -> list[dict[str, Any]]:
    collection_map = _build_collection_map(schema)
    rarity_map = _build_rarity_map(schema)
    rows = _iter_weapon_rows(
        schema,
        collection_map,
        rarity_map,
        target_weapon=target_weapon,
    )

    if not target_weapon:
        for section in SCHEMA_SECTION_TO_GROUP:
            rows.extend(_iter_simple_section_rows(schema, section))

    dedup: dict[tuple[str, str, str, str], dict[str, Any]] = {}
    for row in rows:
        identity = (
            row["group"],
            str(row.get("bucket") or ""),
            row["weapon_key"],
            row["skin_key"],
        )
        if identity not in dedup:
            dedup[identity] = row

    return sorted(
        dedup.values(),
        key=lambda row: (
            GROUP_PRIORITY.get(row["group"], 99),
            str(row.get("bucket") or ""),
            row["weapon_key"],
            row["skin_key"],
        ),
    )


def build_catalog_from_schema(
    payload: dict[str, Any],
    *,
    target_weapon: Optional[str] = None,
    max_items: Optional[int] = None,
) -> dict[str, Any]:
    schema = _load_item_schema(payload)
    rows = _build_rows_from_schema(schema, target_weapon=target_weapon)
    if max_items is not None:
        rows = rows[:max_items]

    catalog = empty_catalog()
    for row in rows:
        wears = row.get("wears") or []
        for wear in wears or [None]:
            add_entry(
                catalog,
                {
                    "group": row["group"],
                    "bucket": row["bucket"],
                    "weapon_name": row["weapon_name"],
                    "weapon_key": row["weapon_key"],
                    "skin_key": row["skin_key"],
                    "skin_name": row.get("skin_name"),
                    "wear": wear,
                    "st": row["st"],
                    "col": row["col"],
                    "r": row.get("r"),
                },
            )

    catalog["meta"]["updated"] = date.today().isoformat()
    catalog["meta"]["total_items"] = count_items(catalog)

    errors = validate_catalog_structure(catalog)
    if errors:
        raise ValueError("Catalog validation failed: " + "; ".join(errors[:5]))
    return catalog


def build_weapon_catalog_from_schema(
    payload: dict[str, Any],
    *,
    weapon_name: str,
    max_items: Optional[int] = None,
) -> dict[str, Any]:
    schema = _load_item_schema(payload)
    _find_weapon_schema(schema, weapon_name)
    return build_catalog_from_schema(
        payload,
        target_weapon=weapon_name,
        max_items=max_items,
    )
