from __future__ import annotations

import gzip
import json
import os
from datetime import date
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import urlencode

import requests

from core import RateLimiter, request_json, session_from_payload

from ._parsing import (
    DEFAULT_CATEGORIES,
    parse_listing_entry,
)
from ._schema_source import build_catalog_from_schema
from ._schema import (
    add_entry,
    count_items,
    empty_catalog,
    iter_catalog_items,
    validate_catalog_structure,
)


def _ensure_session(
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
) -> requests.Session:
    if isinstance(session, requests.Session):
        return session
    return session_from_payload(session)


def _sync_session_cookies(
    session: requests.Session, browser_cookies: list[dict[str, Any]]
) -> None:
    for cookie in browser_cookies:
        name = cookie.get("name")
        value = cookie.get("value")
        if not name or value is None:
            continue
        session.cookies.set(
            name,
            value,
            domain=cookie.get("domain") or "csfloat.com",
            path=cookie.get("path") or "/",
        )


def _fetch_json_with_browser(
    session: requests.Session,
    url: str,
    *,
    params: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    from playwright.sync_api import sync_playwright

    query = urlencode(params or {}, doseq=True)
    target_url = f"{url}?{query}" if query else url
    authorization = session.headers.get("Authorization")
    referer = str(session.headers.get("Referer") or "https://csfloat.com/search")

    cookie_payload: list[dict[str, Any]] = []
    for cookie in session.cookies:
        cookie_payload.append(
            {
                "name": cookie.name,
                "value": cookie.value,
                "domain": cookie.domain or "csfloat.com",
                "path": cookie.path or "/",
            }
        )

    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=True)
        context = browser.new_context()
        if cookie_payload:
            context.add_cookies(cookie_payload)
        page = context.new_page()
        page.goto(referer, wait_until="domcontentloaded")

        result = page.evaluate(
            """
            async ({ targetUrl, auth }) => {
              try {
                const headers = auth ? { Authorization: auth } : {};
                const response = await fetch(targetUrl, {
                  credentials: 'include',
                  headers,
                });
                return {
                  status: response.status,
                  text: await response.text(),
                };
              } catch {
                return { status: -1, text: '' };
              }
            }
            """,
            {"targetUrl": target_url, "auth": authorization},
        )

        _sync_session_cookies(session, context.cookies())
        browser.close()

    status = int(result.get("status", -1))
    if status < 200 or status >= 300:
        raise requests.HTTPError(
            f"Browser fetch failed with status {status}: {target_url}"
        )

    text = str(result.get("text") or "").strip()
    return json.loads(text) if text else {}


def _entry_identity(entry: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        str(entry.get("group") or ""),
        str(entry.get("bucket") or ""),
        str(entry.get("weapon_key") or ""),
        str(entry.get("skin_key") or ""),
    )


def _payload_has_item_schema(payload: dict[str, Any]) -> bool:
    storage = payload.get("storage") or {}
    session_storage = storage.get("session") or {}
    return bool(session_storage.get("ITEM_SCHEMA_V2"))


def scrape_category(
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
    category: Optional[str] = None,
    *,
    page_size: int = 50,
    max_pages: int = 20,
    max_items: Optional[int] = None,
    limiter: Optional[RateLimiter] = None,
) -> list[dict[str, Any]]:
    session_obj = _ensure_session(session)
    limiter = limiter or RateLimiter(0.6, 1.2)
    use_category_filter = os.getenv(
        "CSFLOAT_USE_CATEGORY_FILTER", "0"
    ).strip().lower() in {"1", "true", "yes"}

    api_base = os.getenv("CSFLOAT_API_BASE", "https://csfloat.com/api/v1").rstrip("/")
    endpoint = os.getenv("CSFLOAT_LISTINGS_ENDPOINT", "/listings")
    url = f"{api_base}{endpoint}"

    raw_extra_params = os.getenv(
        "CSFLOAT_LISTINGS_PARAMS",
        '{"type":"buy_now","sort_by":"most_recent"}',
    )
    try:
        extra_params = json.loads(raw_extra_params)
    except json.JSONDecodeError:
        extra_params = {}

    parsed: list[dict[str, Any]] = []
    seen_entries: set[tuple[str, str, str, str]] = set()
    for page in range(1, max_pages + 1):
        params = {
            "limit": page_size,
            "page": page,
            **extra_params,
        }
        if category and use_category_filter:
            params["category"] = category

        try:
            payload = request_json(session_obj, "GET", url, params=params, retries=8)
        except requests.HTTPError as exc:
            if exc.response is None or exc.response.status_code != 403:
                raise
            payload = _fetch_json_with_browser(session_obj, url, params=params)

        rows = payload.get("data") or payload.get("listings") or []
        if not rows:
            break

        for row in rows:
            forced_bucket = category if category and use_category_filter else None
            entry = parse_listing_entry(row, forced_bucket=forced_bucket)
            if entry:
                entry_id = _entry_identity(entry)
                if entry_id in seen_entries:
                    continue
                seen_entries.add(entry_id)
                parsed.append(entry)
            if max_items and len(parsed) >= max_items:
                return parsed

        if len(rows) < page_size:
            break
        limiter.sleep()

    return parsed


def build_full_catalog(
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
    *,
    categories: Optional[Iterable[str]] = None,
    target_weapon: Optional[str] = None,
    max_pages_per_category: int = 20,
    page_size: int = 50,
    max_items: Optional[int] = None,
    min_delay: float = 0.6,
    max_delay: float = 1.2,
) -> dict[str, Any]:
    effective_target_weapon = (
        target_weapon or os.getenv("CSFLOAT_TARGET_WEAPON") or ""
    ).strip()
    if isinstance(session, dict) and _payload_has_item_schema(session):
        return build_catalog_from_schema(
            session,
            target_weapon=effective_target_weapon or None,
            max_items=max_items,
        )

    if effective_target_weapon:
        raise ValueError(
            "Target-weapon catalog mode requires a session payload dict with storage data"
        )

    use_category_filter = os.getenv(
        "CSFLOAT_USE_CATEGORY_FILTER", "0"
    ).strip().lower() in {"1", "true", "yes"}

    limiter = RateLimiter(min_delay, max_delay)
    catalog = empty_catalog()
    requested_categories = list(categories or DEFAULT_CATEGORIES)
    active_categories: list[Optional[str]] = (
        requested_categories if use_category_filter else [None]
    )

    collected = 0
    for category in active_categories:
        remaining = None if max_items is None else max(0, max_items - collected)
        if remaining == 0:
            break

        entries = scrape_category(
            session,
            category,
            page_size=page_size,
            max_pages=max_pages_per_category,
            max_items=remaining,
            limiter=limiter,
        )
        for entry in entries:
            add_entry(catalog, entry)
        collected += len(entries)

    catalog["meta"]["updated"] = date.today().isoformat()
    catalog["meta"]["total_items"] = count_items(catalog)

    errors = validate_catalog_structure(catalog)
    if errors:
        raise ValueError("Catalog validation failed: " + "; ".join(errors[:5]))
    return catalog


def save_catalog(
    catalog: dict[str, Any], path: str | Path, compress: bool = False
) -> Path:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    encoded = json.dumps(catalog, separators=(",", ":"), ensure_ascii=False).encode(
        "utf-8"
    )
    if compress or file_path.suffix == ".gz":
        with gzip.open(file_path, "wb") as stream:
            stream.write(encoded)
    else:
        file_path.write_bytes(encoded)
    return file_path


def load_catalog(path: str | Path) -> dict[str, Any]:
    file_path = Path(path)
    raw = (
        gzip.open(file_path, "rb").read()
        if file_path.suffix == ".gz"
        else file_path.read_bytes()
    )
    catalog = json.loads(raw.decode("utf-8"))
    if catalog.get("v") != 1:
        raise ValueError(f"Unsupported catalog version: {catalog.get('v')}")

    errors = validate_catalog_structure(catalog)
    if errors:
        raise ValueError("Catalog structure is invalid: " + "; ".join(errors[:5]))
    return catalog


def run_catalog_validation_workflow(
    session: requests.Session | dict[str, Any] | list[dict[str, Any]],
    output_path: str | Path = "data/catalog.json",
    *,
    target_weapon: Optional[str] = None,
) -> dict[str, Any]:
    output = Path(output_path)
    effective_target_weapon = (
        target_weapon or os.getenv("CSFLOAT_TARGET_WEAPON") or ""
    ).strip() or None

    single_catalog = build_full_catalog(
        session,
        max_items=1,
        target_weapon=effective_target_weapon,
        max_pages_per_category=2,
        min_delay=0.8,
        max_delay=1.4,
    )
    if single_catalog["meta"]["total_items"] < 1:
        raise RuntimeError("Stage 1 catalog validation failed: no items captured")
    save_catalog(single_catalog, output.with_name("catalog.single.json"))

    batch_catalog = build_full_catalog(
        session,
        max_items=50,
        target_weapon=effective_target_weapon,
        max_pages_per_category=40,
        min_delay=1.2,
        max_delay=3.0,
    )
    if batch_catalog["meta"]["total_items"] < 50:
        raise RuntimeError(
            "Stage 2 catalog validation failed: fewer than 50 unique items captured"
        )
    save_catalog(batch_catalog, output.with_name("catalog.batch50.json"))

    full_catalog = build_full_catalog(
        session,
        target_weapon=effective_target_weapon,
        max_pages_per_category=50,
        min_delay=0.8,
        max_delay=1.8,
    )
    save_catalog(full_catalog, output)

    return {
        "stage_1_single": single_catalog["meta"]["total_items"],
        "stage_2_batch_50": batch_catalog["meta"]["total_items"],
        "stage_3_full": full_catalog["meta"]["total_items"],
        "output": str(output),
    }
