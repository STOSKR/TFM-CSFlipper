"""
Worker implementations for Producer-Consumer pattern.
Handles item processing, queue management, and storage operations.
"""

import asyncio
import random
from typing import List, Dict, Optional, Callable, Awaitable
from playwright.async_api import Page, TimeoutError as PlaywrightTimeout

from app.core.logger import get_logger
from app.core.config import Settings
from app.domain.models import ScrapedItem
from app.services.extractors import ItemExtractor, DetailedItemExtractor
from app.services.storage import StorageService

logger = get_logger(__name__)


class Producer:
    """Productor que extrae items de la tabla principal y alimenta la cola."""

    def __init__(self, extractor: ItemExtractor, exclusion_filters: List[str]):
        self.extractor = extractor
        self.filters = exclusion_filters or []

    async def run(
        self,
        page: Page,
        url: str,
        queue: asyncio.Queue,
        limit: Optional[int],
        worker_count: int,
    ) -> int:
        """Extrae items y los pone en la cola."""
        logger.info("producer_started", url=url)

        try:
            # Extraemos items crudos de la tabla
            raw_items = await self.extractor.extract_items(page, url, limit)

            count = 0
            for item in raw_items:
                # Aplicar filtros de exclusión extra si es necesario
                if any(f in item["item_name"] for f in self.filters):
                    logger.debug("item_filtered_producer", item=item["item_name"])
                    continue

                await queue.put(item)
                count += 1

            # Señal de fin para cada consumidor
            for _ in range(worker_count):
                await queue.put(None)

            logger.info("producer_finished", items_queued=count)
            return count

        except Exception as e:
            logger.error("producer_failed", error=str(e))
            # En caso de error, aseguramos que los consumers no se queden colgados
            for _ in range(worker_count):
                await queue.put(None)
            return 0


class ScraperWorker:
    """Consumidor que procesa cada item en detalle (Buff + Steam)."""

    def __init__(
        self,
        settings: Settings,
        extractor: DetailedItemExtractor,
        storage_service: Optional[StorageService],
        buff_page: Page,
        steam_page: Page,
    ):
        self.settings = settings
        self.extractor = extractor
        self.storage = storage_service
        self.buff_page = buff_page
        self.steam_page = steam_page

    async def run(
        self,
        worker_id: int,
        input_queue: asyncio.Queue,
        storage_queue: Optional[asyncio.Queue],
        results_list: List[ScrapedItem],
        discarded_list: List[Dict],
        total_items: int,
        progress_callback: Optional[Callable[[], Awaitable[None]]] = None,
    ):
        logger.info("worker_started", worker_id=worker_id)
        processed_count = 0

        while True:
            item_data = await input_queue.get()

            # Señal de parada
            if item_data is None:
                input_queue.task_done()
                break

            try:
                # Procesamiento detallado
                result_data = await self.extractor.extract_detailed_item(
                    page=None,  # No usamos la pagina principal aqui
                    item=item_data,
                    buff_page=self.buff_page,
                    steam_page=self.steam_page,
                    worker_id=worker_id,
                )

                if result_data:
                    if result_data.get("discarded"):
                        discarded_list.append(result_data)
                    else:
                        # Convertir a modelo Pydantic
                        model = ScrapedItem(**result_data)
                        results_list.append(model)

                        # Enviar a cola de guardado si existe
                        if storage_queue:
                            await storage_queue.put(model)

                # Delay entre items para evitar bloqueos
                delay = self.settings.delay_between_items
                if delay > 0:
                    await asyncio.sleep(delay / 1000.0)

            except Exception as e:
                logger.error(
                    "worker_item_failed",
                    worker_id=worker_id,
                    item=item_data.get("item_name"),
                    error=str(e),
                )

            finally:
                input_queue.task_done()
                processed_count += 1

                # Actualizar progreso visual
                if progress_callback:
                    try:
                        if asyncio.iscoroutinefunction(progress_callback):
                            await progress_callback()
                        else:
                            progress_callback()
                    except Exception:
                        pass

        logger.info(
            "worker_finished", worker_id=worker_id, total_processed=processed_count
        )


class StorageWorker:
    """Worker dedicado a guardar en BD asíncronamente."""

    def __init__(self, service: StorageService):
        self.service = service
        self.batch_size = 10

    async def run(self, worker_id: int, queue: asyncio.Queue):
        logger.info("storage_worker_started", worker_id=worker_id)
        batch = []

        while True:
            item = await queue.get()

            # Señal de parada
            if item is None:
                # Guardar remanente
                if batch:
                    await self.service.save_items(batch)
                queue.task_done()
                break

            batch.append(item)

            if len(batch) >= self.batch_size:
                await self.service.save_items(batch)
                batch = []

            queue.task_done()

        logger.info("storage_worker_finished", worker_id=worker_id)
