"""File saving utilities for scraper."""

from datetime import datetime
from pathlib import Path
from playwright.async_api import Page

from app.core.logger import get_logger
from app.core.config import Settings

logger = get_logger(__name__)


class FileSaver:
    """Manages file saving for scraper."""

    def __init__(self, settings: Settings):
        self.settings = settings
        self.output_dir = Path(settings.output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def _get_path(self, prefix: str, ext: str, filename: str = None) -> Path:
        """Helper to generate consistent file paths."""
        if filename:
            return self.output_dir / filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return self.output_dir / f"{prefix}_{timestamp}.{ext}"

    async def save_debug_files(self, page: Page):
        """Save both screenshot and HTML if enabled."""
        if not self.settings.save_debug_info:
            return

        try:
            if self.settings.save_screenshot:
                await self.save_screenshot(page)

            if self.settings.save_html:
                await self.save_html(page)

        except Exception as e:
            logger.warning("debug_files_save_failed", error=str(e))

    async def save_screenshot(self, page: Page, filename: str = None) -> str | None:
        """Save a screenshot of the current page."""
        if not self.settings.save_screenshot:
            return None

        path = self._get_path("screenshot", "png", filename)

        try:
            await page.screenshot(path=str(path), full_page=True)
            logger.info("screenshot_saved", path=str(path))
            return str(path)
        except Exception as e:
            logger.warning("screenshot_save_failed", error=str(e))
            return None

    async def save_html(self, page: Page, filename: str = None) -> str | None:
        """Save HTML content of the current page."""
        if not self.settings.save_html:
            return None

        path = self._get_path("page_content", "html", filename)

        try:
            content = await page.content()
            path.write_text(content, encoding="utf-8")
            logger.info("html_saved", path=str(path))
            return str(path)
        except Exception as e:
            logger.warning("html_save_failed", error=str(e))
            return None
