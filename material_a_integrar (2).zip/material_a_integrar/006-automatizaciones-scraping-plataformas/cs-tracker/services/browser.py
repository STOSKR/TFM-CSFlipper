"""Browser manager for Playwright."""

from playwright.async_api import async_playwright, Browser, BrowserContext, Page
from typing import Optional, List, Dict
import json
from pathlib import Path

from app.core.logger import get_logger

logger = get_logger(__name__)


class BrowserManager:
    """Manages Playwright browser lifecycle."""

    def __init__(self, headless: bool = True, storage_state_path: Optional[str] = None):
        self.headless = headless
        self.storage_state_path = storage_state_path
        self.playwright = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None

    async def __aenter__(self):
        await self.start()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    async def start(self):
        """Initializes the browser session."""
        self.playwright = await async_playwright().start()

        launch_args = [
            "--disable-blink-features=AutomationControlled",
            "--disable-dev-shm-usage",
            "--no-sandbox",
            "--disable-setuid-sandbox",
        ]

        self.browser = await self.playwright.chromium.launch(
            headless=self.headless,
            channel="chrome",
            args=launch_args,
        )

        # Context configuration
        context_options = {
            "viewport": {"width": 1920, "height": 1080},
            "user_agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "ignore_https_errors": True,
            "java_script_enabled": True,
        }

        if self.storage_state_path and Path(self.storage_state_path).exists():
            context_options["storage_state"] = self.storage_state_path
            logger.info("browser_starting_with_cookies", path=self.storage_state_path)
        else:
            logger.info("browser_starting_clean")

        self.context = await self.browser.new_context(**context_options)
        self.page = await self.context.new_page()

        # Anti-detection measure
        await self.page.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', { get: () => undefined });"
        )

    async def close(self):
        """Closes all browser resources safely."""
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
        logger.debug("browser_resources_released")

    async def navigate(self, url: str, timeout: int = 60000):
        """Navigates to URL with smart waiting."""
        if not self.page:
            raise RuntimeError("Browser not started")

        logger.info("navigating", url=url)
        try:
            await self.page.goto(url, wait_until="domcontentloaded", timeout=timeout)
            # networkidle a veces es muy lento en sitios complejos, domcontentloaded es más ágil
        except Exception as e:
            logger.error("navigation_failed", url=url, error=str(e))
            raise

    async def save_storage_state(self, path: str):
        """Saves current cookies/storage to file."""
        if not self.context:
            return

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        await self.context.storage_state(path=str(p))
        logger.info("storage_state_saved", path=path)

    def get_page(self) -> Page:
        if not self.page:
            raise RuntimeError("Browser not started")
        return self.page
