"""Session management utilities for browser automation."""

import json
from pathlib import Path
from typing import Optional

from app.core.logger import get_logger

logger = get_logger(__name__)


class SessionManager:
    """Manages browser session loading and merging."""

    def __init__(self, sessions_dir: Path = Path("sessions")):
        self.sessions_dir = sessions_dir
        self.buff_path = sessions_dir / "buff_session.json"
        self.steam_path = sessions_dir / "steam_session.json"
        self.merged_path = sessions_dir / "merged_session.json"

    def get_storage_state_path(self) -> Optional[str]:
        """Get path to merged storage state file, or None if no sessions exist."""
        if not (self.buff_path.exists() or self.steam_path.exists()):
            logger.info("no_sessions_found", msg="Starting without cookies")
            return None

        return self._merge_sessions()

    def _merge_sessions(self) -> str:
        """Combines Buff and Steam cookies into one file."""
        merged_state = {"cookies": [], "origins": []}

        for path, name in [(self.buff_path, "buff"), (self.steam_path, "steam")]:
            if path.exists():
                try:
                    data = json.loads(path.read_text(encoding="utf-8"))
                    cookies = data.get("cookies", [])
                    merged_state["cookies"].extend(cookies)
                    merged_state["origins"].extend(data.get("origins", []))
                    logger.debug(f"loaded_{name}_session", count=len(cookies))
                except Exception as e:
                    logger.warning(f"failed_loading_{name}", error=str(e))

        self.merged_path.parent.mkdir(parents=True, exist_ok=True)

        with open(self.merged_path, "w", encoding="utf-8") as f:
            json.dump(merged_state, f, ensure_ascii=False)

        logger.info("sessions_merged", total_cookies=len(merged_state["cookies"]))
        return str(self.merged_path)
