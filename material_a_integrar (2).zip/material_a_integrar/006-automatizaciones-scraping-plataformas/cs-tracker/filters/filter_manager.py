"""
Filter manager for web scraping configuration.
Manages all search filter configuration on the web interface.
"""

from playwright.async_api import Page
from typing import Optional

from app.core.logger import get_logger
from app.core.config import Settings
from app.core.constants import (
    FILTER_MODAL_CLOSE_WAIT,
    FILTER_DROPDOWN_OPEN_WAIT,
    FILTER_CURRENCY_RELOAD_WAIT,
    FILTER_TAB_SWITCH_WAIT,
    FILTER_INPUT_READY_WAIT,
    FILTER_PLATFORM_OPEN_WAIT,
    FILTER_SEARCH_EXECUTE_WAIT,
)

logger = get_logger(__name__)


class FilterManager:
    """Manages search filter configuration on scraping page."""

    def __init__(self, settings: Settings):
        self.settings = settings

    async def configure_all_filters(self, page: Page):
        """Configure all search filters."""
        logger.info("configuring_search_filters")

        # 1. Cerrar modal si aparece
        await self._close_modal(page)

        # 2. Configure currency
        await self._configure_currency(page)

        # 3. Configure balance type (CRÍTICO: HACER ESTO ANTES DE LOS MODOS)
        # Esto desbloquea las opciones de "Sell at Platform" / "Buy via Steam"
        await self._configure_balance_type(page)

        # 4. Configure sell mode
        await self._configure_sell_mode(page)

        # 5. Configure buy mode (if applicable)
        await self._configure_buy_mode(page)

        # 6. Configure price and volume filters
        await self._configure_price_volume_filters(page)

        # 7. Configure platforms
        await self._configure_platforms(page)

        # 8. Execute search
        await self._execute_search(page)

        logger.info("filter_configuration_completed")

    async def _click_tab_by_text(self, page: Page, full_text: str, context_name: str):
        """Helper robusto para encontrar y clickar pestañas."""
        logger.info(f"checking_{context_name}", mode=full_text)

        # 1. Intento Exacto
        tab = page.locator(f'.tabs-item:has-text("{full_text}")').first
        if await tab.count() > 0:
            await self._process_click(page, tab, full_text, context_name)
            return

        # 2. Intento Parcial (Keywords clave)
        keywords = []
        if "Buy Order" in full_text:
            keywords.append("Buy Order")
        elif "Lowest Price" in full_text:
            keywords.append("Lowest Price")

        for keyword in keywords:
            candidates = await page.locator(f'.tabs-item:has-text("{keyword}")').all()
            for candidate in candidates:
                txt = await candidate.inner_text()
                if keyword in txt and (
                    ("STEAM" in full_text and "STEAM" in txt)
                    or ("Platform" in full_text and "Platform" in txt)
                ):
                    logger.info(
                        f"fuzzy_match_found_for_{context_name}",
                        target=full_text,
                        found=txt,
                    )
                    await self._process_click(page, candidate, full_text, context_name)
                    return

        # 3. Fallo: Listar opciones disponibles para debug
        logger.warning(f"{context_name}_not_found", target=full_text)
        try:
            all_tabs = await page.locator(".tabs-item").all_inner_texts()
            logger.warning("available_tabs_are", tabs=all_tabs)
        except Exception:
            pass

    async def _process_click(self, page, tab, mode_name, context_name):
        """Ejecuta el click verificando si ya está activo."""
        try:
            tab_class = await tab.get_attribute("class")
            if "active" not in tab_class:
                await tab.click()
                await page.wait_for_timeout(FILTER_TAB_SWITCH_WAIT)
                logger.info(f"{context_name}_selected", mode=mode_name)
            else:
                logger.info(f"{context_name}_already_selected", mode=mode_name)
        except Exception as e:
            logger.error(f"{context_name}_click_failed", error=str(e))

    async def _close_modal(self, page: Page):
        """Close initial modal if it appears."""
        try:
            logger.info("checking_for_modal")
            await page.wait_for_timeout(1000)

            close_selectors = [
                ".el-dialog__headerbtn",
                "button[aria-label='Close']",
                'button:has-text("我已知晓")',
                'button:has-text("我知道了")',
                'button:has-text("I understand")',
                'button:has-text("OK")',
                ".el-overlay-dialog .el-button",
            ]

            for selector in close_selectors:
                elements = await page.locator(selector).all()
                for element in elements:
                    if await element.is_visible():
                        logger.info("modal_found_closing", selector=selector)
                        await element.click(force=True)
                        await page.wait_for_timeout(FILTER_MODAL_CLOSE_WAIT)
                        return

            overlay = page.locator(".el-overlay").first
            if await overlay.is_visible():
                await overlay.click(position={"x": 10, "y": 10}, force=True)
                await page.wait_for_timeout(500)

            logger.info("no_modal_blocking_found")
        except Exception as e:
            logger.warning("modal_handling_warning", error=str(e))

    async def _configure_currency(self, page: Page):
        """Configure currency filter."""
        try:
            currency = self.settings.currency_code
            await self._change_currency(page, currency)
        except Exception as e:
            logger.warning("currency_configuration_error", error=str(e))

    async def _change_currency(self, page: Page, currency_code: str = "EUR"):
        """Change currency on the page."""
        try:
            logger.info("changing_currency", target=currency_code)
            await page.wait_for_timeout(500)

            selectors = [
                ".el-dropdown-link",
                "[class*='currency']",
                "[class*='dropdown']",
            ]
            currency_selector = None
            for selector in selectors:
                locator = page.locator(selector).first
                if await locator.count() > 0:
                    currency_selector = locator
                    logger.info("currency_selector_found", selector=selector)
                    break

            if currency_selector:
                await currency_selector.click()
                await page.wait_for_timeout(FILTER_DROPDOWN_OPEN_WAIT)
                currency_option = page.locator(f'li:has-text("{currency_code}")')

                if await currency_option.count() > 0:
                    await currency_option.first.click()
                    logger.info("currency_changed", currency=currency_code)
                    await page.wait_for_timeout(FILTER_CURRENCY_RELOAD_WAIT)
                else:
                    logger.warning("currency_option_not_found", currency=currency_code)
                    await page.keyboard.press("Escape")
            else:
                logger.warning("currency_selector_not_found")

        except Exception as e:
            logger.warning("currency_change_failed", error=str(e))

    async def _configure_sell_mode(self, page: Page):
        """Configure sell mode filter."""
        sell_mode = getattr(self.settings, "sell_mode", "Lowest Price")
        await self._click_tab_by_text(page, sell_mode, "sell_mode")

    async def _configure_buy_mode(self, page: Page):
        """Configure buy mode filter."""
        buy_mode = getattr(self.settings, "buy_mode", None)
        if buy_mode:
            await self._click_tab_by_text(page, buy_mode, "buy_mode")
        else:
            logger.info("no_buy_mode_configured_skipping")

    async def _configure_balance_type(self, page: Page):
        """Configure balance type filter."""
        balance_type = getattr(self.settings, "balance_type", "BUFF-STEAM")
        await self._click_tab_by_text(page, balance_type, "balance_type")

    async def _configure_price_volume_filters(self, page: Page):
        """Configure price and volume filters."""
        try:
            min_price = self.settings.min_price
            max_price = self.settings.max_price
            min_volume = self.settings.min_volume

            await page.wait_for_timeout(FILTER_INPUT_READY_WAIT)
            filter_inputs = await page.locator(
                ".el-input__inner:not(#searchInput)"
            ).all()
            logger.info("filter_inputs_found", count=len(filter_inputs))

            if min_price is not None and len(filter_inputs) >= 1:
                await filter_inputs[0].fill(str(min_price))
                logger.info("min_price_set", value=min_price)

            if max_price is not None and len(filter_inputs) >= 2:
                await filter_inputs[1].fill(str(max_price))
                logger.info("max_price_set", value=max_price)

            if min_volume is not None:
                volume_idx = 2
                if len(filter_inputs) > volume_idx:
                    await filter_inputs[volume_idx].fill(str(min_volume))
                    logger.info("min_volume_set", value=min_volume)

            await page.wait_for_timeout(FILTER_INPUT_READY_WAIT)
        except Exception as e:
            logger.warning("price_volume_filters_error", error=str(e))

    async def _configure_platforms(self, page: Page):
        """Configure platform filters."""
        try:
            logger.info("opening_platform_settings")
            platform_settings = page.locator('.text-blue:has-text("Platform Settings")')

            if await platform_settings.count() > 0:
                await platform_settings.first.click()
                await page.wait_for_timeout(FILTER_PLATFORM_OPEN_WAIT)
                logger.info("platform_settings_opened")

            logger.info("configuring_platforms")
            for platform, attr_name in [
                ("C5GAME", "platform_c5game"),
                ("UU", "platform_uu"),
                ("BUFF", "platform_buff"),
            ]:
                try:
                    checkbox = page.locator(
                        f'.el-checkbox:has-text("{platform}")'
                    ).first
                    if await checkbox.count() > 0:
                        input_chk = checkbox.locator('input[type="checkbox"]')
                        is_checked = await input_chk.is_checked()
                        should_be_checked = getattr(self.settings, attr_name, False)

                        if is_checked != should_be_checked:
                            await checkbox.click()
                            status = "checked" if should_be_checked else "unchecked"
                            logger.info(
                                "platform_configured", platform=platform, status=status
                            )
                        else:
                            logger.info(
                                "platform_already_configured",
                                platform=platform,
                                status="checked" if is_checked else "unchecked",
                            )
                except Exception as e:
                    logger.warning(
                        "platform_config_error", platform=platform, error=str(e)
                    )

            await page.wait_for_timeout(FILTER_INPUT_READY_WAIT)
        except Exception as e:
            logger.warning("platforms_configuration_error", error=str(e))

    async def _execute_search(self, page: Page):
        """Execute search."""
        try:
            logger.info("executing_search")
            confirm_btn = page.locator(
                '.bg-\\[\\#0252D9\\]:has-text("Confirm and Search")'
            )
            if await confirm_btn.count() > 0:
                await confirm_btn.first.click()
                logger.info("search_initiated")
                await page.wait_for_timeout(FILTER_SEARCH_EXECUTE_WAIT)
                logger.info("waiting_for_results")
        except Exception as e:
            logger.warning("search_execution_error", error=str(e))
