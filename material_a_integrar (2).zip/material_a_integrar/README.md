# Material a Integrar

Esta carpeta contiene repositorios brutos de referencia y selecciones útiles organizadas por
tarea del backlog.

Los repos originales (`Cs-scraper`, `Cs-Tracker`, `Master-IA-ARA`,
`Master-IA-RES-ReconocimientoGrafica`) se conservan como referencia. El código útil para migrar
se agrupa en carpetas con el número y nombre de la tarea.

## Carpetas por Tarea

- `002-definir-dominio-y-contratos/`: modelos, IDs canónicos, catálogo, wear, StatTrak y contratos de referencia.
- `003-definir-modelo-datos-supabase/`: schemas, catálogos y semillas para assets/plataformas.
- `004-implementar-persistencia-y-outbox/`: almacenamiento incremental, dumps, retry, métricas y persistencia de referencia.
- `005-adquisicion-manual-csv-json/`: loaders JSON/CSV, validación y agregación de históricos.
- `006-automatizaciones-scraping-plataformas/`: cookies, sesiones, scraping, workers, conectores y fallbacks.
- `007-implementar-pipeline-ocr/`: OCR, parsing visual, calibración y reconstrucción de series.
- `008-implementar-predictor-baseline/`: features, datasets, baseline, artifacts y recomendaciones.
- `010-implementar-reglas-perfiles-riesgo/`: políticas, thresholds, métricas y reglas de decisión.
- `011-implementar-broker-y-votacion/`: referencias para predicción, recomendaciones y política de decisión.
- `012-implementar-simulador-trade-hold/`: reglas de ROI, comisiones, utilidad y capital/riesgo.
- `013-flujo-e2e-evaluacion/`: demo, memoria, scripts de presentación y material para evaluación final.

No hay carpeta `009` porque no se ha encontrado código específico de agentes que sea más útil
que las referencias ya clasificadas en predicción, decisión y broker.

## Regla

Nada de aquí es código final. Para usar una pieza, primero hay que adaptarla a la arquitectura
del monorepo, moverla a `apps/` o `packages/`, y añadir tests relevantes.

Excepción práctica: la carpeta `008-implementar-predictor-baseline/` conserva artefactos
entrenados (`.joblib`) y splits (`.pkl`) porque permiten probar el modelo existente antes de
reentrenar. Siguen siendo material local, no código final.
