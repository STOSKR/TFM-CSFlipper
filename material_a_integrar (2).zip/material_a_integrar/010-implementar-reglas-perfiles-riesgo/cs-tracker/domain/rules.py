"""Business rules - Fee calculations and profit formulas."""

from typing import Literal

STEAM_FEE_PERCENT = 13.0
BUFF_FEE_PERCENT = 2.5
CNY_TO_EUR = 8.2


def calculate_fees(price: float, market: Literal["steam", "buff"]) -> float:
    if market == "steam":
        return price * (STEAM_FEE_PERCENT / 100)
    elif market == "buff":
        return price * (BUFF_FEE_PERCENT / 100)
    raise ValueError(f"Unknown market: {market}")


def calculate_profit(
    buy_price: float, sell_price: float, balance_type: str = "STEAM Balance"
) -> float:
    if balance_type == "STEAM Balance":
        cost_with_fees = buy_price
        revenue_after_fees = sell_price - calculate_fees(sell_price, "steam")
        return revenue_after_fees - cost_with_fees
    else:
        cost_with_fees = sell_price
        revenue_after_fees = buy_price - calculate_fees(buy_price, "buff")
        return revenue_after_fees - cost_with_fees


def calculate_roi(
    buy_price: float, sell_price: float, balance_type: str = "STEAM Balance"
) -> float:
    if balance_type == "STEAM Balance":
        if buy_price == 0:
            return 0.0
        steam_net = sell_price * 0.87
        roi_ratio = (steam_net / buy_price) - 1
        return roi_ratio * 100
    else:
        if sell_price == 0:
            return 0.0
        buff_net = buy_price * 0.975
        roi_ratio = (buff_net / sell_price) - 1
        return roi_ratio * 100


def convert_cny_to_eur(price_cny: float) -> float:
    return price_cny / CNY_TO_EUR
