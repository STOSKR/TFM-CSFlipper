from __future__ import annotations

import json
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping

import pandas as pd


DEFAULT_ARTIFACTS_DIR = Path("notebooksV2") / "artifacts" / "scientific_v2"
POLICY_BUNDLE_FILENAME = "policy_bundle.json"
MODEL_SUBDIR = "models"


def _json_load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=lambda _value: None)


def _json_safe(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _json_safe(inner) for key, inner in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(inner) for inner in value]
    if isinstance(value, Path):
        return value.as_posix()
    if isinstance(value, float) and not math.isfinite(value):
        return None
    return value


def _relative_to(path: Path, base: Path) -> str:
    try:
        return path.resolve().relative_to(base.resolve()).as_posix()
    except ValueError:
        return path.as_posix()


def _model_artifact_candidates(
    artifacts_dir: Path,
    model_id: str,
    metadata: Mapping[str, Any],
) -> list[Path]:
    candidates = [artifacts_dir / MODEL_SUBDIR / f"{model_id}.joblib"]
    if metadata.get("primary_model") == model_id:
        candidates.append(artifacts_dir / "primary_model_lightgbm.joblib")
    return candidates


def _model_artifact_entry(
    artifacts_dir: Path,
    model_id: str,
    metadata: Mapping[str, Any],
    params_by_model: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    candidates = _model_artifact_candidates(artifacts_dir, model_id, metadata)
    existing = next((path for path in candidates if path.exists()), None)
    preferred = existing or candidates[0]
    return {
        "model_id": model_id,
        "path": _relative_to(preferred, artifacts_dir),
        "exists": existing is not None,
        "params": dict(params_by_model.get(model_id, {})),
    }


def _first_rankable_policy(
    ranking: list[Mapping[str, Any]],
    *,
    model_artifacts: Mapping[str, Mapping[str, Any]],
    action: str | None = None,
) -> dict[str, Any] | None:
    for row in ranking:
        if action is not None and row.get("action") != action:
            continue
        if row.get("rank_scope") != "actionable":
            continue
        if row.get("rankable") is False:
            continue
        model_id = str(row.get("model_id") or "")
        if model_artifacts.get(model_id, {}).get("exists"):
            return dict(row)
    return None


def build_policy_bundle(artifacts_dir: str | Path = DEFAULT_ARTIFACTS_DIR) -> dict[str, Any]:
    """Build a portable inference policy bundle from notebook V2 artifacts."""

    artifacts_path = Path(artifacts_dir)
    metadata_path = artifacts_path / "candidate_model_metadata.json"
    training_metadata_path = artifacts_path / "model_training_metadata.json"
    ranking_path = artifacts_path / "threshold_model_ranking.json"
    optimal_path = artifacts_path / "optimal_thresholds.json"

    missing = [
        str(path)
        for path in (metadata_path, ranking_path)
        if not path.exists()
    ]
    if missing:
        raise FileNotFoundError(f"Missing required policy artifact(s): {', '.join(missing)}")

    metadata = _json_load(metadata_path)
    training_metadata = _json_load(training_metadata_path) if training_metadata_path.exists() else {}
    ranking = _json_load(ranking_path)
    optimal_thresholds = _json_load(optimal_path) if optimal_path.exists() else {}

    if not isinstance(ranking, list) or not ranking:
        raise ValueError(f"{ranking_path} must contain a non-empty ranking list")

    candidate_params = metadata.get("candidate_params") or []
    params_by_model = {
        str(params["model_id"]): params
        for params in candidate_params
        if isinstance(params, Mapping) and params.get("model_id")
    }
    model_ids = {
        *params_by_model.keys(),
        *(str(row.get("model_id")) for row in ranking if row.get("model_id")),
    }
    model_artifacts = {
        model_id: _model_artifact_entry(
            artifacts_path,
            model_id,
            metadata,
            params_by_model,
        )
        for model_id in sorted(model_ids)
    }

    primary_policy = dict(ranking[0])
    primary_model_id = str(primary_policy.get("model_id") or "")
    primary_model = model_artifacts.get(primary_model_id, {})
    fallback_policy = _first_rankable_policy(
        ranking,
        model_artifacts=model_artifacts,
        action=str(primary_policy.get("action") or ""),
    )
    if fallback_policy is None:
        fallback_policy = _first_rankable_policy(ranking, model_artifacts=model_artifacts)

    warnings: list[str] = []
    if not primary_model.get("exists"):
        warnings.append(
            f"Primary policy model '{primary_model_id}' is not available locally; "
            "rerun notebooksV2/05_model_candidates.ipynb after the candidate-model "
            "artifact saving cell is updated."
        )
    if fallback_policy and fallback_policy.get("model_id") != primary_model_id:
        warnings.append(
            f"Local inference fallback is '{fallback_policy.get('model_id')}' "
            f"for action '{fallback_policy.get('action')}'."
        )

    filters = {
        "min_price_cents": primary_policy.get("min_price_cents"),
        "min_sales": primary_policy.get("min_sales"),
    }
    bundle = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "artifacts_dir": artifacts_path.as_posix(),
        "features": metadata.get("features") or training_metadata.get("features") or [],
        "class_order": metadata.get("class_order")
        or list((training_metadata.get("class_mapping") or {}).keys()),
        "primary_policy": {
            **primary_policy,
            "model_artifact": primary_model or None,
        },
        "local_inference_fallback_policy": (
            {
                **fallback_policy,
                "model_artifact": model_artifacts.get(str(fallback_policy.get("model_id")), {}),
            }
            if fallback_policy
            else None
        ),
        "ready_for_primary_local_inference": bool(primary_model.get("exists")),
        "model_artifacts": model_artifacts,
        "optimal_thresholds": optimal_thresholds,
        "ranking_top": ranking[:10],
        "filters": filters,
        "metadata": {
            "selection_metric": metadata.get("selection_metric"),
            "primary_model": metadata.get("primary_model"),
            "best_validation_metrics": metadata.get("best_validation_metrics"),
            "samples": metadata.get("samples"),
        },
        "sources": {
            "candidate_model_metadata": metadata_path.name,
            "model_training_metadata": training_metadata_path.name
            if training_metadata_path.exists()
            else None,
            "threshold_model_ranking": ranking_path.name,
            "optimal_thresholds": optimal_path.name if optimal_path.exists() else None,
        },
        "warnings": warnings,
    }
    return _json_safe(bundle)


def write_policy_bundle(
    artifacts_dir: str | Path = DEFAULT_ARTIFACTS_DIR,
    output_path: str | Path | None = None,
) -> Path:
    artifacts_path = Path(artifacts_dir)
    bundle = build_policy_bundle(artifacts_path)
    target = Path(output_path) if output_path else artifacts_path / POLICY_BUNDLE_FILENAME
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(bundle, indent=2, allow_nan=False), encoding="utf-8")
    return target


def load_policy_bundle(path: str | Path) -> dict[str, Any]:
    bundle_path = Path(path)
    bundle = _json_load(bundle_path)
    if not isinstance(bundle, dict):
        raise ValueError(f"{bundle_path} must contain a JSON object")
    return bundle


def resolve_model_path(bundle: Mapping[str, Any], bundle_path: str | Path) -> Path:
    policy = bundle.get("primary_policy") or {}
    artifact = policy.get("model_artifact") or {}
    if not artifact.get("exists") and bundle.get("local_inference_fallback_policy"):
        artifact = bundle["local_inference_fallback_policy"].get("model_artifact") or {}

    path_value = artifact.get("path")
    if not path_value:
        raise FileNotFoundError("No local model artifact path is available in the bundle")

    path = Path(path_value)
    if path.is_absolute():
        return path
    return Path(bundle_path).parent / path


@dataclass(frozen=True)
class PolicyDecision:
    decision: str
    action: str
    label: str
    threshold: float
    confidence: float
    reason: str


def decide_from_policy(policy: Mapping[str, Any], confidence: float) -> PolicyDecision:
    action = str(policy.get("action") or "")
    label = str(policy.get("label") or "")
    threshold = float(policy.get("threshold") or 0.0)

    if action == "BUY_UP":
        decision = "buy" if confidence >= threshold else "review"
        reason = "probabilidad de subida por encima del threshold"
    elif action == "AVOID_DOWN":
        decision = "reject" if confidence >= threshold else "review"
        reason = "riesgo de bajada por encima del threshold"
    else:
        decision = "review"
        reason = "politica no accionable para decision automatica"

    return PolicyDecision(
        decision=decision,
        action=action,
        label=label,
        threshold=threshold,
        confidence=float(confidence),
        reason=reason,
    )


def predict_policy_frame(
    frame: pd.DataFrame,
    bundle_path: str | Path = DEFAULT_ARTIFACTS_DIR / POLICY_BUNDLE_FILENAME,
) -> pd.DataFrame:
    """Run the bundled local model over a feature frame and return policy decisions."""

    bundle = load_policy_bundle(bundle_path)
    policy = bundle.get("primary_policy") or {}
    if not bundle.get("ready_for_primary_local_inference") and bundle.get(
        "local_inference_fallback_policy"
    ):
        policy = bundle["local_inference_fallback_policy"]

    features = list(bundle.get("features") or [])
    missing_features = [column for column in features if column not in frame.columns]
    if missing_features:
        raise ValueError(f"Missing required feature columns: {missing_features}")

    import joblib

    model_path = resolve_model_path(bundle, bundle_path)
    model = joblib.load(model_path)
    probabilities = model.predict_proba(frame[features])
    class_to_pos = {str(label): pos for pos, label in enumerate(model.classes_)}

    label = str(policy.get("label") or "")
    if label not in class_to_pos:
        raise ValueError(f"Policy label '{label}' is not present in model classes")

    out = frame.copy()
    for class_label, pos in class_to_pos.items():
        out[f"p_{class_label}"] = probabilities[:, pos]

    confidences = out[f"p_{label}"].astype(float)
    decisions = [decide_from_policy(policy, value) for value in confidences]
    out["policy_action"] = [decision.action for decision in decisions]
    out["policy_label"] = [decision.label for decision in decisions]
    out["policy_threshold"] = [decision.threshold for decision in decisions]
    out["decision"] = [decision.decision for decision in decisions]
    out["confidence"] = [decision.confidence for decision in decisions]
    out["reason"] = [decision.reason for decision in decisions]
    return out
