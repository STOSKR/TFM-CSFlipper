"""Reusable metrics for actionable threshold policies."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd


DEFAULT_MIN_PRICE_CENTS = 100
DEFAULT_MIN_SALES = 5
DEFAULT_RETURN_CLIP = (-1.0, 1.0)
DEFAULT_LARGE_LOSS_THRESHOLD = -0.20


@dataclass(frozen=True)
class PolicyMetricConfig:
    min_price_cents: int = DEFAULT_MIN_PRICE_CENTS
    min_sales: int = DEFAULT_MIN_SALES
    return_clip: tuple[float, float] = DEFAULT_RETURN_CLIP
    min_selected: int = 100
    min_signal_coverage: float = 0.005
    large_loss_threshold: float = DEFAULT_LARGE_LOSS_THRESHOLD


def eligibility_mask(
    frame: pd.DataFrame,
    *,
    min_price_cents: int = DEFAULT_MIN_PRICE_CENTS,
    min_sales: int = DEFAULT_MIN_SALES,
) -> pd.Series:
    """Return rows that meet minimum price and liquidity requirements."""

    required_columns = {"price_cents", "sales"}
    missing = sorted(required_columns - set(frame.columns))
    if missing:
        raise KeyError(f"Missing eligibility columns: {missing}")

    return (frame["price_cents"] >= min_price_cents) & (frame["sales"] >= min_sales)


def _finite_float(value: float, default: float = 0.0) -> float:
    value = float(value)
    return value if np.isfinite(value) else default


def _trimmed_mean(values: pd.Series) -> float:
    if values.empty:
        return 0.0
    low, high = values.quantile([0.01, 0.99])
    return _finite_float(values.clip(low, high).mean())


def signed_returns(frame: pd.DataFrame, return_sign: float) -> pd.Series:
    if return_sign == 0.0:
        return -frame["future_return"].abs()
    return frame["future_return"] * return_sign


def compute_selected_policy_metrics(
    frame: pd.DataFrame,
    *,
    model_id: str,
    action: str,
    label: str,
    threshold: float,
    selected_mask: Iterable[bool] | pd.Series,
    return_sign: float,
    rank_scope: str = "actionable",
    avg_probability_col: str | None = None,
    config: PolicyMetricConfig | None = None,
) -> dict[str, object]:
    """Compute robust policy metrics after applying operability filters."""

    config = config or PolicyMetricConfig()
    selected_mask = pd.Series(selected_mask, index=frame.index).fillna(False).astype(bool)
    eligible = eligibility_mask(
        frame,
        min_price_cents=config.min_price_cents,
        min_sales=config.min_sales,
    )
    effective_selected = selected_mask & eligible

    total_rows = int(len(frame))
    eligible_rows = int(eligible.sum())
    selected = int(effective_selected.sum())
    coverage = selected / total_rows if total_rows else 0.0
    eligible_coverage = eligible_rows / total_rows if total_rows else 0.0
    signal_coverage = selected / eligible_rows if eligible_rows else 0.0

    eligible_frame = frame.loc[eligible]
    base_rate = float((eligible_frame["direction"] == label).mean()) if eligible_rows else 0.0

    if selected:
        selected_frame = frame.loc[effective_selected]
        precision = float((selected_frame["direction"] == label).mean())
        realized = signed_returns(selected_frame, return_sign)
        signed_avg_return = _finite_float(realized.mean())
        signed_return_median = _finite_float(realized.median())
        signed_return_clipped_mean = _finite_float(
            realized.clip(*config.return_clip).mean()
        )
        signed_return_trimmed_mean = _trimmed_mean(realized)
        loss_rate = _finite_float((realized < 0).mean())
        large_loss_rate = _finite_float((realized < config.large_loss_threshold).mean())
        avg_probability = (
            _finite_float(selected_frame[avg_probability_col].mean(), default=np.nan)
            if avg_probability_col
            else np.nan
        )
    else:
        precision = 0.0
        signed_avg_return = 0.0
        signed_return_median = 0.0
        signed_return_clipped_mean = 0.0
        signed_return_trimmed_mean = 0.0
        loss_rate = 0.0
        large_loss_rate = 0.0
        avg_probability = np.nan if avg_probability_col else np.nan

    precision_edge = precision - base_rate
    legacy_utility_score = precision_edge * np.sqrt(coverage) * max(signed_avg_return, 0.0)
    utility_score = (
        precision_edge
        * np.sqrt(signal_coverage)
        * max(signed_return_clipped_mean, 0.0)
    )
    rankable = bool(
        rank_scope == "actionable"
        and selected >= config.min_selected
        and signal_coverage >= config.min_signal_coverage
        and precision_edge > 0
        and signed_return_clipped_mean > 0
    )

    return {
        "model_id": model_id,
        "action": action,
        "label": label,
        "threshold": float(threshold),
        "selected": selected,
        "coverage": coverage,
        "eligible_rows": eligible_rows,
        "eligible_coverage": eligible_coverage,
        "signal_coverage": signal_coverage,
        "precision": precision,
        "base_rate": base_rate,
        "precision_edge": precision_edge,
        "signed_avg_return": signed_avg_return,
        "signed_return_median": signed_return_median,
        "signed_return_clipped_mean": signed_return_clipped_mean,
        "signed_return_trimmed_mean": signed_return_trimmed_mean,
        "loss_rate": loss_rate,
        "large_loss_rate": large_loss_rate,
        "avg_probability": avg_probability,
        "legacy_utility_score": float(legacy_utility_score),
        "utility_score": float(utility_score),
        "rank_scope": rank_scope,
        "rankable": rankable,
        "min_price_cents": config.min_price_cents,
        "min_sales": config.min_sales,
    }


def compute_probability_policy_metrics(
    frame: pd.DataFrame,
    *,
    model_id: str,
    action: str,
    label: str,
    prob_col: str,
    threshold: float,
    return_sign: float,
    rank_scope: str = "actionable",
    config: PolicyMetricConfig | None = None,
) -> dict[str, object]:
    selected_mask = frame[prob_col] >= threshold
    return compute_selected_policy_metrics(
        frame,
        model_id=model_id,
        action=action,
        label=label,
        threshold=threshold,
        selected_mask=selected_mask,
        return_sign=return_sign,
        rank_scope=rank_scope,
        avg_probability_col=prob_col,
        config=config,
    )
