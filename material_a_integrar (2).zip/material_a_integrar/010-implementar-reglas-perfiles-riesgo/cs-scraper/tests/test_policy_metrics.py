import math

import pandas as pd

from analytics.policy_metrics import (
    PolicyMetricConfig,
    compute_selected_policy_metrics,
    eligibility_mask,
)


def _base_frame(rows=120):
    return pd.DataFrame(
        {
            "direction": ["up"] * 60 + ["down"] * 60,
            "future_return": [0.10] * 60 + [-0.05] * 60,
            "price_cents": [100] * rows,
            "sales": [5] * rows,
        }
    )


def test_eligibility_filters_price_and_sales():
    frame = pd.DataFrame(
        {
            "price_cents": [99, 100, 200],
            "sales": [5, 4, 5],
        }
    )

    assert eligibility_mask(frame, min_price_cents=100, min_sales=5).tolist() == [
        False,
        False,
        True,
    ]


def test_outlier_does_not_dominate_robust_utility():
    frame = _base_frame()
    frame.loc[:99, "direction"] = ["up"] * 55 + ["down"] * 45
    frame.loc[:99, "future_return"] = [0.01] * 55 + [-0.01] * 45
    frame.loc[0, "future_return"] = 500.0

    row = compute_selected_policy_metrics(
        frame,
        model_id="m",
        action="BUY_UP",
        label="up",
        threshold=0.5,
        selected_mask=[True] * 100 + [False] * 20,
        return_sign=1.0,
        config=PolicyMetricConfig(return_clip=(-1.0, 1.0)),
    )

    assert row["signed_avg_return"] > 5.0
    assert row["signed_return_clipped_mean"] < 0.02
    assert row["legacy_utility_score"] > row["utility_score"]


def test_avoid_down_uses_negative_future_return_as_positive_signal():
    frame = _base_frame()
    selected = [False] * len(frame)
    for index in range(60, 120):
        selected[index] = True

    row = compute_selected_policy_metrics(
        frame,
        model_id="m",
        action="AVOID_DOWN",
        label="down",
        threshold=0.9,
        selected_mask=selected,
        return_sign=-1.0,
    )

    assert row["precision"] == 1.0
    assert math.isclose(row["signed_avg_return"], 0.05)
    assert math.isclose(row["signed_return_clipped_mean"], 0.05)


def test_rankable_requires_minimum_rules_and_robust_positive_return():
    frame = _base_frame(120)
    selected = [True] * 100 + [False] * 20

    rankable = compute_selected_policy_metrics(
        frame,
        model_id="m",
        action="BUY_UP",
        label="up",
        threshold=0.5,
        selected_mask=selected,
        return_sign=1.0,
    )
    assert rankable["rankable"] is True

    too_few = compute_selected_policy_metrics(
        frame,
        model_id="m",
        action="BUY_UP",
        label="up",
        threshold=0.5,
        selected_mask=[True] * 99 + [False] * 21,
        return_sign=1.0,
    )
    assert too_few["rankable"] is False

    negative_return = frame.copy()
    negative_return.loc[:99, "future_return"] = -0.01
    not_profitable = compute_selected_policy_metrics(
        negative_return,
        model_id="m",
        action="BUY_UP",
        label="up",
        threshold=0.5,
        selected_mask=selected,
        return_sign=1.0,
    )
    assert not_profitable["rankable"] is False
