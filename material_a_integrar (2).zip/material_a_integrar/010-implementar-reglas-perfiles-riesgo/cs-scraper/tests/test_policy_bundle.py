from __future__ import annotations

import json
from pathlib import Path

from analytics.policy_bundle import (
    build_policy_bundle,
    decide_from_policy,
    write_policy_bundle,
)


def _write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_build_policy_bundle_marks_missing_primary_and_fallback(tmp_path: Path) -> None:
    artifacts = tmp_path / "scientific_v2"
    artifacts.mkdir()
    (artifacts / "primary_model_lightgbm.joblib").write_bytes(b"model")

    _write_json(
        artifacts / "candidate_model_metadata.json",
        {
            "primary_model": "lgbm_grid_2",
            "features": ["ret_7d", "price_cents", "sales"],
            "class_order": ["down", "hold", "up"],
            "candidate_params": [
                {"model_id": "lgbm_grid_1", "n_estimators": 70},
                {"model_id": "lgbm_grid_2", "n_estimators": 100},
            ],
        },
    )
    _write_json(
        artifacts / "threshold_model_ranking.json",
        [
            {
                "rank": 1,
                "model_id": "lgbm_grid_1",
                "action": "AVOID_DOWN",
                "label": "down",
                "threshold": 0.9,
                "rank_scope": "actionable",
                "rankable": True,
                "min_price_cents": 100,
                "min_sales": 5,
            },
            {
                "rank": 2,
                "model_id": "lgbm_grid_2",
                "action": "AVOID_DOWN",
                "label": "down",
                "threshold": 0.9,
                "rank_scope": "actionable",
                "rankable": True,
                "min_price_cents": 100,
                "min_sales": 5,
            },
        ],
    )

    bundle = build_policy_bundle(artifacts)

    assert bundle["primary_policy"]["model_id"] == "lgbm_grid_1"
    assert bundle["ready_for_primary_local_inference"] is False
    assert bundle["primary_policy"]["model_artifact"]["exists"] is False
    assert bundle["local_inference_fallback_policy"]["model_id"] == "lgbm_grid_2"
    assert bundle["local_inference_fallback_policy"]["model_artifact"]["exists"] is True
    assert bundle["filters"] == {"min_price_cents": 100, "min_sales": 5}


def test_write_policy_bundle_outputs_json(tmp_path: Path) -> None:
    artifacts = tmp_path / "scientific_v2"
    artifacts.mkdir()
    _write_json(
        artifacts / "candidate_model_metadata.json",
        {
            "primary_model": "lgbm_grid_1",
            "features": ["ret_7d"],
            "class_order": ["down", "hold", "up"],
            "candidate_params": [{"model_id": "lgbm_grid_1"}],
        },
    )
    _write_json(
        artifacts / "threshold_model_ranking.json",
        [
            {
                "rank": 1,
                "model_id": "lgbm_grid_1",
                "action": "BUY_UP",
                "label": "up",
                "threshold": 0.7,
                "rank_scope": "actionable",
                "rankable": True,
            }
        ],
    )

    path = write_policy_bundle(artifacts)

    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["schema_version"] == 1
    assert payload["primary_policy"]["action"] == "BUY_UP"


def test_decide_from_policy_for_avoid_down_and_buy_up() -> None:
    avoid = {"action": "AVOID_DOWN", "label": "down", "threshold": 0.9}
    buy = {"action": "BUY_UP", "label": "up", "threshold": 0.7}

    assert decide_from_policy(avoid, 0.91).decision == "reject"
    assert decide_from_policy(avoid, 0.50).decision == "review"
    assert decide_from_policy(buy, 0.71).decision == "buy"
    assert decide_from_policy(buy, 0.50).decision == "review"
