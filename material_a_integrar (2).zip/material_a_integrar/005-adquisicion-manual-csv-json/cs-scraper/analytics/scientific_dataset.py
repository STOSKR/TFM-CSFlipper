from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from analytics.direction_dataset import (
    CLASS_ORDER,
    add_direction_labels,
    add_past_features,
    build_daily_panel,
    categorical_feature_columns,
    feature_columns,
    filter_min_history,
    load_notebook_price_rows,
    numeric_feature_columns,
)

DATASET_SUBDIR = "datasets"
DATASET_FILE = "direction_dataset_engineered.parquet"
SAMPLE_FILE = "direction_dataset_sample.csv"
METADATA_FILE = "direction_dataset_metadata.json"
SAMPLE_ROWS = 1000
BASELINE_BALANCED_ACCURACY = {
    "LightGBM": 0.4634,
    "CatBoost": 0.4640,
    "XGBoost": 0.4470,
    "Random Forest": 0.4673,
}


@dataclass(frozen=True)
class ScientificDatasetConfig:
    horizon_days: int = 7
    band: float = 0.03
    min_history_days: int = 120
    embargo_days: int = 7


def dataset_artifacts_dir(
    artifacts_dir: str | Path,
    *,
    dataset_subdir: str = DATASET_SUBDIR,
) -> Path:
    path = Path(artifacts_dir) / dataset_subdir
    path.mkdir(parents=True, exist_ok=True)
    return path


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {str(key): _json_safe(inner) for key, inner in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(inner) for inner in value]
    return value


def _date_range(frame: pd.DataFrame) -> dict[str, str | None]:
    if frame.empty or "day" not in frame.columns:
        return {"start": None, "end": None}
    dates = pd.to_datetime(frame["day"], unit="D", origin="unix")
    return {
        "start": dates.min().date().isoformat(),
        "end": dates.max().date().isoformat(),
    }


def _coverage_summary(daily: pd.DataFrame) -> dict[str, Any]:
    if daily.empty:
        return {"variants": 0, "temporal_gaps": 0}
    coverage = daily.groupby("variant_id")["day"].agg(["count", "min", "max"])
    gaps = (
        daily.sort_values(["variant_id", "day"])
        .groupby("variant_id")["day"]
        .diff()
        .sub(1)
        .clip(lower=0)
        .fillna(0)
    )
    return {
        "variants": int(len(coverage)),
        "rows": int(len(daily)),
        "date_range": _date_range(daily),
        "temporal_gaps": int(gaps.sum()),
        "days_per_variant": {
            "min": int(coverage["count"].min()),
            "median": float(coverage["count"].median()),
            "max": int(coverage["count"].max()),
        },
    }


def _group_summary(frame: pd.DataFrame, column: str) -> list[dict[str, Any]]:
    if frame.empty or column not in frame.columns:
        return []
    summary = (
        frame.groupby(column, observed=True)
        .agg(rows=("variant_id", "size"), variants=("variant_id", "nunique"))
        .reset_index()
        .sort_values(["variants", "rows"], ascending=False)
    )
    return summary.head(50).to_dict(orient="records")


def add_compatibility_aliases(frame: pd.DataFrame) -> pd.DataFrame:
    work = frame.copy()
    work["unique_id"] = work["variant_id"].astype(str)
    work["ds"] = pd.to_datetime(work["day"], unit="D", origin="unix")
    work["y"] = work["price_cents"].astype("float64")
    work["y_7d_direction"] = work["direction"].astype(str)
    if "weapon_key" in work.columns and "weapon" not in work.columns:
        work["weapon"] = work["weapon_key"].astype(str)
    return work


def build_scientific_direction_dataset(
    data_root: str | Path,
    config: ScientificDatasetConfig | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    cfg = config or ScientificDatasetConfig()
    data_path = Path(data_root)
    if not data_path.exists():
        raise FileNotFoundError(f"Data root not found: {data_path}")

    json_files = sorted(data_path.rglob("*.json"))
    raw, json_errors = load_notebook_price_rows(data_path)
    if raw.empty:
        raise ValueError(f"No real price rows found under {data_path}")

    daily_all = build_daily_panel(raw)
    daily = filter_min_history(daily_all, min_days=cfg.min_history_days)
    featured = add_past_features(daily)
    labeled = add_direction_labels(
        featured,
        horizon_days=cfg.horizon_days,
        band=cfg.band,
    ).replace([np.inf, -np.inf], np.nan)
    final = add_compatibility_aliases(labeled.dropna().reset_index(drop=True))

    numeric_features = numeric_feature_columns(final.columns)
    categorical_features = categorical_feature_columns(final.columns)
    all_features = feature_columns(final.columns, include_categoricals=True)
    metadata = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "parameters": asdict(cfg),
        "source": {
            "data_root": str(data_path),
            "json_files": len(json_files),
            "json_errors": json_errors,
        },
        "audit": {
            "raw_rows": int(len(raw)),
            "daily_before_history_filter": _coverage_summary(daily_all),
            "daily_after_history_filter": _coverage_summary(daily),
            "final_rows": int(len(final)),
            "final_variants": int(final["variant_id"].nunique()),
            "final_date_range": _date_range(final),
            "by_category": _group_summary(final, "category"),
            "by_weapon": _group_summary(final, "weapon_key"),
            "by_rarity": _group_summary(final, "rarity"),
            "by_wear": _group_summary(final, "w"),
        },
        "target": {
            "class_order": CLASS_ORDER,
            "distribution": final["direction"].value_counts().to_dict(),
            "proportion": final["direction"].value_counts(normalize=True).to_dict(),
        },
        "columns": {
            "canonical": [
                "variant_id", "item_key", "category", "weapon_key", "skin_key",
                "collection", "rarity", "w", "st", "day", "price_cents",
                "sales", "future_price_cents", "future_return", "direction",
            ],
            "aliases": ["unique_id", "ds", "y", "y_7d_direction", "weapon"],
            "numeric_features": numeric_features,
            "categorical_features": categorical_features,
            "all_features": all_features,
        },
        "no_regression_reference": {
            "metric": "balanced_accuracy",
            "baseline_values": BASELINE_BALANCED_ACCURACY,
            "promotion_rule": "New experiments do not replace baselines unless they match or improve the reference metric.",
        },
    }
    return final, metadata


def export_scientific_dataset(
    frame: pd.DataFrame,
    metadata: dict[str, Any],
    artifacts_dir: str | Path,
    *,
    sample_rows: int = SAMPLE_ROWS,
    dataset_subdir: str = DATASET_SUBDIR,
) -> dict[str, Path]:
    out_dir = dataset_artifacts_dir(artifacts_dir, dataset_subdir=dataset_subdir)
    paths = {
        "dataset": out_dir / DATASET_FILE,
        "sample": out_dir / SAMPLE_FILE,
        "metadata": out_dir / METADATA_FILE,
    }
    frame.to_parquet(paths["dataset"], index=False)
    frame.head(sample_rows).to_csv(paths["sample"], index=False)
    paths["metadata"].write_text(
        json.dumps(_json_safe(metadata), indent=2),
        encoding="utf-8",
    )
    return paths


def load_scientific_dataset(
    artifacts_dir: str | Path,
    *,
    dataset_subdir: str = DATASET_SUBDIR,
) -> pd.DataFrame:
    path = dataset_artifacts_dir(artifacts_dir, dataset_subdir=dataset_subdir) / DATASET_FILE
    return pd.read_parquet(path)
