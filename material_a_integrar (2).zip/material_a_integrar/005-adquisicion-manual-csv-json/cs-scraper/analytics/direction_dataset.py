from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

META_COLUMNS = ["category", "weapon_key", "skin_key", "collection", "rarity"]
RAW_COLUMNS = ["variant_id", "item_key", *META_COLUMNS, "w", "st", "day", "p", "vol"]
DAILY_COLUMNS = [
    "variant_id",
    "item_key",
    *META_COLUMNS,
    "w",
    "st",
    "day",
    "sales",
    "price_cents",
]
CLASS_ORDER = ["down", "hold", "up"]
CATEGORICAL_FEATURES = [
    "item_key",
    "w",
    "category",
    "weapon_key",
    "skin_key",
    "collection",
    "rarity",
]
NUMERIC_BASE_FEATURES = [
    "st",
    "price_cents",
    "sales",
    "log_price",
    "log_sales",
    "variant_age_days",
]
FLOAT_FEATURE_PREFIXES = (
    "ret_",
    "sales_ret_",
    "price_vs_ma_",
    "volatility_",
    "sales_z_",
    "rsi_",
    "macd_",
    "category_ret_",
    "weapon_ret_",
    "rel_momentum_",
)


def find_repo_root(start: str | Path | None = None) -> Path:
    root = Path(start or Path.cwd()).resolve()
    for candidate in [root, *root.parents]:
        if (candidate / "analytics").is_dir() and (candidate / "notebooks").is_dir():
            return candidate
    return root


def _item_meta(payload: dict[str, object]) -> dict[str, str]:
    raw_meta = payload.get("item_meta")
    meta = raw_meta if isinstance(raw_meta, dict) else {}
    return {
        column: str(meta.get(column) or "UNK")
        for column in META_COLUMNS
    }


def load_notebook_price_rows(
    data_root: str | Path,
) -> tuple[pd.DataFrame, list[dict[str, str]]]:
    root = Path(data_root)
    rows: list[dict[str, object]] = []
    errors: list[dict[str, str]] = []

    for file_path in sorted(root.rglob("*.json")):
        try:
            payload = json.loads(file_path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(
                {
                    "path": str(file_path),
                    "error": type(exc).__name__,
                    "message": str(exc),
                }
            )
            continue

        item_key = str(payload.get("item_key") or file_path.stem)
        meta = _item_meta(payload)
        variants = payload.get("variants")
        if not isinstance(variants, dict):
            continue

        for variant in variants.values():
            if not isinstance(variant, dict):
                continue
            wear = str(variant.get("w") or "UNK").upper()
            stattrak = int(variant.get("st") or 0)
            variant_id = f"{item_key}__{wear}_st{stattrak}"
            series = variant.get("series")
            if not isinstance(series, list):
                continue
            for point in series:
                if not isinstance(point, dict):
                    continue
                timestamp = point.get("t")
                price = point.get("p")
                if not isinstance(timestamp, int) or not isinstance(price, int):
                    continue
                rows.append(
                    {
                        "variant_id": variant_id,
                        "item_key": item_key,
                        **meta,
                        "w": wear,
                        "st": stattrak,
                        "day": timestamp // 86400,
                        "p": price,
                        "vol": int(point.get("vol") or 0),
                    }
                )

    if not rows:
        return pd.DataFrame(columns=RAW_COLUMNS), errors
    return pd.DataFrame(rows, columns=RAW_COLUMNS), errors


def build_daily_panel(raw: pd.DataFrame) -> pd.DataFrame:
    if raw.empty:
        return pd.DataFrame(columns=DAILY_COLUMNS)

    work = raw.copy()
    for column in META_COLUMNS:
        if column not in work.columns:
            work[column] = "UNK"
        work[column] = work[column].fillna("UNK").astype(str)
    work["price_volume"] = work["p"].astype("int64") * work["vol"].astype("int64")
    group_columns = ["variant_id", "item_key", *META_COLUMNS, "w", "st", "day"]
    grouped = (
        work.groupby(group_columns, as_index=False)
        .agg(sales=("vol", "sum"), price_volume=("price_volume", "sum"), mean=("p", "mean"))
        .sort_values(["variant_id", "day"])
        .reset_index(drop=True)
    )

    sales_safe = grouped["sales"].where(grouped["sales"] > 0, np.nan)
    weighted = grouped["price_volume"] / sales_safe
    grouped["price_cents"] = (
        weighted.fillna(grouped["mean"]).round().astype("int64")
    )
    grouped["st"] = grouped["st"].astype("int8")
    grouped["sales"] = grouped["sales"].astype("int32")
    grouped["price_cents"] = grouped["price_cents"].astype("int32")
    grouped["day"] = grouped["day"].astype("int32")
    return grouped[DAILY_COLUMNS]


def filter_min_history(daily: pd.DataFrame, min_days: int = 120) -> pd.DataFrame:
    if daily.empty:
        return daily.copy()
    counts = daily.groupby("variant_id")["day"].transform("size")
    return daily[counts >= int(min_days)].reset_index(drop=True)


def add_direction_labels(
    daily: pd.DataFrame,
    *,
    horizon_days: int,
    band: float,
) -> pd.DataFrame:
    if daily.empty:
        return daily.copy()

    base = daily.copy()
    base["future_day"] = base["day"] + int(horizon_days)
    future = daily[["variant_id", "day", "price_cents"]].rename(
        columns={"day": "future_day", "price_cents": "future_price_cents"}
    )
    labeled = base.merge(future, on=["variant_id", "future_day"], how="inner")
    labeled["future_return"] = (
        labeled["future_price_cents"] - labeled["price_cents"]
    ) / labeled["price_cents"]
    labeled["direction"] = np.select(
        [labeled["future_return"] > band, labeled["future_return"] < -band],
        ["up", "down"],
        default="hold",
    )
    labeled["is_safe"] = (labeled["future_return"] >= -0.01).astype(int)
    labeled["is_up"] = (labeled["future_return"] > band).astype(int)
    return labeled.drop(columns=["future_day"])


def add_past_features(daily: pd.DataFrame) -> pd.DataFrame:
    if daily.empty:
        return daily.copy()

    work = daily.sort_values(["variant_id", "day"]).reset_index(drop=True).copy()
    grouped = work.groupby("variant_id", group_keys=False)
    price = grouped["price_cents"]
    sales = grouped["sales"]

    for period in (1, 3, 7, 14, 30):
        work[f"ret_{period}d"] = price.pct_change(periods=period)
        work[f"sales_ret_{period}d"] = sales.pct_change(periods=period)

    shifted_price = grouped["price_cents"].shift(1)
    shifted_sales = grouped["sales"].shift(1)
    for window in (7, 14, 30):
        roll_price = shifted_price.groupby(work["variant_id"])
        roll_sales = shifted_sales.groupby(work["variant_id"])
        mean = roll_price.rolling(window, min_periods=3).mean().reset_index(level=0, drop=True)
        std = roll_price.rolling(window, min_periods=3).std().reset_index(level=0, drop=True)
        sales_mean = roll_sales.rolling(window, min_periods=3).mean().reset_index(level=0, drop=True)
        sales_std = roll_sales.rolling(window, min_periods=3).std().reset_index(level=0, drop=True)
        work[f"price_vs_ma_{window}d"] = (work["price_cents"] / mean) - 1.0
        work[f"volatility_{window}d"] = std / mean
        work[f"sales_z_{window}d"] = (work["sales"] - sales_mean) / sales_std

    # Indicadores técnicos adicionales (MACD y RSI)
    def calc_rsi(group_series, window=14):
        delta = group_series.diff()
        gain = delta.where(delta > 0, 0.0)
        loss = -delta.where(delta < 0, 0.0)
        avg_gain = gain.ewm(alpha=1/window, min_periods=3, adjust=False).mean()
        avg_loss = loss.ewm(alpha=1/window, min_periods=3, adjust=False).mean()
        rs = avg_gain / avg_loss
        return 100 - (100 / (1 + rs))

    work["rsi_14d"] = grouped["price_cents"].transform(calc_rsi)

    def calc_macd(group_series):
        ema_12 = group_series.ewm(span=12, adjust=False).mean()
        ema_26 = group_series.ewm(span=26, adjust=False).mean()
        macd = ema_12 - ema_26
        macd_signal = macd.ewm(span=9, adjust=False).mean()
        return macd - macd_signal

    work["macd_hist"] = grouped["price_cents"].transform(calc_macd)

    # Momentum cruzado (relativo)
    work["category_ret_7d"] = work.groupby(["category", "day"])["ret_7d"].transform("mean")
    work["weapon_ret_7d"] = work.groupby(["weapon_key", "day"])["ret_7d"].transform("mean")
    work["rel_momentum_cat_7d"] = work["ret_7d"] - work["category_ret_7d"]
    work["rel_momentum_weap_7d"] = work["ret_7d"] - work["weapon_ret_7d"]

    work["dow"] = pd.to_datetime(work["day"], unit="D", origin="unix").dt.dayofweek
    work["month"] = pd.to_datetime(work["day"], unit="D", origin="unix").dt.month
    work["log_price"] = np.log1p(work["price_cents"].astype("float64"))
    work["log_sales"] = np.log1p(work["sales"].astype("float64"))
    work["variant_age_days"] = work["day"] - grouped["day"].transform("min")
    work["dow"] = work["dow"].astype("int8")
    work["month"] = work["month"].astype("int8")
    work["variant_age_days"] = work["variant_age_days"].astype("int32")
    return work.replace([np.inf, -np.inf], np.nan)


def optimize_direction_frame(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty:
        return frame

    optimized = frame
    for column in ["item_key", "w", *META_COLUMNS, "direction"]:
        if column in optimized.columns:
            optimized[column] = optimized[column].astype("category")

    for column in optimized.columns:
        if column.startswith(FLOAT_FEATURE_PREFIXES) or column in {
            "future_return",
            "log_price",
            "log_sales",
        }:
            optimized[column] = optimized[column].astype("float32")

    for column in ["day", "sales", "price_cents", "future_price_cents"]:
        if column in optimized.columns:
            optimized[column] = optimized[column].astype("int32")
    for binary_col in ["is_safe", "is_up"]:
        if binary_col in optimized.columns:
            optimized[binary_col] = optimized[binary_col].astype("int8")
    if "st" in optimized.columns:
        optimized["st"] = optimized["st"].astype("int8")
    if "dow" in optimized.columns:
        optimized["dow"] = optimized["dow"].astype("int8")
    if "month" in optimized.columns:
        optimized["month"] = optimized["month"].astype("int8")
    if "variant_age_days" in optimized.columns:
        optimized["variant_age_days"] = optimized["variant_age_days"].astype("int32")
    return optimized


def build_direction_dataset(
    data_root: str | Path,
    *,
    horizon_days: int = 7,
    band: float = 0.03,
    min_history_days: int = 120,
) -> tuple[pd.DataFrame, list[dict[str, str]]]:
    raw, errors = load_notebook_price_rows(data_root)
    daily = filter_min_history(build_daily_panel(raw), min_days=min_history_days)
    featured = add_past_features(daily)
    labeled = add_direction_labels(
        featured,
        horizon_days=horizon_days,
        band=band,
    )
    return optimize_direction_frame(labeled.dropna()), errors


def temporal_split(
    frame: pd.DataFrame,
    *,
    train_ratio: float = 0.70,
    val_ratio: float = 0.15,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    if frame.empty:
        return frame.copy(), frame.copy(), frame.copy()

    days = np.sort(frame["day"].unique())
    train_end = days[int(len(days) * train_ratio)]
    val_end = days[int(len(days) * (train_ratio + val_ratio))]
    train = frame[frame["day"] <= train_end]
    val = frame[(frame["day"] > train_end) & (frame["day"] <= val_end)]
    test = frame[frame["day"] > val_end]
    return train.copy(), val.copy(), test.copy()


def numeric_feature_columns(columns: Iterable[str]) -> list[str]:
    prefixes = (
        "ret_", "sales_ret_", "price_vs_ma_", "volatility_", "sales_z_",
        "rsi_", "macd_", "category_ret_", "weapon_ret_", "rel_momentum_"
    )
    selected = [column for column in columns if column.startswith(prefixes)]
    selected.extend(NUMERIC_BASE_FEATURES)
    selected.extend(["dow", "month"])
    return [column for column in selected if column in columns]


def categorical_feature_columns(columns: Iterable[str]) -> list[str]:
    available = set(columns)
    return [column for column in CATEGORICAL_FEATURES if column in available]


def feature_columns(
    columns: Iterable[str],
    *,
    include_categoricals: bool = False,
) -> list[str]:
    selected = numeric_feature_columns(columns)
    if include_categoricals:
        selected.extend(categorical_feature_columns(columns))
    return [column for column in selected if column in columns]
