from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Iterable, Optional

try:
    import numpy as np
except ModuleNotFoundError:  # pragma: no cover - optional at runtime
    np = None

import pandas as pd

BASE_COLUMNS = ["t", "w", "st", "p", "vol", "ccy", "item_key"]
VARIANT_KEY_PATTERN = re.compile(r"^([A-Za-z]+)_st([01])$")


def _empty_frame() -> pd.DataFrame:
    return pd.DataFrame(columns=BASE_COLUMNS)


def _variant_from_key(key: str) -> tuple[str, int] | None:
    match = VARIANT_KEY_PATTERN.match(key.strip())
    if not match:
        return None
    return match.group(1).upper(), int(match.group(2))


def _normalize_frame(rows: list[dict[str, object]]) -> pd.DataFrame:
    if not rows:
        return _empty_frame()

    frame = pd.DataFrame(rows)
    frame["t"] = frame["t"].astype("int64")
    frame["st"] = frame["st"].astype("int8")
    frame["p"] = frame["p"].astype("int64")
    frame["vol"] = frame["vol"].astype("int64")
    if "ccy" not in frame.columns:
        frame["ccy"] = "UNK"
    frame["ccy"] = frame["ccy"].fillna("UNK").astype("string")
    frame["w"] = frame["w"].astype("string")
    frame["item_key"] = frame["item_key"].astype("string")
    return frame[BASE_COLUMNS]


def _load_jsonl_rows(file_path: Path, item_key: str) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []

    with file_path.open("r", encoding="utf-8") as stream:
        for line in stream:
            line = line.strip()
            if not line:
                continue
            payload = json.loads(line)
            if not isinstance(payload, dict):
                continue
            try:
                rows.append(
                    {
                        "t": int(payload["t"]),
                        "w": str(payload["w"]).upper(),
                        "st": int(payload["st"]),
                        "p": int(payload["p"]),
                        "vol": int(payload["vol"]),
                        "ccy": str(payload.get("ccy") or "UNK").upper(),
                        "item_key": item_key,
                    }
                )
            except (KeyError, TypeError, ValueError):
                continue

    return rows


def _load_grouped_json_rows(file_path: Path, item_key: str) -> list[dict[str, object]]:
    with file_path.open("r", encoding="utf-8") as stream:
        payload = json.load(stream)

    if not isinstance(payload, dict):
        return []

    resolved_item_key = str(payload.get("item_key") or item_key)
    variants = payload.get("variants")
    if not isinstance(variants, dict):
        return []

    rows: list[dict[str, object]] = []
    for variant_key, variant_payload in variants.items():
        parsed = _variant_from_key(str(variant_key))
        default_wear = parsed[0] if parsed else ""
        default_st = parsed[1] if parsed else None

        if isinstance(variant_payload, dict):
            wear = str(variant_payload.get("w") or default_wear).upper()
            st_raw = variant_payload.get("st", default_st)
            series = variant_payload.get("series")
        elif isinstance(variant_payload, list):
            wear = default_wear
            st_raw = default_st
            series = variant_payload
        else:
            continue

        if not isinstance(series, list):
            continue

        try:
            stattrak = int(st_raw)
        except (TypeError, ValueError):
            continue

        if not wear or stattrak not in (0, 1):
            continue

        for row in series:
            if not isinstance(row, dict):
                continue
            try:
                rows.append(
                    {
                        "t": int(row["t"]),
                        "w": wear,
                        "st": stattrak,
                        "p": int(row["p"]),
                        "vol": int(row["vol"]),
                        "ccy": str(
                            row.get("ccy") or variant_payload.get("ccy") or "UNK"
                        ).upper(),
                        "item_key": resolved_item_key,
                    }
                )
            except (KeyError, TypeError, ValueError):
                continue

    return rows


def _candidate_priority(folder: Path, path: Path) -> int:
    rel_parts = path.relative_to(folder).parts
    in_items_tree = bool(rel_parts) and rel_parts[0] == "items"
    if path.suffix == ".json" and in_items_tree:
        return 0
    if path.suffix == ".json":
        return 1
    if path.suffix == ".jsonl" and in_items_tree:
        return 2
    return 3


def load_price_file(path: str | Path, item_key: Optional[str] = None) -> pd.DataFrame:
    file_path = Path(path)
    resolved_item_key = item_key or file_path.stem

    if file_path.suffix == ".jsonl":
        rows = _load_jsonl_rows(file_path, resolved_item_key)
    elif file_path.suffix == ".json":
        rows = _load_grouped_json_rows(file_path, resolved_item_key)
    else:
        raise ValueError(f"Unsupported price file format: {file_path.suffix}")

    frame = _normalize_frame(rows)
    return frame.sort_values(["item_key", "t", "w", "st"]).reset_index(drop=True)


def load_price_files(paths: Iterable[str | Path]) -> pd.DataFrame:
    frames = [load_price_file(path) for path in paths]
    if not frames:
        return _empty_frame()
    return pd.concat(frames, ignore_index=True)


def load_prices_dir(
    prices_dir: str | Path, item_keys: Optional[Iterable[str]] = None
) -> pd.DataFrame:
    folder = Path(prices_dir)
    requested = set(item_keys or [])

    by_stem: dict[str, Path] = {}
    by_priority: dict[str, int] = {}
    candidates = sorted(folder.glob("**/*.json")) + sorted(folder.glob("**/*.jsonl"))
    for path in candidates:
        priority = _candidate_priority(folder, path)
        existing_priority = by_priority.get(path.stem)
        if existing_priority is None or priority < existing_priority:
            by_stem[path.stem] = path
            by_priority[path.stem] = priority

    files = [path for _stem, path in sorted(by_stem.items())]
    if requested:
        files = [path for path in files if path.stem in requested]

    return load_price_files(files)


def to_numpy_array(frame: pd.DataFrame, columns: Optional[list[str]] = None) -> Any:
    if np is None:
        raise ModuleNotFoundError(
            "numpy is required for to_numpy_array; install dependencies from requirements.txt"
        )
    selected = columns or ["t", "st", "p", "vol"]
    return frame[selected].to_numpy()


def explain_t_column() -> str:
    return (
        "t representa un timestamp Unix en segundos UTC. "
        "Puedes convertirlo con pandas.to_datetime(frame['t'], unit='s', utc=True)."
    )


def summarize_daily_prices(frame: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "item_key",
        "w",
        "st",
        "day_utc",
        "sales",
        "price_mean_cents",
        "price_median_cents",
        "price_weighted_mean_cents",
    ]
    if frame.empty:
        return pd.DataFrame(columns=columns)

    work = frame.copy()
    work["day_utc"] = pd.to_datetime(work["t"], unit="s", utc=True).dt.strftime(
        "%Y-%m-%d"
    )
    work["price_volume"] = work["p"] * work["vol"]

    grouped = (
        work.groupby(["item_key", "w", "st", "day_utc"], as_index=False)
        .agg(
            sales=("vol", "sum"),
            price_mean_cents=("p", "mean"),
            price_median_cents=("p", "median"),
            price_volume=("price_volume", "sum"),
        )
        .sort_values(["item_key", "w", "st", "day_utc"])
        .reset_index(drop=True)
    )

    grouped["price_mean_cents"] = grouped["price_mean_cents"].round().astype("int64")
    grouped["price_median_cents"] = (
        grouped["price_median_cents"].round().astype("int64")
    )
    has_sales = grouped["sales"] > 0
    sales_safe = grouped["sales"].where(has_sales, 1)
    weighted = grouped["price_volume"] / sales_safe
    weighted = weighted.where(has_sales, grouped["price_mean_cents"].astype("float64"))
    grouped["price_weighted_mean_cents"] = weighted.round().astype("int64")
    grouped["sales"] = grouped["sales"].astype("int64")

    return grouped.drop(columns=["price_volume"])[columns]
