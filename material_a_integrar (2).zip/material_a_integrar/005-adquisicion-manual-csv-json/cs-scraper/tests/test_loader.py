from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from analytics.loader import (
    explain_t_column,
    load_price_file,
    load_prices_dir,
    summarize_daily_prices,
)


def test_load_price_file_grouped_json(tmp_path: Path) -> None:
    payload = {
        "item_key": "rifle_ak_47_fire_serpent",
        "variants": {
            "FT_st0": {
                "w": "FT",
                "st": 0,
                "series": [
                    {"t": 1000, "p": 100, "vol": 2, "day": "1970-01-01"},
                    {"t": 2000, "p": 200, "vol": 1, "day": "1970-01-01"},
                ],
            },
            "MW_st1": {
                "w": "MW",
                "st": 1,
                "series": [{"t": 1500, "p": 300, "vol": 4, "day": "1970-01-01"}],
            },
        },
    }

    path = tmp_path / "rifle_ak_47_fire_serpent.json"
    path.write_text(json.dumps(payload), encoding="utf-8")

    frame = load_price_file(path)

    assert list(frame.columns) == ["t", "w", "st", "p", "vol", "ccy", "item_key"]
    assert len(frame) == 3
    assert set(frame["w"].tolist()) == {"FT", "MW"}
    assert set(frame["ccy"].tolist()) == {"UNK"}


def test_summarize_daily_prices() -> None:
    frame = pd.DataFrame(
        [
            {
                "item_key": "ak",
                "w": "FT",
                "st": 0,
                "t": 1704067200,
                "p": 1000,
                "vol": 2,
            },
            {
                "item_key": "ak",
                "w": "FT",
                "st": 0,
                "t": 1704067201,
                "p": 1200,
                "vol": 1,
            },
            {
                "item_key": "ak",
                "w": "FT",
                "st": 1,
                "t": 1704067200,
                "p": 2000,
                "vol": 3,
            },
        ]
    )

    summary = summarize_daily_prices(frame)

    ft_st0 = summary[(summary["w"] == "FT") & (summary["st"] == 0)].iloc[0]
    assert ft_st0["sales"] == 3
    assert ft_st0["price_mean_cents"] == 1100
    assert ft_st0["price_median_cents"] == 1100
    assert ft_st0["price_weighted_mean_cents"] == 1067


def test_explain_t_column_mentions_unix_and_utc() -> None:
    text = explain_t_column().lower()
    assert "unix" in text
    assert "utc" in text


def test_load_prices_dir_recursive_prefers_items_json(tmp_path: Path) -> None:
    item_key = "rifle_ak_47_fire_serpent"
    nested = tmp_path / "items" / "rifle" / "ak" / f"{item_key}.json"
    nested.parent.mkdir(parents=True, exist_ok=True)
    nested.write_text(
        json.dumps(
            {
                "item_key": item_key,
                "variants": {
                    "FT_st0": {
                        "w": "FT",
                        "st": 0,
                        "series": [
                            {"t": 1000, "p": 100, "vol": 2, "day": "1970-01-01"}
                        ],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    # Legacy flat file with same stem should be ignored when nested json exists.
    legacy = tmp_path / f"{item_key}.jsonl"
    legacy.write_text(
        json.dumps({"t": 2000, "w": "FT", "st": 0, "p": 999, "vol": 9}) + "\n",
        encoding="utf-8",
    )

    frame = load_prices_dir(tmp_path)

    assert len(frame) == 1
    assert frame.iloc[0]["t"] == 1000
