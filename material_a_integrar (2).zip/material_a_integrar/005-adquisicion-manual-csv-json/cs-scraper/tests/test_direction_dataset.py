from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from analytics.direction_dataset import (
    categorical_feature_columns,
    add_direction_labels,
    add_past_features,
    build_daily_panel,
    feature_columns,
    load_notebook_price_rows,
    temporal_split,
)
from analytics.direction_signal import estimate_direction_signal
from analytics.scientific_dataset import (
    ScientificDatasetConfig,
    build_scientific_direction_dataset,
    export_scientific_dataset,
)


def test_load_notebook_price_rows_skips_broken_json(tmp_path: Path) -> None:
    good = tmp_path / "good.json"
    good.write_text(
        json.dumps(
            {
                "item_key": "rifle_ak",
                "variants": {
                    "FT_st0": {
                        "w": "FT",
                        "st": 0,
                        "series": [{"t": 1704067200, "p": 100, "vol": 2}],
                    }
                },
            }
        ),
        encoding="utf-8",
    )
    (tmp_path / "broken.json").write_text("{", encoding="utf-8")

    frame, errors = load_notebook_price_rows(tmp_path)

    assert len(frame) == 1
    assert len(errors) == 1
    assert errors[0]["error"] == "JSONDecodeError"
    assert frame.iloc[0]["category"] == "UNK"


def test_load_notebook_price_rows_includes_item_metadata(tmp_path: Path) -> None:
    good = tmp_path / "good.json"
    good.write_text(
        json.dumps(
            {
                "item_key": "pistol_five_seven_jungle",
                "item_meta": {
                    "category": "pistol",
                    "weapon_key": "five_seven",
                    "skin_key": "jungle",
                    "collection": "the_aztec_collection",
                    "rarity": "consumer_grade",
                },
                "variants": {
                    "FT_st0": {
                        "w": "FT",
                        "st": 0,
                        "series": [{"t": 1704067200, "p": 100, "vol": 2}],
                    }
                },
            }
        ),
        encoding="utf-8",
    )

    frame, errors = load_notebook_price_rows(tmp_path)

    assert errors == []
    assert frame.iloc[0]["weapon_key"] == "five_seven"
    assert frame.iloc[0]["rarity"] == "consumer_grade"


def test_build_daily_panel_uses_weighted_price_for_duplicates() -> None:
    raw = pd.DataFrame(
        [
            {
                "variant_id": "ak__FT_st0",
                "item_key": "ak",
                "w": "FT",
                "st": 0,
                "day": 10,
                "p": 100,
                "vol": 2,
            },
            {
                "variant_id": "ak__FT_st0",
                "item_key": "ak",
                "w": "FT",
                "st": 0,
                "day": 10,
                "p": 200,
                "vol": 1,
            },
        ]
    )

    daily = build_daily_panel(raw)

    assert len(daily) == 1
    assert int(daily.iloc[0]["sales"]) == 3
    assert int(daily.iloc[0]["price_cents"]) == 133
    assert daily.iloc[0]["category"] == "UNK"


def test_add_direction_labels_uses_calendar_horizon() -> None:
    daily = pd.DataFrame(
        {
            "variant_id": ["a", "a", "a"],
            "item_key": ["a", "a", "a"],
            "w": ["FT", "FT", "FT"],
            "st": [0, 0, 0],
            "day": [10, 11, 17],
            "sales": [1, 1, 1],
            "price_cents": [100, 300, 120],
        }
    )

    labeled = add_direction_labels(daily, horizon_days=7, band=0.03)

    assert len(labeled) == 1
    assert int(labeled.iloc[0]["day"]) == 10
    assert labeled.iloc[0]["direction"] == "up"


def test_add_past_features_does_not_mix_variants() -> None:
    daily = pd.DataFrame(
        {
            "variant_id": ["a"] * 8 + ["b"] * 8,
            "item_key": ["a"] * 8 + ["b"] * 8,
            "w": ["FT"] * 16,
            "st": [0] * 16,
            "day": list(range(8)) + list(range(8)),
            "sales": [1] * 16,
            "price_cents": list(range(100, 108)) + list(range(1000, 1008)),
        }
    )

    featured = add_past_features(daily)
    first_b = featured[featured["variant_id"] == "b"].iloc[0]

    assert pd.isna(first_b["ret_1d"])


def test_add_past_features_adds_pattern_features() -> None:
    daily = pd.DataFrame(
        {
            "variant_id": ["a"] * 8,
            "item_key": ["a"] * 8,
            "w": ["FT"] * 8,
            "st": [0] * 8,
            "day": list(range(8)),
            "sales": [1, 2, 3, 4, 5, 6, 7, 8],
            "price_cents": list(range(100, 108)),
        }
    )

    featured = add_past_features(daily)

    assert featured.iloc[-1]["variant_age_days"] == 7
    assert "log_price" in featured.columns
    assert "month" in featured.columns


def test_feature_columns_can_include_categoricals() -> None:
    columns = [
        "ret_1d",
        "price_cents",
        "dow",
        "item_key",
        "w",
        "category",
        "direction",
    ]

    numeric = feature_columns(columns)
    full = feature_columns(columns, include_categoricals=True)

    assert "item_key" not in numeric
    assert "item_key" in full
    assert categorical_feature_columns(columns) == ["item_key", "w", "category"]


def test_temporal_split_keeps_chronological_order() -> None:
    frame = pd.DataFrame({"day": list(range(100)), "value": list(range(100))})

    train, val, test = temporal_split(frame)

    assert train["day"].max() < val["day"].min()
    assert val["day"].max() < test["day"].min()


def test_estimate_direction_signal_returns_direction() -> None:
    daily = pd.DataFrame(
        {
            "day_utc": pd.date_range("2026-01-01", periods=15, freq="D", tz="UTC"),
            "price_smooth_usd": [10 + idx for idx in range(15)],
        }
    )

    signal = estimate_direction_signal(
        daily,
        horizon_days=7,
        hold_band_pct=3.0,
    )

    assert signal is not None
    assert signal.direction == "up"


def test_build_scientific_dataset_requires_real_rows(tmp_path: Path) -> None:
    empty_root = tmp_path / "empty"
    empty_root.mkdir()

    try:
        build_scientific_direction_dataset(empty_root)
    except ValueError as exc:
        assert "No real price rows" in str(exc)
    else:
        raise AssertionError("Expected empty real data to fail")


def test_build_scientific_dataset_exports_contract(tmp_path: Path) -> None:
    data_root = tmp_path / "data"
    data_root.mkdir()
    series = [
        {
            "t": (1704067200 + day * 86400),
            "p": 100 + day + (day % 5),
            "vol": 1 + (day % 7),
        }
        for day in range(80)
    ]
    (data_root / "item.json").write_text(
        json.dumps(
            {
                "item_key": "rifle_ak_47_test",
                "item_meta": {
                    "category": "rifle",
                    "weapon_key": "ak_47",
                    "skin_key": "test",
                    "collection": "test_collection",
                    "rarity": "classified",
                },
                "variants": {"FT_st0": {"w": "FT", "st": 0, "series": series}},
            }
        ),
        encoding="utf-8",
    )

    frame, metadata = build_scientific_direction_dataset(
        data_root,
        ScientificDatasetConfig(horizon_days=7, band=0.03, min_history_days=8),
    )
    paths = export_scientific_dataset(frame, metadata, tmp_path / "artifacts")

    assert not frame.empty
    assert {"variant_id", "future_return", "direction"}.issubset(frame.columns)
    assert {"unique_id", "ds", "y", "y_7d_direction"}.issubset(frame.columns)
    assert "future_return" not in metadata["columns"]["all_features"]
    assert paths["dataset"].exists()
    assert paths["sample"].exists()
    assert paths["metadata"].exists()
