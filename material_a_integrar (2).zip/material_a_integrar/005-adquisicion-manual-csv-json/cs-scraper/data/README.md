# Data Layout

This folder stores runtime artifacts produced by auth, catalog, and price scraping.

## Price Storage

Main location:

- `prices/items/<category>/<weapon>/<item_key>.json`

Examples:

- `prices/items/rifle/ak/rifle_ak_47_fire_serpent.json`
- `prices/items/pistol/usp/pistol_usp_s_printstream.json`

Each file is organized by variant key (`<wear>_st<0|1>`), with independent time series per variant.

Price semantics:

- `p` is stored in minor units (cents) to avoid floating point drift.
- `ccy` stores the currency code for each point (`EUR`, `USD`, `CNY`, etc.).
- Current scraper requests Steam `pricehistory` in EUR by default, so new points are expected to be `ccy="EUR"` unless overridden by environment variables.

## Legacy Files

If older flat files are detected (`prices/<item_key>.json` or `prices/<item_key>.jsonl`),
the storage layer migrates their data into the hierarchical path and archives the originals under:

- `prices/legacy_flat/`

## Training Read Path

Use `analytics.loader.load_prices_dir("data/prices")`.

- It scans recursively.
- It prefers hierarchical JSON in `prices/items/**` over legacy flat files.
- It returns a normalized frame with columns: `t`, `w`, `st`, `p`, `vol`, `ccy`, `item_key`.
