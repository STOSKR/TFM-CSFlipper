from __future__ import annotations

from model_service.features import arbitrage_return, build_model_features


def test_build_model_features_returns_requested_columns() -> None:
    features = build_model_features(
        {
            "external_price_cents": 1000,
            "steam_price_cents": 1300,
            "fee_pct": 0.13,
            "stattrak": True,
            "history": [
                {"day": "2026-04-01", "price_cents": 1000, "sales": 10},
                {"day": "2026-04-08", "price_cents": 1200, "sales": 20},
            ],
        },
        ["ret_1d", "sales_ret_1d", "st", "log_price", "dow", "month"],
    )

    assert set(features) == {"ret_1d", "sales_ret_1d", "st", "log_price", "dow", "month"}
    assert round(features["ret_1d"], 6) == 0.2
    assert features["sales_ret_1d"] == 1.0
    assert features["st"] == 1.0
    assert features["month"] == 4.0


def test_arbitrage_return_uses_net_steam_sale() -> None:
    value = arbitrage_return(
        {"external_price_cents": 1000, "steam_price_cents": 1300, "fee_pct": 0.13}
    )

    assert round(value, 4) == 0.131
