from __future__ import annotations

import json
from pathlib import Path

from model_service.recommendations import build_recommendations, clear_recommendation_cache


def _write_price_file(root: Path, item_key: str, prices: list[int]) -> None:
    file_path = root / "items" / "rifle" / "ak" / f"{item_key}.json"
    file_path.parent.mkdir(parents=True, exist_ok=True)
    series = [
        {
            "t": 1767225600 + index * 86400,
            "p": price,
            "vol": 12 + index,
            "day": f"2026-01-{index + 1:02d}",
        }
        for index, price in enumerate(prices)
    ]
    file_path.write_text(
        json.dumps(
            {
                "item_key": item_key,
                "item_meta": {
                    "category": "rifle",
                    "weapon_key": "ak_47",
                    "skin_name": item_key.replace("_", " ").title(),
                },
                "variants": {"FT_st0": {"w": "FT", "st": 0, "series": series}},
            }
        ),
        encoding="utf-8",
    )


def test_build_recommendations_ranks_by_forward_gain(tmp_path: Path, monkeypatch) -> None:
    _write_price_file(tmp_path, "rifle_ak_47_alpha", [100, 102, 104, 105, 108, 110, 112, 114, 120, 125, 130, 155, 170, 190, 210])
    _write_price_file(tmp_path, "rifle_ak_47_beta", [100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114])
    monkeypatch.setenv("RECOMMENDATIONS_DATA_DIR", str(tmp_path))
    clear_recommendation_cache()

    result = build_recommendations(
        selected_date="2026-01-08",
        limit=10,
        sort_by="pct_up",
        horizon_days=7,
        min_price_cents=100,
        min_sales=5,
    )

    assert result["total_candidates"] == 2
    assert result["items"][0]["item_key"] == "rifle_ak_47_alpha"
    assert result["items"][0]["pct_up_source"] == "realized_forward"
    assert len(result["items"]) == 2
