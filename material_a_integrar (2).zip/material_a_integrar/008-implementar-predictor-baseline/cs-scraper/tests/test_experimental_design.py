from __future__ import annotations

import pandas as pd

from analytics.experimental_design import build_temporal_design


def test_temporal_design_uses_embargo_between_windows() -> None:
    frame = pd.DataFrame(
        {
            "variant_id": ["a"] * 100,
            "day": list(range(100)),
            "direction": ["hold"] * 100,
        }
    )

    design = build_temporal_design(frame, embargo_days=7)
    train_end = design["main_split"]["train"]["end_day"]
    val_start = design["main_split"]["validation"]["start_day"]
    val_end = design["main_split"]["validation"]["end_day"]
    test_start = design["main_split"]["test"]["start_day"]

    assert val_start - train_end == 8
    assert test_start - val_end == 8
    assert len(design["walk_forward_folds"]) == 3
