#!/usr/bin/env python3
"""
Executor: Ejecuta secuencialmente todos los notebooks del pipeline de mejoras
Valida outputs y genera reporte de ejecución
"""

import subprocess
import sys
from pathlib import Path
import json
import time
from datetime import datetime

ROOT = Path(__file__).parent.parent
NOTEBOOKS_DIR = ROOT / 'notebooks' / 'modelos'
ARTIFACTS_DIR = NOTEBOOKS_DIR / 'artifacts'

NOTEBOOKS = [
    ('02_feature_engineering_advanced.ipynb', 'Feature Engineering'),
    ('03_experimental_design.ipynb', 'Temporal Experimental Design'),
    ('03_baselines_validation.ipynb', 'Baselines + Walk-Forward'),
    ('04_catboost_lightgbm.ipynb', 'CatBoost + LightGBM'),
    ('05_threshold_analysis.ipynb', 'Threshold Optimization'),
    ('06_calibration.ipynb', 'Probability Calibration'),
    ('07_advanced_variants.ipynb', 'Advanced Variants'),
    ('08_ensemble.ipynb', 'Ensemble + Selective Classification'),
    ('09_final_evaluation.ipynb', 'Final Evaluation'),
]

EXPECTED_OUTPUTS = {
    '02_feature_engineering_advanced.ipynb': [
        'datasets/direction_dataset_engineered.parquet',
        'datasets/direction_dataset_sample.csv',
        'datasets/direction_dataset_metadata.json',
    ],
    '03_experimental_design.ipynb': ['scientific_v2/temporal_design_metadata.json'],
    '03_baselines_validation.ipynb': [
        'scientific_v2/walk_forward_splits.pkl',
        'scientific_v2/baselines_results.csv',
    ],
    '04_catboost_lightgbm.ipynb': [
        'scientific_v2/catboost_model_v1.pkl',
        'scientific_v2/lightgbm_model_v1.pkl',
    ],
    '05_threshold_analysis.ipynb': ['scientific_v2/optimal_thresholds.json'],
    '06_calibration.ipynb': [
        'scientific_v2/isotonic_calibrator.pkl',
        'scientific_v2/calibration_results.json',
    ],
    '07_advanced_variants.ipynb': ['scientific_v2/variant_comparison.json'],
    '08_ensemble.ipynb': [
        'scientific_v2/ensemble_config.json',
        'scientific_v2/selectivity_analysis.json',
    ],
    '09_final_evaluation.ipynb': ['scientific_v2/final_results.json'],
}

execution_log = {
    'timestamp': datetime.now().isoformat(),
    'notebooks': [],
    'summary': {},
}

def run_notebook(notebook_path, description):
    """Ejecuta un notebook usando jupyter nbconvert"""
    print(f'\n{"="*60}')
    print(f'📓 Ejecutando: {description}')
    print(f'   Archivo: {notebook_path.name}')
    print(f'{"="*60}')
    
    start_time = time.time()
    
    try:
        # Intentar ejecutar con nbconvert
        cmd = [
            'jupyter', 'nbconvert',
            '--to', 'notebook',
            '--execute',
            '--ExecutePreprocessor.timeout=3600',
            '--output', notebook_path.name,
            str(notebook_path)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=7200)
        elapsed = time.time() - start_time
        
        if result.returncode == 0:
            print(f'✅ COMPLETADO en {elapsed:.1f}s')
            return True, elapsed, None
        else:
            error_msg = result.stderr or result.stdout
            print(f'❌ ERROR: {error_msg[:200]}')
            return False, elapsed, error_msg
            
    except subprocess.TimeoutExpired:
        elapsed = time.time() - start_time
        print(f'⏱️  TIMEOUT después de {elapsed:.1f}s')
        return False, elapsed, 'Timeout'
    except FileNotFoundError:
        print(f'⚠️  jupyter no disponible. Usando fallback...')
        # Fallback a ejecución con papermill
        try:
            import papermill as pm
            pm.execute_notebook(
                input_path=str(notebook_path),
                output_path=str(notebook_path),
                timeout=3600
            )
            elapsed = time.time() - start_time
            print(f'✅ COMPLETADO (papermill) en {elapsed:.1f}s')
            return True, elapsed, None
        except Exception as e:
            print(f'❌ ERROR con papermill: {str(e)[:100]}')
            return False, time.time() - start_time, str(e)

def verify_outputs(notebook_name):
    """Verifica que los outputs esperados existan"""
    expected = EXPECTED_OUTPUTS.get(notebook_name, [])
    found = []
    missing = []
    
    for output in expected:
        output_path = ARTIFACTS_DIR / output
        if output_path.exists():
            found.append(output)
        else:
            missing.append(output)
    
    return found, missing

def main():
    print(f'\n🚀 INICIANDO EJECUCIÓN DEL PIPELINE DE MEJORAS')
    print(f'   Timestmap: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')
    print(f'   Root: {ROOT}')
    print(f'   Notebooks: {len(NOTEBOOKS)}')
    
    # Crear directorio de artifacts si no existe
    ARTIFACTS_DIR.mkdir(exist_ok=True)
    
    total_start = time.time()
    completed = 0
    failed = 0
    
    for notebook_file, description in NOTEBOOKS:
        notebook_path = NOTEBOOKS_DIR / notebook_file
        
        if not notebook_path.exists():
            print(f'\n⚠️  Notebook no encontrado: {notebook_path}')
            failed += 1
            continue
        
        # Ejecutar
        success, elapsed, error = run_notebook(notebook_path, description)
        
        # Verificar outputs
        found, missing = verify_outputs(notebook_file)
        
        if success and len(missing) == 0:
            status = '✅ SUCCESS'
            completed += 1
        elif success:
            status = '⚠️  SUCCESS (faltan outputs)'
            completed += 1
        else:
            status = '❌ FAILED'
            failed += 1
        
        # Log
        execution_log['notebooks'].append({
            'notebook': notebook_file,
            'description': description,
            'status': status,
            'elapsed': elapsed,
            'found_outputs': found,
            'missing_outputs': missing,
            'error': error,
        })
        
        print(f'{status}')
        if found:
            print(f'   Outputs: {", ".join(found)}')
        if missing:
            print(f'   ⚠️  Faltan: {", ".join(missing)}')
    
    total_elapsed = time.time() - total_start
    
    # Summary
    execution_log['summary'] = {
        'total': len(NOTEBOOKS),
        'completed': completed,
        'failed': failed,
        'total_time_seconds': total_elapsed,
        'total_time_hours': total_elapsed / 3600,
    }
    
    print(f'\n{"="*60}')
    print(f'📊 RESUMEN FINAL')
    print(f'{"="*60}')
    print(f'✅ Completados: {completed}/{len(NOTEBOOKS)}')
    print(f'❌ Fallidos: {failed}/{len(NOTEBOOKS)}')
    print(f'⏱️  Tiempo total: {total_elapsed/3600:.1f} horas')
    print(f'{"="*60}')
    
    # Guardar log
    log_path = ROOT / '.planning' / 'execution_log.json'
    with open(log_path, 'w') as f:
        json.dump(execution_log, f, indent=2, default=str)
    print(f'\n📝 Log guardado: {log_path}')
    
    return 0 if failed == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
