from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

import nbformat
from nbclient import NotebookClient


DEFAULT_NOTEBOOKS = [
    "notebooks/modelos/00_baseline_naive_media_movil.ipynb",
    "notebooks/modelos/01_lightgbm_regresion.ipynb",
    "notebooks/modelos/02_catboost_regresion.ipynb",
    "notebooks/modelos/03_xgboost_regresion.ipynb",
    "notebooks/modelos/04_random_forest_regresion.ipynb",
]


def find_repo_root(start: Path | None = None) -> Path:
    root = (start or Path.cwd()).resolve()
    for candidate in [root, *root.parents]:
        if (candidate / "analytics").is_dir() and (candidate / "notebooks").is_dir():
            return candidate
    raise SystemExit(
        "No encuentro la raiz del repo. Ejecuta desde Cs-scraper o una subcarpeta."
    )


def read_notebook_list(path: Path) -> list[str]:
    notebooks: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        clean = line.strip()
        if clean and not clean.startswith("#"):
            notebooks.append(clean)
    return notebooks


def resolve_notebooks(repo_root: Path, values: list[str]) -> list[Path]:
    resolved: list[Path] = []
    for value in values:
        path = Path(value)
        if not path.is_absolute():
            path = repo_root / path
        path = path.resolve()
        if not path.exists():
            raise FileNotFoundError(f"No existe el notebook: {path}")
        resolved.append(path)
    return resolved


def execute_notebook(
    *,
    notebook_path: Path,
    repo_root: Path,
    output_dir: Path,
    timeout: int,
    kernel_name: str | None,
) -> Path:
    nb = nbformat.read(notebook_path, as_version=4)
    client_kwargs = {
        "timeout": timeout,
        "resources": {"metadata": {"path": str(repo_root)}},
    }
    if kernel_name:
        client_kwargs["kernel_name"] = kernel_name
    client = NotebookClient(nb, **client_kwargs)

    output_path = output_dir / notebook_path.name
    try:
        client.execute()
    finally:
        output_dir.mkdir(parents=True, exist_ok=True)
        nbformat.write(nb, output_path)

    return output_path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Ejecuta notebooks en orden, conserva una copia ejecutada y deja que "
            "cada notebook guarde sus artifacts en notebooks/modelos/artifacts."
        )
    )
    parser.add_argument(
        "notebooks",
        nargs="*",
        help="Rutas de notebooks a ejecutar. Si se omite, usa la lista por defecto.",
    )
    parser.add_argument(
        "--list-file",
        type=Path,
        help="Archivo de texto con un notebook por linea. Permite comentarios con #.",
    )
    parser.add_argument(
        "--run-id",
        default=datetime.now().strftime("%Y%m%d_%H%M%S"),
        help="Nombre de la carpeta donde se guardan las copias ejecutadas.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=7200,
        help="Timeout por celda, en segundos.",
    )
    parser.add_argument(
        "--kernel",
        default=None,
        help="Kernel Jupyter a usar. Por defecto usa el kernel del notebook.",
    )
    parser.add_argument(
        "--continue-on-error",
        action="store_true",
        help="Continua con el siguiente notebook si uno falla.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    repo_root = find_repo_root()

    selected = list(args.notebooks)
    if args.list_file:
        selected.extend(read_notebook_list(args.list_file))
    if not selected:
        selected = DEFAULT_NOTEBOOKS

    notebooks = resolve_notebooks(repo_root, selected)
    output_dir = repo_root / "notebooks" / "modelos" / "executed" / args.run_id

    print("repo_root:", repo_root)
    print("executed_notebooks_dir:", output_dir)
    print("notebooks:")
    for notebook in notebooks:
        print(" -", notebook.relative_to(repo_root))

    failures: list[tuple[Path, Exception]] = []
    for index, notebook in enumerate(notebooks, start=1):
        print(f"\n[{index}/{len(notebooks)}] Ejecutando {notebook.name}")
        try:
            output_path = execute_notebook(
                notebook_path=notebook,
                repo_root=repo_root,
                output_dir=output_dir,
                timeout=args.timeout,
                kernel_name=args.kernel,
            )
        except Exception as exc:  # noqa: BLE001 - report notebook failures cleanly
            failures.append((notebook, exc))
            print(f"ERROR en {notebook.name}: {type(exc).__name__}: {exc}")
            if not args.continue_on_error:
                break
        else:
            print("OK:", output_path)

    if failures:
        print("\nFallos:")
        for notebook, exc in failures:
            print(f" - {notebook.name}: {type(exc).__name__}: {exc}")
        return 1

    print("\nTodos los notebooks terminaron correctamente.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
