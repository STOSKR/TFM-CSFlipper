from __future__ import annotations

import argparse
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from analytics.policy_bundle import DEFAULT_ARTIFACTS_DIR, write_policy_bundle


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Export a portable local-inference policy bundle from V2 artifacts."
    )
    parser.add_argument(
        "--artifacts-dir",
        type=Path,
        default=DEFAULT_ARTIFACTS_DIR,
        help="Directory containing candidate model and threshold ranking artifacts.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Output JSON path. Defaults to <artifacts-dir>/policy_bundle.json.",
    )
    args = parser.parse_args()

    target = write_policy_bundle(args.artifacts_dir, args.output)
    print(target)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
