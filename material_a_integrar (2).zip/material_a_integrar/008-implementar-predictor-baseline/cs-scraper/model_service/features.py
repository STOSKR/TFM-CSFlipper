from __future__ import annotations

import math
from datetime import datetime
from typing import Any, Iterable, Mapping


def _float(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(number):
        return default
    return number


def _positive(value: Any, default: float = 0.0) -> float:
    number = _float(value, default)
    return number if number > 0 else default


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def _std(values: list[float]) -> float:
    if len(values) < 2:
        return 0.0
    avg = _mean(values)
    return math.sqrt(_mean([(value - avg) ** 2 for value in values]))


def _return(values: list[float], days: int) -> float:
    if len(values) <= days:
        return 0.0
    previous = values[-1 - days]
    return values[-1] / previous - 1.0 if previous > 0 else 0.0


def _window_returns(values: list[float], days: int) -> list[float]:
    if len(values) < 2:
        return []
    start = max(1, len(values) - days)
    returns: list[float] = []
    for index in range(start, len(values)):
        previous = values[index - 1]
        if previous > 0:
            returns.append(values[index] / previous - 1.0)
    return returns


def _z_score(values: list[float], days: int) -> float:
    window = values[-days:]
    if len(window) < 2:
        return 0.0
    sigma = _std(window)
    return (window[-1] - _mean(window)) / sigma if sigma > 0 else 0.0


def _rsi(prices: list[float], days: int = 14) -> float:
    if len(prices) <= days:
        return 50.0
    deltas = [prices[index] - prices[index - 1] for index in range(len(prices) - days, len(prices))]
    gains = [delta for delta in deltas if delta > 0]
    losses = [-delta for delta in deltas if delta < 0]
    avg_gain = _mean(gains)
    avg_loss = _mean(losses)
    if avg_loss == 0:
        return 100.0 if avg_gain > 0 else 50.0
    relative_strength = avg_gain / avg_loss
    return 100.0 - (100.0 / (1.0 + relative_strength))


def _ema(values: list[float], span: int) -> float:
    if not values:
        return 0.0
    alpha = 2.0 / (span + 1.0)
    current = values[0]
    for value in values[1:]:
        current = value * alpha + current * (1.0 - alpha)
    return current


def _macd_hist(prices: list[float]) -> float:
    if len(prices) < 26:
        return 0.0
    macd_series: list[float] = []
    for end in range(26, len(prices) + 1):
        window = prices[:end]
        macd_series.append(_ema(window, 12) - _ema(window, 26))
    signal = _ema(macd_series, 9)
    return macd_series[-1] - signal


def _parse_history(raw_history: Any) -> list[dict[str, Any]]:
    if not isinstance(raw_history, Iterable) or isinstance(raw_history, (str, bytes, Mapping)):
        return []
    rows: list[dict[str, Any]] = []
    for item in raw_history:
        if isinstance(item, Mapping):
            price = _positive(item.get("price_cents") or item.get("price"))
            if 0 < price < 1000 and "price_cents" not in item:
                price *= 100.0
            if price > 0:
                rows.append(
                    {
                        "day": item.get("day") or item.get("date"),
                        "price_cents": price,
                        "sales": _float(item.get("sales")),
                    }
                )
    return rows


def _day_parts(day_value: Any) -> tuple[int, int]:
    if isinstance(day_value, str) and day_value.strip():
        try:
            parsed = datetime.fromisoformat(day_value.strip().replace("Z", "+00:00"))
            return int(parsed.weekday()), int(parsed.month)
        except ValueError:
            return 0, 1
    now = datetime.utcnow()
    return int(now.weekday()), int(now.month)


def build_model_features(payload: Mapping[str, Any], feature_names: Iterable[str]) -> dict[str, float]:
    """Return exactly the model feature columns, filling unavailable market-relative inputs."""

    history = _parse_history(payload.get("history"))
    prices = [_positive(row.get("price_cents")) for row in history]
    sales_values = [_float(row.get("sales")) for row in history]

    current_price = _positive(
        payload.get("price_cents")
        or payload.get("steam_price_cents")
        or (prices[-1] if prices else 0.0)
    )
    current_sales = _float(payload.get("sales") if payload.get("sales") is not None else (sales_values[-1] if sales_values else 0.0))
    if not prices and current_price > 0:
        prices = [current_price]
    if not sales_values:
        sales_values = [current_sales]

    day, month = _day_parts(payload.get("day") or (history[-1].get("day") if history else None))
    raw: dict[str, float] = {
        "st": 1.0 if payload.get("stattrak") is True else _float(payload.get("st")),
        "price_cents": current_price,
        "sales": current_sales,
        "log_price": math.log1p(current_price),
        "log_sales": math.log1p(max(current_sales, 0.0)),
        "variant_age_days": _float(payload.get("variant_age_days"), float(max(len(prices) - 1, 0))),
        "dow": _float(payload.get("dow"), float(day)),
        "month": _float(payload.get("month"), float(month)),
        "category_ret_7d": _float(payload.get("category_ret_7d")),
        "weapon_ret_7d": _float(payload.get("weapon_ret_7d")),
    }

    for days in (1, 3, 7, 14, 30):
        raw[f"ret_{days}d"] = _float(payload.get(f"ret_{days}d"), _return(prices, days))
        raw[f"sales_ret_{days}d"] = _float(payload.get(f"sales_ret_{days}d"), _return(sales_values, days))

    for days in (7, 14, 30):
        price_ma = _mean(prices[-days:])
        raw[f"price_vs_ma_{days}d"] = _float(
            payload.get(f"price_vs_ma_{days}d"),
            current_price / price_ma - 1.0 if price_ma > 0 else 0.0,
        )
        raw[f"volatility_{days}d"] = _float(payload.get(f"volatility_{days}d"), _std(_window_returns(prices, days)))
        raw[f"sales_z_{days}d"] = _float(payload.get(f"sales_z_{days}d"), _z_score(sales_values, days))

    raw["rsi_14d"] = _float(payload.get("rsi_14d"), _rsi(prices))
    raw["macd_hist"] = _float(payload.get("macd_hist"), _macd_hist(prices))
    raw["rel_momentum_cat_7d"] = _float(
        payload.get("rel_momentum_cat_7d"),
        raw["ret_7d"] - raw["category_ret_7d"],
    )
    raw["rel_momentum_weap_7d"] = _float(
        payload.get("rel_momentum_weap_7d"),
        raw["ret_7d"] - raw["weapon_ret_7d"],
    )

    features: dict[str, float] = {}
    for name in feature_names:
        features[str(name)] = _float(payload.get(str(name)), raw.get(str(name), 0.0))
    return features


def arbitrage_return(payload: Mapping[str, Any]) -> float:
    external = _positive(payload.get("external_price_cents"))
    steam = _positive(payload.get("steam_price_cents") or payload.get("price_cents"))
    fee_pct = min(max(_float(payload.get("fee_pct"), 0.13), 0.0), 1.0)
    if external <= 0 or steam <= 0:
        return _float(payload.get("arbitrage_return"))
    return steam * (1.0 - fee_pct) / external - 1.0

