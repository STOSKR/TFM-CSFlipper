# CS2 Market Model API

Backend Python para servir el modelo LightGBM entrenado en `notebooksV2/artifacts/scientific_v2`.

## Local

```bash
python -m pip install -r requirements.txt
uvicorn model_service.app:app --reload --host 0.0.0.0 --port 8000
```

Prueba rapida:

```bash
curl http://127.0.0.1:8000/health
```

## Variables

- `ARTIFACTS_DIR`: carpeta con `candidate_model_metadata.json`, `optimal_thresholds.json` y los `.joblib`.
- `MODEL_ID`: fuerza un modelo concreto, por ejemplo `lgbm_grid_2`.
- `MODEL_PATH`: ruta absoluta a un `.joblib`, tiene prioridad sobre `MODEL_ID`.
- `CORS_ORIGINS`: origenes permitidos separados por coma. Por defecto permite todos.

