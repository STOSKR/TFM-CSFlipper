from __future__ import annotations

import json
import math
import os
from datetime import date, datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable, Mapping

import pandas as pd

from model_service.features import build_model_features


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_PRICES_DIR = ROOT / "data" / "prices"
NOTEBOOK_PRICES_DIR = ROOT / "notebooks" / "data"
DEFAULT_HORIZON_DAYS = 7


def _date_to_day(value: str | date) -> int:
    if isinstance(value, date):
        parsed = value
    else:
        parsed = date.fromisoformat(str(value))
    return int(datetime(parsed.year, parsed.month, parsed.day, tzinfo=timezone.utc).timestamp() // 86400)


def _day_to_iso(day: int) -> str:
    return datetime.fromtimestamp(int(day) * 86400, tz=timezone.utc).date().isoformat()


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return number if math.isfinite(number) else default


def _resolve_prices_dir() -> Path:
    configured = os.getenv("RECOMMENDATIONS_DATA_DIR")
    if configured:
        return Path(configured).resolve()

    items_dir = DEFAULT_PRICES_DIR / "items"
    if items_dir.exists() and any(items_dir.glob("**/*.json")):
        return DEFAULT_PRICES_DIR
    return NOTEBOOK_PRICES_DIR


def _iter_price_files(root: Path) -> Iterable[Path]:
    items_root = root / "items"
    search_root = items_root if items_root.exists() else root
    return sorted(search_root.glob("**/*.json"))


def _meta(payload: Mapping[str, Any], item_key: str) -> dict[str, str]:
    raw = payload.get("item_meta")
    meta = raw if isinstance(raw, Mapping) else {}
    fallback_parts = item_key.split("_")
    return {
        "category": str(meta.get("category") or (fallback_parts[0] if fallback_parts else "UNK")),
        "weapon_key": str(meta.get("weapon_key") or (fallback_parts[1] if len(fallback_parts) > 1 else "UNK")),
        "skin_name": str(meta.get("skin_name") or item_key.replace("_", " ").title()),
        "collection": str(meta.get("collection") or "UNK"),
        "rarity": str(meta.get("rarity") or "UNK"),
    }


def _variant_rows(item_key: str, variant: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    wear = str(variant.get("w") or "").upper()
    stattrak = int(variant.get("st") or 0)
    series = variant.get("series")
    if not wear or not isinstance(series, list):
        return rows

    for point in series:
        if not isinstance(point, Mapping):
            continue
        try:
            timestamp = int(point["t"])
            price = int(point["p"])
        except (KeyError, TypeError, ValueError):
            continue
        rows.append(
            {
                "item_key": item_key,
                "w": wear,
                "st": stattrak,
                "day": timestamp // 86400,
                "price_cents": price,
                "sales": int(point.get("vol") or 0),
            }
        )
    rows.sort(key=lambda row: int(row["day"]))
    return rows


@lru_cache(maxsize=2)
def _load_price_index(root_value: str) -> list[dict[str, Any]]:
    root = Path(root_value)
    variants: list[dict[str, Any]] = []
    for file_path in _iter_price_files(root):
        try:
            payload = json.loads(file_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if not isinstance(payload, Mapping):
            continue

        item_key = str(payload.get("item_key") or file_path.stem)
        meta = _meta(payload, item_key)
        raw_variants = payload.get("variants")
        if not isinstance(raw_variants, Mapping):
            continue

        for variant_key, variant in raw_variants.items():
            if not isinstance(variant, Mapping):
                continue
            rows = _variant_rows(item_key, variant)
            if not rows:
                continue
            wear = str(rows[-1]["w"])
            stattrak = int(rows[-1]["st"])
            variants.append(
                {
                    "variant_id": f"{item_key}__{wear}_st{stattrak}",
                    "variant_key": str(variant_key),
                    "item_key": item_key,
                    "wear": wear,
                    "st": stattrak,
                    "meta": meta,
                    "rows": rows,
                }
            )
    return variants


def _history_until(rows: list[dict[str, Any]], selected_day: int) -> list[dict[str, Any]]:
    history = [row for row in rows if int(row["day"]) <= selected_day]
    if len(history) > 90:
        history = history[-90:]
    return [
        {
            "day": _day_to_iso(int(row["day"])),
            "price_cents": int(row["price_cents"]),
            "sales": int(row["sales"]),
        }
        for row in history
    ]


def _point_on_or_after(rows: list[dict[str, Any]], target_day: int) -> dict[str, Any] | None:
    return next((row for row in rows if int(row["day"]) >= target_day), None)


def _recent_return(history: list[dict[str, Any]], days: int) -> float:
    if len(history) <= days:
        return 0.0
    current = _finite(history[-1].get("price_cents"))
    previous = _finite(history[-1 - days].get("price_cents"))
    return current / previous - 1.0 if previous > 0 else 0.0


def _probabilities(model: Any, feature_names: list[str], payload: Mapping[str, Any]) -> dict[str, float]:
    if model is None or not feature_names:
        momentum = _finite(payload.get("ret_7d"))
        volatility = max(_finite(payload.get("volatility_30d")), 0.0)
        up = min(max(0.45 + momentum * 2.0 - volatility, 0.02), 0.98)
        down = min(max(0.30 - momentum * 1.4 + volatility, 0.02), 0.98)
        hold = max(0.0, 1.0 - up - down)
        total = up + down + hold
        return {"down": down / total, "hold": hold / total, "up": up / total}

    features = build_model_features(payload, feature_names)
    frame = pd.DataFrame([features], columns=feature_names)
    raw = model.predict_proba(frame)[0]
    labels = [str(label) for label in getattr(model, "classes_", [])]
    return dict(zip(labels, map(float, raw), strict=True))


def _score(prob_up: float, pct_up: float, sort_by: str) -> float:
    if sort_by == "probability":
        return prob_up
    if sort_by == "pct_up":
        return pct_up
    return prob_up * min(max(pct_up, 0.0), 1.0)


def build_recommendations(
    *,
    selected_date: str,
    limit: int,
    sort_by: str,
    horizon_days: int = DEFAULT_HORIZON_DAYS,
    min_price_cents: int = 100,
    min_sales: int = 5,
    model: Any = None,
    feature_names: list[str] | None = None,
) -> dict[str, Any]:
    selected_day = _date_to_day(selected_date)
    limit = min(max(int(limit), 10), 50)
    horizon_days = max(1, int(horizon_days))
    sort_by = sort_by if sort_by in {"hybrid", "pct_up", "probability"} else "hybrid"
    data_dir = _resolve_prices_dir()
    variants = _load_price_index(str(data_dir))

    items: list[dict[str, Any]] = []
    for variant in variants:
        rows = variant["rows"]
        history = _history_until(rows, selected_day)
        if len(history) < 8:
            continue

        current = history[-1]
        if int(current["price_cents"]) < min_price_cents or int(current["sales"]) < min_sales:
            continue

        future = _point_on_or_after(rows, selected_day + horizon_days)
        if future is not None:
            pct_up = _finite(future.get("price_cents")) / _finite(current.get("price_cents")) - 1.0
            pct_up_source = "realized_forward"
        else:
            pct_up = _recent_return(history, min(7, len(history) - 1))
            pct_up_source = "recent_momentum"

        payload = {
            "item_key": variant["item_key"],
            "wear": variant["wear"],
            "st": variant["st"],
            "price_cents": current["price_cents"],
            "steam_price_cents": current["price_cents"],
            "sales": current["sales"],
            "history": history,
        }
        features = build_model_features(payload, feature_names or [])
        probabilities = _probabilities(model, feature_names or [], {**payload, **features})
        prob_up = _finite(probabilities.get("up"))
        score = _score(prob_up, pct_up, sort_by)
        if score <= 0 and sort_by != "probability":
            continue

        meta = variant["meta"]
        items.append(
            {
                "variant_id": variant["variant_id"],
                "item_key": variant["item_key"],
                "skin_name": meta["skin_name"],
                "category": meta["category"],
                "weapon_key": meta["weapon_key"],
                "wear": variant["wear"],
                "st": variant["st"],
                "price_cents": int(current["price_cents"]),
                "sales": int(current["sales"]),
                "prob_up": prob_up,
                "pct_up": pct_up,
                "pct_up_source": pct_up_source,
                "score": score,
                "collection": meta["collection"],
                "rarity": meta["rarity"],
            }
        )

    items.sort(key=lambda row: (float(row["score"]), float(row["prob_up"]), float(row["pct_up"])), reverse=True)
    return {
        "date": selected_date,
        "horizon_days": horizon_days,
        "sort_by": sort_by,
        "limit": limit,
        "data_dir": str(data_dir),
        "total_candidates": len(items),
        "items": items[:limit],
    }


def clear_recommendation_cache() -> None:
    _load_price_index.cache_clear()
