# Plan Detallado: Predicción de Dirección de Precios con Optimización de Precisión

**Objetivo Principal**: Crear un modelo que predice dirección de precios (up/hold/down) con **alta precisión en threshold bajo** basándose en el plan de mejoras de Codex.

**Status**: 🟡 EN PLANIFICACIÓN
**Fecha Inicio**: 2026-05-06
**Milestones**: v1.0 → v1.1 → v1.2 → v1.3

---

## RESUMEN EJECUTIVO: LAS 8 MEJORAS CLAVE

Según análisis en `mejoras.md`, para lograr "threshold más bajo con precisión más alta":

1. **Calibración de Probabilidades** → Platt + Isotonic para confiabilidad
2. **Optimizar Precision Selectiva** → Medir precision@threshold, no solo macro-F1
3. **Target Limpio** → Aumentar band para up/down más limpios
4. **Features Potentes** → Momentum, volatilidad, cross-sectional, régimen
5. **Validación Walk-Forward Real** → Múltiples folds temporales, thresholds congelados
6. **Ensemble con Diversidad** → CatBoost + LightGBM + Logística
7. **Clasificación Selectiva** → Solo actuar cuando confidence alto
8. **Cost-Sensitive Training** → Penalizar más falsos positivos

**Orden Ejecutable**: 1→5→2→3→4→6→7→8

---

## FASE 1: CORRECCIÓN DEL SPLIT TEMPORAL CON HORIZONTE

### Notebook 02: Feature Engineering Avanzado
**Responsabilidad**: Crear features leakage-free potentes

**Input**: 
- `direction_dataset` (cargado desde `analytics.direction_dataset`)
- Daily panel con `unique_id`, `ds`, `y`, `category`, `weapon`

**Output**: 
- `direction_dataset_engineered.parquet`
- Columnas: `unique_id`, `ds`, + 50+ features + `y_7d_direction`

**Implementación Detallada**:

```python
# 1. Cargar datos
from analytics.direction_dataset import build_daily_panel, filter_min_history
daily = filter_min_history(build_daily_panel(raw), min_days=365)

# 2. Definir target
df['return_7d'] = df.groupby('unique_id')['y'].shift(-7) / df['y'] - 1
band = 0.01
df['y_7d_direction'] = pd.cut(df['return_7d'], 
                               bins=[-np.inf, -band, band, np.inf],
                               labels=['down', 'hold', 'up'])

# 3. Features de Momentum (Mejora #4)
for lag in [3, 7, 14, 30]:
    df[f'momentum_{lag}d'] = df.groupby('unique_id')['y'].pct_change(lag)
    df[f'momentum_accel_{lag}d'] = df[f'momentum_{lag}d'].diff()

# 4. Features de Volatilidad
for window in [7, 14, 30]:
    df[f'volatility_{window}d'] = df.groupby('unique_id')['y'].rolling(window).std()
    df[f'volume_zscore_{window}d'] = (
        (df['volume'] - df.groupby('unique_id')['volume'].rolling(window).mean()) /
        df.groupby('unique_id')['volume'].rolling(window).std()
    )

# 5. Cross-Sectional Features (Mejora #4)
df['weapon_rank'] = df.groupby(['ds', 'weapon'])['y'].rank()
df['category_momentum'] = df.groupby(['ds', 'category'])['momentum_7d'].transform('mean')

# 6. Lags combinados
df['lag_7d_price'] = df.groupby('unique_id')['y'].shift(7)
df['lag_7d_volume'] = df.groupby('unique_id')['volume'].shift(7)
df['price_volume_corr'] = df.groupby('unique_id')[['y', 'volume']].rolling(14).corr().unstack()

# 7. Régimen de mercado global (Mejora #4)
market_return = df.groupby('ds')['y'].mean().pct_change()
df['market_regime'] = market_return.rolling(5).mean()

# 8. Limpieza y exportar
df = df.dropna()
df.to_parquet('engineered_dataset.parquet')
```

**Criterios de Completitud**:
- ✓ Ninguna feature referencia datos futuros
- ✓ 50+ features creadas
- ✓ No NaN en features finales
- ✓ Dataset exportado en parquet

**Tiempo**: 2 horas

---

## FASE 2: BASELINES Y VALIDACIÓN TEMPORAL ROBUSTA

### Notebook 03: Baselines + Walk-Forward Validation
**Responsabilidad**: Establecer validación temporal correcta y baselines

**Input**: 
- `direction_dataset_engineered.parquet`

**Output**: 
- `walk_forward_splits.pkl` (folds reutilizables)
- `baselines_results.csv`
- Visualizaciones de estabilidad entre folds

**Implementación Detallada**:

```python
# 1. Walk-Forward Splits (Mejora #5)
# Principio: train en pasado, test en futuro, sin solapamiento
total_days = df['ds'].nunique()
folds = []

fold_config = [
    {'train': (0.00, 0.50), 'val': (0.50, 0.65), 'test': (0.65, 0.80)},  # Fold 1
    {'train': (0.00, 0.65), 'val': (0.65, 0.80), 'test': (0.80, 0.95)},  # Fold 2
    {'train': (0.00, 0.80), 'val': (0.80, 0.95), 'test': (0.95, 1.00)},  # Fold 3
]

for config in fold_config:
    fold = {
        'train_idx': get_date_indices(df, config['train']),
        'val_idx': get_date_indices(df, config['val']),
        'test_idx': get_date_indices(df, config['test']),
    }
    folds.append(fold)

# 2. Baseline 1: Persistencia (predecir hold)
pred = np.ones(len(df)) * 1  # 1 = hold
metrics['persistence'] = compute_metrics(y_true, pred)

# 3. Baseline 2: Signo del último retorno
df['last_7d_sign'] = df.groupby('unique_id')['return_7d'].shift(7).apply(lambda x: 0 if x < 0 else 2)
metrics['last_return_sign'] = compute_metrics(y_true, df['last_7d_sign'])

# 4. Baseline 3: Logística Multinomial
from sklearn.linear_model import LogisticRegression
lr = LogisticRegression(multi_class='multinomial', max_iter=1000)
lr.fit(X_train, y_train)
metrics['logistic'] = compute_metrics(y_val, lr.predict(X_val))

# 5. Medir estabilidad entre folds
results = []
for fold_idx, fold in enumerate(folds):
    X_train = df.loc[fold['train_idx'], features]
    y_train = df.loc[fold['train_idx'], 'y_7d_direction']
    X_val = df.loc[fold['val_idx'], features]
    y_val = df.loc[fold['val_idx'], 'y_7d_direction']
    
    for baseline_name in ['persistence', 'last_return_sign', 'logistic']:
        preds = baseline_predictor(X_val, baseline_name)
        metrics = compute_metrics(y_val, preds)
        results.append({
            'fold': fold_idx,
            'baseline': baseline_name,
            'macro_f1': metrics['macro_f1'],
            'balanced_acc': metrics['balanced_accuracy'],
        })

results_df = pd.DataFrame(results)
print(results_df.groupby('baseline')[['macro_f1', 'balanced_acc']].std())  # Debe ser <0.05

results_df.to_csv('baselines_results.csv')
```

**Criterios de Completitud**:
- ✓ 3 folds walk-forward creados
- ✓ Baselines evaluados en cada fold
- ✓ Estabilidad entre folds < 5% desv. estándar
- ✓ Folds guardados para reutilizar

**Tiempo**: 1.5 horas

---

## FASE 3: MODELOS BASE PRODUCTIVOS

### Notebook 04: CatBoost + LightGBM
**Responsabilidad**: Entrenar modelos base optimizados

**Input**: 
- `direction_dataset_engineered.parquet`
- `walk_forward_splits.pkl`

**Output**: 
- `catboost_model_v1.pkl`
- `lightgbm_model_v1.pkl`
- `models_comparison.csv`
- `feature_importance.csv`

**Implementación Detallada**:

```python
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from optuna import create_study

# 1. Definir search spaces
catboost_params = {
    'iterations': trial.suggest_int(100, 500),
    'learning_rate': trial.suggest_float(0.01, 0.1),
    'depth': trial.suggest_int(4, 8),
    'l2_leaf_reg': trial.suggest_float(1, 10),
}

lightgbm_params = {
    'n_estimators': trial.suggest_int(100, 500),
    'learning_rate': trial.suggest_float(0.01, 0.1),
    'num_leaves': trial.suggest_int(20, 40),
    'lambda_l2': trial.suggest_float(0, 1),
}

# 2. Bayesian hyperparameter tuning en validation folds
catboost_results = []
for fold in folds:
    study = create_study()
    def objective(trial):
        params = catboost_params
        model = CatBoostClassifier(**params, verbose=0)
        model.fit(X_train, y_train, eval_set=[(X_val, y_val)])
        return model.score(X_val, y_val)
    
    study.optimize(objective, n_trials=20)
    catboost_results.append(study.best_params)

best_cb_params = merge_params(catboost_results)  # Average best params

# 3. Entrenar modelos finales
cb_model = CatBoostClassifier(**best_cb_params)
cb_model.fit(X_train, y_train)
cb_model.save_model('catboost_model_v1.pkl')

lgb_model = LGBMClassifier(**best_lgb_params)
lgb_model.fit(X_train, y_train)
lgb_model.save_model('lightgbm_model_v1.pkl')

# 4. Feature importance
cb_importance = cb_model.get_feature_importance()
lgb_importance = lgb_model.feature_importances_

# 5. Comparar performance
comparison = {
    'CatBoost': evaluate_model(cb_model, X_val, y_val),
    'LightGBM': evaluate_model(lgb_model, X_val, y_val),
}
pd.DataFrame(comparison).to_csv('models_comparison.csv')
```

**Criterios de Completitud**:
- ✓ CatBoost y LightGBM entrenados
- ✓ Hiperparámetros optimizados en validation folds
- ✓ Feature importance calculado
- ✓ Modelos persistidos

**Tiempo**: 3 horas

---

## FASE 4: OPTIMIZACIÓN DE THRESHOLDS

### Notebook 05: Precision/Threshold Analysis
**Responsabilidad**: Encontrar thresholds óptimos para alta precisión (Mejora #2)

**Input**: 
- Modelos entrenados
- Probabilidades de validation set

**Output**: 
- `optimal_thresholds.json`
- `precision_recall_curves.png`
- `threshold_stability_analysis.csv`

**Implementación Detallada**:

```python
from sklearn.metrics import precision_recall_curve, auc

# 1. Generar probabilidades en validation folds
for fold in folds:
    X_val = df.loc[fold['val_idx'], features]
    
    cb_probs = cb_model.predict_proba(X_val)  # (n_samples, 3)
    lgb_probs = lgb_model.predict_proba(X_val)
    
    # 2. Para cada clase (up, down), analizar precision@threshold
    thresholds_per_class = {}
    
    for class_idx, class_name in enumerate(['down', 'hold', 'up']):
        if class_name == 'hold':
            continue  # No nos interesa hold
        
        probs = cb_probs[:, class_idx]
        y_true_binary = (df['y_7d_direction'] == class_name).astype(int)
        
        # Precision-recall curve
        precision, recall, thresholds = precision_recall_curve(y_true_binary, probs)
        
        # Encontrar threshold que da precision >= 0.90 con máxima recall
        valid_idx = precision >= 0.90
        if valid_idx.any():
            best_threshold = thresholds[np.argmax(recall[valid_idx])]
            thresholds_per_class[class_name] = {
                'threshold': float(best_threshold),
                'precision': float(precision[np.argmax(recall[valid_idx])]),
                'recall': float(recall[np.argmax(recall[valid_idx])]),
            }
        
        # Graficar
        plt.plot(recall, precision, label=f'{class_name} (AUC={auc(recall, precision):.3f})')
    
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.legend()
    plt.savefig(f'precision_recall_fold_{fold_idx}.png')

# 3. Verificar estabilidad de thresholds entre folds
threshold_std = pd.DataFrame(thresholds_per_class).std()
print(f"Stability (std of thresholds): {threshold_std}")

# 4. Guardar thresholds óptimos
json.dump(thresholds_per_class, open('optimal_thresholds.json', 'w'))
```

**Criterios de Completitud**:
- ✓ Precision-recall curves para up y down
- ✓ Thresholds óptimos encontrados
- ✓ Estabilidad verificada entre folds (std < 0.05)
- ✓ Coverage >= 20%

**Tiempo**: 2 horas

---

## FASE 5: CALIBRACIÓN DE PROBABILIDADES

### Notebook 06: Probability Calibration
**Responsabilidad**: Hacer confiables las probabilidades (Mejora #1)

**Input**: 
- Probabilidades de validation set
- Modelos entrenados

**Output**: 
- `platt_calibrator.pkl`
- `isotonic_calibrators.pkl`
- `calibration_results.json`

**Implementación Detallada**:

```python
from sklearn.calibration import CalibratedClassifierCV
from sklearn.calibration import calibration_curve

# 1. Datos para calibración (usar validation set)
X_calib = df.loc[fold['val_idx'], features]
y_calib = df.loc[fold['val_idx'], 'y_7d_direction']

# 2. Aplicar Platt scaling
platt_calibrator = CalibratedClassifierCV(cb_model, method='sigmoid', cv='prefit')
platt_calibrator.fit(X_calib, y_calib)
platt_probs = platt_calibrator.predict_proba(X_calib)

# 3. Aplicar Isotonic regression
isotonic_calibrator = CalibratedClassifierCV(cb_model, method='isotonic', cv='prefit')
isotonic_calibrator.fit(X_calib, y_calib)
isotonic_probs = isotonic_calibrator.predict_proba(X_calib)

# 4. Evaluar calibración antes/después
from sklearn.metrics import brier_score_loss

def compute_calibration_metrics(y_true, y_probs):
    # Brier score (menor es mejor)
    brier = brier_score_loss(y_true, y_probs.max(axis=1))
    
    # Reliability plot
    prob_true, prob_pred = calibration_curve(y_true, y_probs.max(axis=1), n_bins=10)
    
    return {'brier': brier, 'prob_true': prob_true, 'prob_pred': prob_pred}

original_calib = compute_calibration_metrics(y_calib, cb_model.predict_proba(X_calib))
platt_calib = compute_calibration_metrics(y_calib, platt_probs)
isotonic_calib = compute_calibration_metrics(y_calib, isotonic_probs)

print(f"Original Brier: {original_calib['brier']:.4f}")
print(f"Platt Brier: {platt_calib['brier']:.4f}")
print(f"Isotonic Brier: {isotonic_calib['brier']:.4f}")

# 5. Visualizar reliability plots
fig, axes = plt.subplots(1, 3, figsize=(15, 5))
for ax, calib, title in zip(axes, [original_calib, platt_calib, isotonic_calib], 
                             ['Original', 'Platt', 'Isotonic']):
    ax.plot([0, 1], [0, 1], 'k--', label='Perfect calibration')
    ax.plot(calib['prob_pred'], calib['prob_true'], 's-', label='Model')
    ax.set_xlabel('Mean predicted probability')
    ax.set_ylabel('Fraction of positives')
    ax.set_title(title)
    ax.legend()

plt.savefig('calibration_comparison.png')

# 6. Re-optimizar thresholds con probabilidades calibradas
calibrated_probs = isotonic_probs  # Usar isotonic que suele ser mejor
for class_idx, class_name in enumerate(['down', 'up']):
    probs = calibrated_probs[:, class_idx]
    precision, recall, thresholds = precision_recall_curve(y_calib == class_name, probs)
    # Encontrar nuevo threshold
    ...

# 7. Guardar calibradores
pickle.dump(isotonic_calibrator, open('isotonic_calibrator.pkl', 'wb'))
```

**Criterios de Completitud**:
- ✓ Platt y Isotonic calibrators entrenados
- ✓ Brier score mejorado
- ✓ Reliability plots generados
- ✓ Thresholds re-optimizados con probs calibradas

**Tiempo**: 1.5 horas

---

## FASE 6: INGENIERÍA AVANZADA

### Notebook 07: Variantes Avanzadas + Features Experimentales
**Responsabilidad**: Probar alternativas para aumentar precisión (Mejoras #3, #4)

**Input**: 
- Datasets originales
- Modelos entrenados

**Output**: 
- `variant_comparison.csv`
- `advanced_features_comparison.csv`

**Implementación Detallada**:

```python
# Variante 1: Aumentar band a 0.03 (up/down más limpios)
df['y_7d_direction_v2'] = pd.cut(df['return_7d'], 
                                  bins=[-np.inf, -0.03, 0.03, np.inf],
                                  labels=['down', 'hold', 'up'])

# Entrenar modelo con banda mayor
cb_v2 = CatBoostClassifier(**best_params)
cb_v2.fit(X_train, df.loc[X_train.index, 'y_7d_direction_v2'])

# Variante 2: Dos modelos binarios
df['y_up'] = (df['y_7d_direction'] == 'up').astype(int)
df['y_down'] = (df['y_7d_direction'] == 'down').astype(int)

cb_binary_up = CatBoostClassifier(**best_params)
cb_binary_up.fit(X_train, df.loc[X_train.index, 'y_up'])

cb_binary_down = CatBoostClassifier(**best_params)
cb_binary_down.fit(X_train, df.loc[X_train.index, 'y_down'])

# Variante 3: Predecir retorno esperado
from sklearn.ensemble import GradientBoostingRegressor
gb_regressor = GradientBoostingRegressor()
gb_regressor.fit(X_train, df.loc[X_train.index, 'return_7d'])

# Features adicionales avanzadas
df['momentum_volatility_interaction'] = df['momentum_7d'] * df['volatility_7d']
df['market_regime_category'] = pd.cut(df['market_regime'], bins=3, labels=['down', 'neutral', 'up'])
df['days_since_change'] = df.groupby('unique_id')['momentum_7d'].apply(
    lambda x: (x != 0).cumprod().groupby(x != 0).cumsum()
)

# Features de persistencia
df['price_persistence'] = df.groupby('unique_id')['y'].transform(lambda x: x.autocorr(7))

# Comparar todas las variantes
results = {
    'baseline': evaluate_model(cb_model, X_val, y_val),
    'band_0.03': evaluate_model(cb_v2, X_val, df.loc[X_val.index, 'y_7d_direction_v2']),
    'binary_up': evaluate_model(cb_binary_up, X_val, df.loc[X_val.index, 'y_up']),
    'binary_down': evaluate_model(cb_binary_down, X_val, df.loc[X_val.index, 'y_down']),
}

pd.DataFrame(results).to_csv('variant_comparison.csv')
```

**Criterios de Completitud**:
- ✓ 3 variantes de target entrenadas
- ✓ Features avanzadas creadas
- ✓ Comparativa de AUC-PR y precision
- ✓ Mejor variante identificada

**Tiempo**: 3 horas

---

## FASE 7: ENSEMBLE Y CLASIFICACIÓN SELECTIVA

### Notebook 08: Ensemble + Selective Classification
**Responsabilidad**: Combinar modelos y añadir lógica de abstención (Mejoras #6, #7)

**Input**: 
- Modelos: CatBoost, LightGBM, calibradores
- Probabilidades de validation

**Output**: 
- `ensemble_model_v1.pkl`
- `selectivity_analysis.json`
- `ensemble_comparison.csv`

**Implementación Detallada**:

```python
# 1. Ensemble 1: Media de probabilidades
cb_probs = cb_model.predict_proba(X_val)
lgb_probs = lgb_model.predict_proba(X_val)
ensemble_probs_avg = (cb_probs + lgb_probs) / 2

# 2. Ensemble 2: Stacking con meta-modelo
from sklearn.linear_model import LogisticRegression

# Usar modelos como features para meta-modelo
meta_X = np.column_stack([cb_probs, lgb_probs])
meta_model = LogisticRegression(max_iter=1000)
meta_model.fit(meta_X, y_val)
ensemble_probs_stack = meta_model.predict_proba(meta_X)

# 3. Ensemble 3: Voting con confianza
def voting_with_confidence(cb_pred, lgb_pred, cb_probs, lgb_probs):
    # Predecir si ambos están de acuerdo
    agreement = cb_pred == lgb_pred
    
    # Confianza promedio
    cb_confidence = cb_probs.max(axis=1)
    lgb_confidence = lgb_probs.max(axis=1)
    avg_confidence = (cb_confidence + lgb_confidence) / 2
    
    # Solo actuar si agreement y confidence alto
    final_pred = np.where(agreement & (avg_confidence > 0.7), 
                          cb_pred, 
                          1)  # 1 = hold (abstención)
    
    return final_pred, avg_confidence

ensemble_preds, confidence = voting_with_confidence(
    cb_model.predict(X_val), 
    lgb_model.predict(X_val),
    cb_probs,
    lgb_probs
)

# 4. Clasificación selectiva (Mejora #7)
def selective_classification(probs, threshold=0.75):
    max_prob = probs.max(axis=1)
    predicted_class = probs.argmax(axis=1)
    
    # Abstención: si no hay confianza
    uncertain = max_prob < threshold
    predicted_class[uncertain] = 1  # Hold
    
    return predicted_class, (1 - uncertain.mean())  # Coverage

predictions, coverage = selective_classification(ensemble_probs_avg, threshold=0.75)

# 5. Cost-sensitive training (Mejora #8)
# Penalizar más falsos positivos en up/down
class_weights = {
    'down': 2.0,   # Penalizar falsos positivos en down
    'hold': 1.0,
    'up': 2.0,     # Penalizar falsos positivos en up
}

cb_weighted = CatBoostClassifier(
    **best_params,
    class_weights=class_weights,
)
cb_weighted.fit(X_train, y_train)

# 6. Comparar estrategias
comparison = {
    'baseline_catboost': evaluate_model(cb_model, X_val, y_val),
    'ensemble_avg': evaluate_model(None, X_val, y_val, 
                                   probs=ensemble_probs_avg),
    'ensemble_stack': evaluate_model(None, X_val, y_val, 
                                     probs=ensemble_probs_stack),
    'selective': {
        'coverage': coverage,
        'precision': precision_score(y_val[~uncertain], predictions[~uncertain]),
        'f1': f1_score(y_val[~uncertain], predictions[~uncertain], average='macro'),
    },
    'cost_sensitive': evaluate_model(cb_weighted, X_val, y_val),
}

# 7. Análisis de selectividad: precision vs coverage
selectivity_curves = {}
for threshold in np.linspace(0.5, 0.99, 20):
    preds, cov = selective_classification(ensemble_probs_avg, threshold)
    prec = precision_score(y_val, preds, average='macro')
    selectivity_curves[threshold] = {'coverage': cov, 'precision': prec}

# Visualizar trade-off
thresholds = list(selectivity_curves.keys())
coverage = [selectivity_curves[t]['coverage'] for t in thresholds]
precision = [selectivity_curves[t]['precision'] for t in thresholds]

plt.plot(coverage, precision, marker='o')
plt.xlabel('Coverage (%)')
plt.ylabel('Precision')
plt.title('Precision-Coverage Trade-off (Selective Classification)')
plt.grid(True)
plt.savefig('selectivity_tradeoff.png')

# 8. Guardar ensemble
ensemble_config = {
    'models': {'catboost': cb_model, 'lightgbm': lgb_model},
    'meta_model': meta_model,
    'calibrator': isotonic_calibrator,
    'selectivity_threshold': 0.75,
    'thresholds': optimal_thresholds,
}
pickle.dump(ensemble_config, open('ensemble_model_v1.pkl', 'wb'))
```

**Criterios de Completitud**:
- ✓ 3 estrategias de ensemble implementadas
- ✓ Selective classification con threshold tuning
- ✓ Cost-sensitive training aplicado
- ✓ Trade-off precision-coverage visualizado
- ✓ Ensemble guardado

**Tiempo**: 2.5 horas

---

## FASE 8: EVALUACIÓN FINAL

### Notebook 09: Benchmarking Final y Conclusiones
**Responsabilidad**: Evaluación comprehensiva y recomendaciones

**Input**: 
- Todos los modelos
- Test set (nunca tocado antes)

**Output**: 
- `FINAL_RESULTS.csv`
- `test_metrics.json`
- `PRODUCTION_RECOMMENDATIONS.md`

**Implementación Detallada**:

```python
# 1. Evaluar en test set (final - nunca tocado)
test_idx = fold_config[-1]['test_idx']
X_test = df.loc[test_idx, features]
y_test = df.loc[test_idx, 'y_7d_direction']

# 2. Generar predicciones con mejor ensemble
final_ensemble = load_ensemble('ensemble_model_v1.pkl')
probs = final_ensemble.predict_proba(X_test)

# Aplicar calibración
probs_calibrated = final_calibrator.predict_proba(X_test)

# Aplicar selectividad
predictions_selective, coverage = selective_classification(probs_calibrated, threshold=0.75)

# 3. Computar métricas comprehensivas
metrics_test = {
    'macro_f1': f1_score(y_test, predictions_selective, average='macro'),
    'weighted_f1': f1_score(y_test, predictions_selective, average='weighted'),
    'balanced_accuracy': balanced_accuracy_score(y_test, predictions_selective),
    'precision_per_class': precision_score(y_test, predictions_selective, average=None),
    'recall_per_class': recall_score(y_test, predictions_selective, average=None),
    'coverage': coverage,
}

# 4. Precision@coverage levels
for coverage_level in [0.3, 0.5, 0.7]:
    # Ajustar threshold para alcanzar coverage_level
    threshold_for_coverage = find_threshold_for_coverage(probs_calibrated, coverage_level)
    preds, _ = selective_classification(probs_calibrated, threshold_for_coverage)
    precision = precision_score(y_test, preds, average='macro')
    metrics_test[f'precision@coverage_{coverage_level:.1%}'] = precision

# 5. Tabla comparativa de todos los modelos
all_results = {}
for model_name, model in [
    ('Baseline', baseline_model),
    ('CatBoost', cb_model),
    ('LightGBM', lgb_model),
    ('CatBoost+Calib', cb_model + calibrator),
    ('Ensemble', final_ensemble),
    ('Ensemble+Selective', ensemble_selective),
]:
    results = evaluate_model(model, X_test, y_test)
    all_results[model_name] = results

results_table = pd.DataFrame(all_results).T
results_table.to_csv('FINAL_RESULTS.csv')

# 6. Crear matriz de confusión final
from sklearn.metrics import confusion_matrix
import seaborn as sns

cm = confusion_matrix(y_test, predictions_selective, labels=['down', 'hold', 'up'])
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
            xticklabels=['down', 'hold', 'up'],
            yticklabels=['down', 'hold', 'up'])
plt.title('Confusion Matrix - Final Ensemble (Test Set)')
plt.ylabel('True Label')
plt.xlabel('Predicted Label')
plt.savefig('final_confusion_matrix.png')

# 7. Generar reporte de producción
production_report = f"""
# Production Recommendations

## Model Specification

- **Model**: Ensemble (CatBoost + LightGBM) con Calibración Isotónica
- **Features**: 50+ momentum, volatility, cross-sectional features
- **Target**: 7-day direction (up/hold/down) con band=0.01
- **Validation**: Walk-forward con 3 folds temporales

## Performance Summary

### Test Set Metrics

- Macro F1: {metrics_test['macro_f1']:.4f}
- Balanced Accuracy: {metrics_test['balanced_accuracy']:.4f}
- Coverage (selectivity threshold=0.75): {metrics_test['coverage']:.1%}

### Per-Class Performance

- **UP**: Precision={metrics_test['precision_per_class'][2]:.4f}, Recall={metrics_test['recall_per_class'][2]:.4f}
- **DOWN**: Precision={metrics_test['precision_per_class'][0]:.4f}, Recall={metrics_test['recall_per_class'][0]:.4f}
- **HOLD**: Precision={metrics_test['precision_per_class'][1]:.4f}, Recall={metrics_test['recall_per_class'][1]:.4f}

### Precision at Coverage Levels

- Precision @ 30% coverage: {metrics_test.get('precision@coverage_0.3', 'N/A'):.4f}
- Precision @ 50% coverage: {metrics_test.get('precision@coverage_0.5', 'N/A'):.4f}
- Precision @ 70% coverage: {metrics_test.get('precision@coverage_0.7', 'N/A'):.4f}

## Deployment Checklist

- ✓ Model serialization: `ensemble_model_v1.pkl`
- ✓ Calibrator: `isotonic_calibrator.pkl`
- ✓ Feature engineering code: `02_feature_engineering.ipynb`
- ✓ Prediction pipeline: `predict_direction.py`
- ✓ Monitoring: `monitoring_dashboard.py`

## Key Decisions

1. **Selective Classification**: Solo predecir cuando confianza > 75%
2. **Calibration**: Usar Isotonic regression para confiabilidad de probabilidades
3. **Ensemble**: CatBoost + LightGBM (diversidad)
4. **Thresholds**: Congelados en validation set

## Recommendations

1. Reentrenar modelo cada mes con últimos 12 meses de datos
2. Monitorear drift de features en datos nuevos
3. Validar en A/B con baseline antes de producción
4. Alertar si precision cae bajo 85% en cualquier clase
"""

with open('PRODUCTION_RECOMMENDATIONS.md', 'w') as f:
    f.write(production_report)

print("✓ Evaluación final completada")
print(results_table)
```

**Criterios de Completitud**:
- ✓ Evaluación en test set
- ✓ Todas las métricas computadas
- ✓ Tablas comparativas
- ✓ Reporte de producción

**Tiempo**: 1 hora

---

## RESUMEN DE TIMELINE

| # | Notebook | Horas | Status |
|---|----------|-------|--------|
| 1 | 02 Feature Engineering | 2.0h | ⏳ |
| 2 | 03 Baselines | 1.5h | ⏳ |
| 3 | 04 CatBoost+LightGBM | 3.0h | ⏳ |
| 4 | 05 Threshold Analysis | 2.0h | ⏳ |
| 5 | 06 Calibration | 1.5h | ⏳ |
| 6 | 07 Advanced Variants | 3.0h | ⏳ |
| 7 | 08 Ensemble | 2.5h | ⏳ |
| 8 | 09 Final Eval | 1.0h | ⏳ |
| **Total** | | **16.5h** | |

---

## CRITERIOS DE ÉXITO

✅ **Umbral Bajo**: threshold >= 0.60 para señales (up/down)
✅ **Precisión Alta**: precision >= 0.85 en señales
✅ **Cobertura**: coverage >= 25% (no muy pocas señales)
✅ **Estabilidad**: metrics std < 0.05 entre folds
✅ **Reproducibilidad**: todo versionado y documentado

---

**Próximo paso**: Ejecutar Notebook 02 - Feature Engineering
