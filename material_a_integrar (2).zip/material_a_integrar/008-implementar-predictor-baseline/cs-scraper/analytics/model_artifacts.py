from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np
import pandas as pd
from sklearn.metrics import balanced_accuracy_score, classification_report


DEFAULT_THRESHOLDS = (0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80)
DEFAULT_ACTION_LABELS = ("down", "hold", "up")
IDENTITY_COLUMNS = [
    "variant_id",
    "item_key",
    "w",
    "st",
    "day",
    "price_cents",
    "future_price_cents",
    "future_return",
    "direction",
]
ARTIFACT_SUBDIRS = ("models", "results", "residuals")


def ensure_artifacts_dir(root: str | Path) -> Path:
    artifacts_dir = Path(root) / "notebooks" / "modelos" / "artifacts"
    artifacts_dir.mkdir(parents=True, exist_ok=True)
    for subdir in ARTIFACT_SUBDIRS:
        (artifacts_dir / subdir).mkdir(parents=True, exist_ok=True)
    return artifacts_dir


def artifact_paths(root_or_artifacts_dir: str | Path) -> dict[str, Path]:
    base = Path(root_or_artifacts_dir)
    if not base.name == "artifacts":
        base = ensure_artifacts_dir(base)
    else:
        base.mkdir(parents=True, exist_ok=True)
        for subdir in ARTIFACT_SUBDIRS:
            (base / subdir).mkdir(parents=True, exist_ok=True)
    return {
        "base": base,
        "models": base / "models",
        "results": base / "results",
        "residuals": base / "residuals",
    }


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, Mapping):
        return {str(key): _json_safe(inner) for key, inner in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(inner) for inner in value]
    return value


def classification_summary(
    *,
    model_name: str,
    y_true: Iterable[object],
    y_pred: Iterable[object],
    class_order: list[str],
) -> dict[str, object]:
    true = pd.Series(y_true).astype(str)
    pred = pd.Series(y_pred).astype(str)
    report = classification_report(
        true,
        pred,
        labels=class_order,
        zero_division=0,
        output_dict=True,
    )
    row: dict[str, object] = {
        "model": model_name,
        "balanced_accuracy": balanced_accuracy_score(true, pred),
    }
    for label in class_order:
        row[f"precision_{label}"] = report[label]["precision"]
        row[f"recall_{label}"] = report[label]["recall"]
        row[f"f1_{label}"] = report[label]["f1-score"]
        row[f"support_{label}"] = int(report[label]["support"])
    return row


def probability_frame(
    probabilities: np.ndarray,
    *,
    probability_columns: Iterable[object],
    class_order: list[str],
    index: pd.Index | None = None,
) -> pd.DataFrame:
    frame = pd.DataFrame(
        probabilities,
        columns=[str(column) for column in probability_columns],
        index=index,
    )
    for label in class_order:
        if label not in frame.columns:
            frame[label] = 0.0
    return frame[class_order].astype("float32")


def precision_at_thresholds(
    *,
    y_true: Iterable[object],
    probabilities: pd.DataFrame,
    labels: Iterable[str] = DEFAULT_ACTION_LABELS,
    thresholds: Iterable[float] = DEFAULT_THRESHOLDS,
) -> pd.DataFrame:
    true = pd.Series(y_true, index=probabilities.index).astype(str)
    rows: list[dict[str, object]] = []
    total = len(true)

    for label in labels:
        if label not in probabilities.columns:
            continue
        label_probs = probabilities[label]
        for threshold in thresholds:
            selected = label_probs >= float(threshold)
            selected_count = int(selected.sum())
            if selected_count:
                precision = float((true[selected] == label).mean())
                avg_probability = float(label_probs[selected].mean())
            else:
                precision = 0.0
                avg_probability = 0.0
            rows.append(
                {
                    "label": label,
                    "threshold": float(threshold),
                    "selected": selected_count,
                    "coverage": selected_count / total if total else 0.0,
                    "precision": precision,
                    "avg_probability": avg_probability,
                }
            )

    return pd.DataFrame(rows)


def save_classifier_outputs(
    *,
    artifacts_dir: str | Path,
    prefix: str,
    model_name: str,
    y_true: Iterable[object],
    y_pred: Iterable[object],
    probabilities: np.ndarray,
    probability_columns: Iterable[object],
    class_order: list[str],
    test_frame: pd.DataFrame,
    config: Mapping[str, object],
    expected_return_by_class: Mapping[str, float] | None = None,
) -> dict[str, Path]:
    paths = artifact_paths(artifacts_dir)

    true = pd.Series(y_true, index=test_frame.index).astype(str)
    pred = pd.Series(y_pred, index=test_frame.index).astype(str)
    proba = probability_frame(
        probabilities,
        probability_columns=probability_columns,
        class_order=class_order,
        index=test_frame.index,
    )
    summary = pd.DataFrame(
        [
            classification_summary(
                model_name=model_name,
                y_true=true,
                y_pred=pred,
                class_order=class_order,
            )
        ]
    ).round(4)
    thresholds = precision_at_thresholds(y_true=true, probabilities=proba).round(4)

    prediction_columns = [
        column for column in IDENTITY_COLUMNS if column in test_frame.columns
    ]
    predictions = test_frame[prediction_columns].copy()
    for column in predictions.select_dtypes(include=["category"]).columns:
        predictions[column] = predictions[column].astype(str)
    predictions["y_true"] = true.to_numpy()
    predictions["y_pred"] = pred.to_numpy()
    for label in class_order:
        predictions[f"prob_{label}"] = proba[label].to_numpy()
    if expected_return_by_class:
        expected_return = np.zeros(len(predictions), dtype="float32")
        for label in class_order:
            expected_return += (
                proba[label].to_numpy(dtype="float32")
                * float(expected_return_by_class.get(label, 0.0))
            )
        predictions["predicted_return"] = expected_return
        predictions["predicted_return_pct"] = expected_return * 100.0
        if "future_return" in predictions.columns:
            predictions["return_residual"] = (
                predictions["future_return"].astype("float32") - expected_return
            )
            predictions["return_residual_pct"] = predictions["return_residual"] * 100.0

    summary_path = paths["results"] / f"{prefix}_direction_metrics.csv"
    json_path = paths["results"] / f"{prefix}_direction_metrics.json"
    threshold_path = paths["results"] / f"{prefix}_threshold_precision.csv"
    predictions_path = paths["residuals"] / f"{prefix}_test_predictions.csv.gz"

    summary.to_csv(summary_path, index=False)
    thresholds.to_csv(threshold_path, index=False)
    predictions.to_csv(predictions_path, index=False, compression="gzip")

    payload = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "config": _json_safe(dict(config)),
        "expected_return_by_class": _json_safe(dict(expected_return_by_class or {})),
        "summary": _json_safe(summary.to_dict(orient="records")[0]),
        "thresholds": _json_safe(thresholds.to_dict(orient="records")),
        "artifacts": {
            "summary_csv": str(summary_path),
            "metrics_json": str(json_path),
            "threshold_precision_csv": str(threshold_path),
            "test_predictions_csv_gz": str(predictions_path),
        },
    }
    json_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    return {
        "summary": summary_path,
        "json": json_path,
        "thresholds": threshold_path,
        "predictions": predictions_path,
    }
