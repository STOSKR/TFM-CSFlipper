from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class DirectionSignal:
    direction: str
    confidence: float
    expected_return_pct: float
    reason: str


def _pct_change(current: float, previous: float) -> float:
    if previous == 0:
        return 0.0
    return ((current - previous) / previous) * 100.0


def estimate_direction_signal(
    daily_frame: pd.DataFrame,
    *,
    horizon_days: int,
    hold_band_pct: float,
) -> DirectionSignal | None:
    if daily_frame.empty or len(daily_frame) < 8:
        return None

    work = daily_frame.sort_values("day_utc").reset_index(drop=True)
    price = work["price_smooth_usd"].astype("float64")
    current = float(price.iloc[-1])
    lookback = min(max(int(horizon_days), 7), len(work) - 1)
    previous = float(price.iloc[-1 - lookback])
    momentum_pct = _pct_change(current, previous)

    recent = price.tail(min(30, len(price)))
    volatility_pct = float(recent.pct_change().dropna().std() * 100.0)
    expected_return_pct = momentum_pct * 0.55
    confidence = min(0.85, 0.45 + abs(expected_return_pct) / 25.0)

    if expected_return_pct > hold_band_pct:
        direction = "up"
        reason = "Momentum positivo frente al tramo reciente."
    elif expected_return_pct < -hold_band_pct:
        direction = "down"
        reason = "Momentum negativo frente al tramo reciente."
    else:
        direction = "hold"
        reason = "Movimiento esperado dentro de la banda de estabilidad."

    if volatility_pct > 8.0:
        confidence = max(0.35, confidence - 0.12)
        reason = f"{reason} Volatilidad reciente alta."

    return DirectionSignal(
        direction=direction,
        confidence=round(confidence, 3),
        expected_return_pct=round(expected_return_pct, 2),
        reason=reason,
    )
