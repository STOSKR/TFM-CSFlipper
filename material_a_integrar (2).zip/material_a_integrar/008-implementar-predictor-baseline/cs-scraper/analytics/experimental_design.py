from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

DEFAULT_FOLDS = (
    ("fold_1", 0.00, 0.50, 0.65, 0.80),
    ("fold_2", 0.00, 0.65, 0.80, 0.95),
    ("fold_3", 0.00, 0.80, 0.95, 1.00),
)


def _json_safe(value: Any) -> Any:
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, pd.Timestamp):
        return value.isoformat()
    if isinstance(value, dict):
        return {str(key): _json_safe(inner) for key, inner in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(inner) for inner in value]
    return value


def _day_at(days: np.ndarray, pct: float) -> int:
    index = min(max(int(len(days) * pct), 0), len(days) - 1)
    return int(days[index])


def _window_summary(
    frame: pd.DataFrame,
    *,
    start_day: int,
    end_day: int,
    label_column: str,
) -> dict[str, Any]:
    part = frame[(frame["day"] >= start_day) & (frame["day"] <= end_day)]
    dates = pd.to_datetime(part["day"], unit="D", origin="unix")
    return {
        "start_day": int(start_day),
        "end_day": int(end_day),
        "start_date": dates.min().date().isoformat() if not part.empty else None,
        "end_date": dates.max().date().isoformat() if not part.empty else None,
        "rows": int(len(part)),
        "variants": int(part["variant_id"].nunique()) if "variant_id" in part else 0,
        "class_distribution": part[label_column].value_counts().to_dict(),
    }


def build_temporal_design(
    frame: pd.DataFrame,
    *,
    train_ratio: float = 0.70,
    val_ratio: float = 0.15,
    embargo_days: int = 7,
    label_column: str = "direction",
) -> dict[str, Any]:
    if frame.empty:
        raise ValueError("Cannot build temporal design from an empty frame")

    days = np.sort(frame["day"].unique())
    train_end = _day_at(days, train_ratio)
    val_end = _day_at(days, train_ratio + val_ratio)
    main = {
        "train": _window_summary(
            frame, start_day=int(days[0]), end_day=train_end, label_column=label_column
        ),
        "validation": _window_summary(
            frame,
            start_day=train_end + embargo_days + 1,
            end_day=val_end,
            label_column=label_column,
        ),
        "test": _window_summary(
            frame,
            start_day=val_end + embargo_days + 1,
            end_day=int(days[-1]),
            label_column=label_column,
        ),
    }

    folds = []
    for name, train_start, train_stop, val_stop, test_stop in DEFAULT_FOLDS:
        fold_train_end = _day_at(days, train_stop)
        fold_val_end = _day_at(days, val_stop)
        fold_test_end = _day_at(days, test_stop)
        folds.append(
            {
                "name": name,
                "train": _window_summary(
                    frame,
                    start_day=_day_at(days, train_start),
                    end_day=fold_train_end,
                    label_column=label_column,
                ),
                "validation": _window_summary(
                    frame,
                    start_day=fold_train_end + embargo_days + 1,
                    end_day=fold_val_end,
                    label_column=label_column,
                ),
                "test": _window_summary(
                    frame,
                    start_day=fold_val_end + embargo_days + 1,
                    end_day=fold_test_end,
                    label_column=label_column,
                ),
            }
        )

    return {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "parameters": {
            "train_ratio": train_ratio,
            "val_ratio": val_ratio,
            "test_ratio": 1.0 - train_ratio - val_ratio,
            "embargo_days": int(embargo_days),
            "label_column": label_column,
        },
        "main_split": main,
        "walk_forward_folds": folds,
    }


def export_temporal_design(design: dict[str, Any], output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(_json_safe(design), indent=2), encoding="utf-8")
    return path
