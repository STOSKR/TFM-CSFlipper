from __future__ import annotations

from datetime import date
from typing import Any

from ._parsing import WEAPON_BUCKETS, WEAR_ORDER


def empty_catalog() -> dict[str, Any]:
    return {
        "v": 1,
        "meta": {"updated": date.today().isoformat(), "total_items": 0},
        "weapons": {bucket: {} for bucket in WEAPON_BUCKETS},
        "knives": {},
        "gloves": {},
        "agents": {},
        "cases": {},
        "stickers": {},
    }


def add_entry(catalog: dict[str, Any], entry: dict[str, Any]) -> None:
    group = entry["group"]

    if group == "weapons":
        bucket = entry["bucket"] or "rifle"
        bucket_map = catalog["weapons"].setdefault(bucket, {})
        weapon_obj = bucket_map.setdefault(
            entry["weapon_key"], {"n": entry["weapon_name"], "skins": {}}
        )
    else:
        section = catalog[group]
        weapon_obj = section.setdefault(
            entry["weapon_key"], {"n": entry["weapon_name"], "skins": {}}
        )

    skin_obj = weapon_obj["skins"].setdefault(
        entry["skin_key"], {"col": entry["col"], "w": []}
    )

    rarity = entry.get("r")
    if isinstance(rarity, str) and rarity.strip() and "r" not in skin_obj:
        skin_obj["r"] = rarity.strip()

    skin_name = entry.get("skin_name")
    if skin_name and "n" not in skin_obj:
        skin_obj["n"] = str(skin_name)

    wear = entry.get("wear")
    if wear and wear not in skin_obj["w"]:
        skin_obj["w"].append(wear)
        skin_obj["w"].sort(
            key=lambda value: WEAR_ORDER.index(value) if value in WEAR_ORDER else 999
        )

    if entry.get("st"):
        skin_obj["st"] = True


def count_items(catalog: dict[str, Any]) -> int:
    total = 0
    for weapons in catalog.get("weapons", {}).values():
        for weapon_obj in weapons.values():
            total += len(weapon_obj.get("skins", {}))

    for section_name in ("knives", "gloves", "agents", "cases", "stickers"):
        for weapon_obj in catalog.get(section_name, {}).values():
            total += len(weapon_obj.get("skins", {}))

    return total


def validate_catalog_structure(catalog: dict[str, Any]) -> list[str]:
    errors: list[str] = []

    for key in (
        "v",
        "meta",
        "weapons",
        "knives",
        "gloves",
        "agents",
        "cases",
        "stickers",
    ):
        if key not in catalog:
            errors.append(f"missing key: {key}")

    for bucket in WEAPON_BUCKETS:
        if bucket not in catalog.get("weapons", {}):
            errors.append(f"missing weapons bucket: {bucket}")

    for bucket_data in catalog.get("weapons", {}).values():
        for weapon_obj in bucket_data.values():
            if "n" not in weapon_obj or "skins" not in weapon_obj:
                errors.append("weapon object missing n or skins")
                continue
            for skin_obj in weapon_obj["skins"].values():
                wears = skin_obj.get("w", [])
                if not isinstance(wears, list) or any(
                    wear not in WEAR_ORDER for wear in wears
                ):
                    errors.append("invalid wear list")
                rarity = skin_obj.get("r")
                if rarity is not None and (
                    not isinstance(rarity, str) or not rarity.strip()
                ):
                    errors.append("invalid rarity field")
                if "st" in skin_obj and skin_obj["st"] is not True:
                    errors.append("st field must be true when present")

    return errors


def iter_catalog_items(catalog: dict[str, Any]):
    for category, weapons in catalog.get("weapons", {}).items():
        for weapon_key, weapon_obj in weapons.items():
            for skin_key, skin_obj in weapon_obj.get("skins", {}).items():
                item_key = f"{category}_{weapon_key}_{skin_key}"
                yield item_key, {
                    "category": category,
                    "weapon_key": weapon_key,
                    "weapon_name": weapon_obj.get("n", weapon_key),
                    "skin_key": skin_key,
                    "skin_data": skin_obj,
                }
