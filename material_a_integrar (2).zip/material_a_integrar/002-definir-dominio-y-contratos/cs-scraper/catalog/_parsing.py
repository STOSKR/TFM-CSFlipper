from __future__ import annotations

import re
from typing import Any, Optional

WEAR_TO_ABBR = {
    "factory new": "FN",
    "minimal wear": "MW",
    "field-tested": "FT",
    "well-worn": "WW",
    "battle-scarred": "BS",
    "fn": "FN",
    "mw": "MW",
    "ft": "FT",
    "ww": "WW",
    "bs": "BS",
}

WEAR_ORDER = ["FN", "MW", "FT", "WW", "BS"]
WEAPON_BUCKETS = ["rifle", "sniper", "smg", "pistol", "shotgun", "heavy"]
DEFAULT_CATEGORIES = ["rifle", "sniper", "smg", "pistol", "shotgun", "heavy"]

WEAPON_BUCKET_MAP = {
    "ak-47": "rifle",
    "m4a4": "rifle",
    "m4a1-s": "rifle",
    "aug": "rifle",
    "famas": "rifle",
    "galil ar": "rifle",
    "sg 553": "rifle",
    "awp": "sniper",
    "ssg 08": "sniper",
    "scar-20": "sniper",
    "g3sg1": "sniper",
    "mac-10": "smg",
    "mp5-sd": "smg",
    "mp7": "smg",
    "mp9": "smg",
    "p90": "smg",
    "pp-bizon": "smg",
    "ump-45": "smg",
    "desert eagle": "pistol",
    "usp-s": "pistol",
    "glock-18": "pistol",
    "p250": "pistol",
    "five-seven": "pistol",
    "cz75-auto": "pistol",
    "tec-9": "pistol",
    "dual berettas": "pistol",
    "xm1014": "shotgun",
    "sawed-off": "shotgun",
    "mag-7": "shotgun",
    "nova": "shotgun",
    "m249": "heavy",
    "negev": "heavy",
}


def normalize_key(value: str) -> str:
    cleaned = re.sub(r"[^a-z0-9]+", "_", value.lower()).strip("_")
    return cleaned


def wear_to_abbr(wear: Optional[str]) -> Optional[str]:
    if not wear:
        return None
    return WEAR_TO_ABBR.get(wear.strip().lower())


def strip_stattrak(name: str) -> tuple[str, bool]:
    value = name.strip()
    for prefix in ("StatTrak(TM) ", "StatTrak\u2122 ", "Stattrak "):
        if value.lower().startswith(prefix.lower()):
            return value[len(prefix) :], True
        starred_prefix = f"\u2605 {prefix}"
        if value.lower().startswith(starred_prefix.lower()):
            remainder = value[len(starred_prefix) :]
            return f"\u2605 {remainder}", True
    return value, False


def strip_souvenir(name: str) -> tuple[str, bool]:
    value = name.strip()
    prefix = "Souvenir "
    if value.lower().startswith(prefix.lower()):
        return value[len(prefix) :], True
    starred_prefix = f"\u2605 {prefix}"
    if value.lower().startswith(starred_prefix.lower()):
        remainder = value[len(starred_prefix) :]
        return f"\u2605 {remainder}", True
    return value, False


def split_market_name(name: str) -> tuple[str, str, Optional[str], bool]:
    base, stattrak = strip_stattrak(name)
    base, _ = strip_souvenir(base)
    match = re.match(r"^(.+?)\s*\|\s*(.+?)(?:\s*\(([^)]+)\))?$", base.strip())
    if not match:
        plain = base.strip()
        return plain, plain, None, stattrak

    weapon_name = match.group(1).strip()
    skin_name = match.group(2).strip()
    wear = match.group(3).strip() if match.group(3) else None
    return weapon_name, skin_name, wear, stattrak


def _normalize_rarity(raw: Any) -> Optional[str]:
    if raw is None or isinstance(raw, bool):
        return None

    if isinstance(raw, dict):
        for key in ("name", "key", "value"):
            resolved = _normalize_rarity(raw.get(key))
            if resolved:
                return resolved
        return None

    if isinstance(raw, int):
        return f"rarity_{raw}"

    text = str(raw).strip()
    if not text:
        return None

    if text.isdigit():
        return f"rarity_{int(text)}"

    return normalize_key(text)


def _extract_listing_rarity(
    item: dict[str, Any], listing: dict[str, Any]
) -> Optional[str]:
    for candidate in (
        item.get("rarity_name"),
        item.get("rarity"),
        item.get("grade_name"),
        item.get("grade"),
        listing.get("rarity_name"),
        listing.get("rarity"),
        listing.get("grade_name"),
        listing.get("grade"),
    ):
        resolved = _normalize_rarity(candidate)
        if resolved:
            return resolved
    return None


def classify_group(
    weapon_name: str, item_type: Optional[str] = None
) -> tuple[str, Optional[str]]:
    lowered_type = str(item_type or "").lower().strip()
    if lowered_type:
        if "sticker" in lowered_type or "patch" in lowered_type:
            return "stickers", None
        if "agent" in lowered_type:
            return "agents", None
        if any(
            token in lowered_type
            for token in ("container", "case", "capsule", "crate", "package")
        ):
            return "cases", None
        if "glove" in lowered_type:
            return "gloves", None
        if "knife" in lowered_type:
            return "knives", None

    lowered = weapon_name.lower()
    if "glove" in lowered:
        return "gloves", None
    if "agent" in lowered:
        return "agents", None
    if "sticker" in lowered:
        return "stickers", None
    if "case" in lowered or "capsule" in lowered:
        return "cases", None
    if weapon_name.startswith("\u2605") or "knife" in lowered or "daggers" in lowered:
        return "knives", None

    bucket = WEAPON_BUCKET_MAP.get(lowered)
    if bucket:
        return "weapons", bucket
    return "weapons", "rifle"


def parse_listing_entry(
    listing: dict[str, Any], forced_bucket: Optional[str] = None
) -> Optional[dict[str, Any]]:
    item = (listing.get("contract") or {}).get("item") or listing.get("item") or listing
    market_name = (
        item.get("market_hash_name")
        or item.get("name")
        or listing.get("market_hash_name")
    )
    if not market_name:
        return None

    weapon_name, skin_name, wear, stattrak = split_market_name(str(market_name))
    wear_abbr = wear_to_abbr(wear)
    item_type = item.get("type_name") or item.get("type") or listing.get("type")

    group, bucket = classify_group(weapon_name, item_type=str(item_type or ""))
    if forced_bucket and group == "weapons":
        bucket = forced_bucket

    collection = (
        item.get("collection")
        or item.get("collection_name")
        or listing.get("collection")
    )
    if isinstance(collection, dict):
        collection = collection.get("name") or collection.get("short")

    rarity = _extract_listing_rarity(item, listing)

    return {
        "group": group,
        "bucket": bucket,
        "weapon_name": weapon_name,
        "weapon_key": normalize_key(weapon_name.replace("\u2605", "")),
        "skin_key": normalize_key(skin_name),
        "wear": wear_abbr,
        "st": stattrak,
        "col": normalize_key(str(collection or "unknown")),
        "r": rarity,
    }
