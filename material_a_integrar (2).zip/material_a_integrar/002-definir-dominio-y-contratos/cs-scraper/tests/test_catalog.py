from __future__ import annotations

import json
from pathlib import Path

from catalog import builder
from catalog._parsing import parse_listing_entry


PARSED_ENTRY = {
    "group": "weapons",
    "bucket": "rifle",
    "weapon_name": "AK-47",
    "weapon_key": "ak_47",
    "skin_key": "redline",
    "wear": "FT",
    "st": True,
    "col": "phoenix",
    "r": "classified",
}


def test_build_full_catalog_one_item(monkeypatch) -> None:
    monkeypatch.setattr(
        builder, "scrape_category", lambda *args, **kwargs: [PARSED_ENTRY]
    )

    catalog = builder.build_full_catalog(session={}, categories=["rifle"], max_items=1)

    skin = catalog["weapons"]["rifle"]["ak_47"]["skins"]["redline"]
    assert skin["col"] == "phoenix"
    assert skin["r"] == "classified"
    assert skin["w"] == ["FT"]
    assert skin["st"] is True


def test_run_catalog_validation_workflow(monkeypatch, tmp_path: Path) -> None:
    def fake_build(*_args, **kwargs):
        limit = kwargs.get("max_items")
        total = 111 if limit is None else int(limit)
        return {
            "v": 1,
            "meta": {"updated": "2026-04-07", "total_items": total},
            "weapons": {
                bucket: {}
                for bucket in ["rifle", "sniper", "smg", "pistol", "shotgun", "heavy"]
            },
            "knives": {},
            "gloves": {},
            "agents": {},
            "cases": {},
            "stickers": {},
        }

    monkeypatch.setattr(builder, "build_full_catalog", fake_build)
    monkeypatch.setattr(
        builder, "save_catalog", lambda *_args, **_kwargs: Path("saved.json")
    )

    report = builder.run_catalog_validation_workflow(
        {}, output_path=tmp_path / "catalog.json"
    )

    assert report["stage_1_single"] == 1
    assert report["stage_2_batch_50"] == 50
    assert report["stage_3_full"] == 111


def test_parse_listing_entry_uses_item_type_for_cases() -> None:
    listing = {
        "item": {
            "market_hash_name": "EMS Katowice 2014 Challengers",
            "type": "container",
            "type_name": "Container",
        }
    }

    entry = parse_listing_entry(listing)

    assert entry is not None
    assert entry["group"] == "cases"
    assert entry["skin_key"] == "ems_katowice_2014_challengers"


def test_parse_listing_entry_strips_souvenir_prefix() -> None:
    listing = {
        "item": {
            "market_hash_name": "Souvenir AWP | Dragon Lore (Field-Tested)",
            "type": "skin",
            "type_name": "Skin",
        }
    }

    entry = parse_listing_entry(listing)

    assert entry is not None
    assert entry["weapon_name"] == "AWP"
    assert entry["bucket"] == "sniper"
    assert entry["wear"] == "FT"


def test_parse_listing_entry_detects_stattrak_with_star_prefix() -> None:
    listing = {
        "item": {
            "market_hash_name": "★ StatTrak™ Shadow Daggers | Night (Factory New)",
            "type": "skin",
            "type_name": "Skin",
        }
    }

    entry = parse_listing_entry(listing)

    assert entry is not None
    assert entry["st"] is True
    assert entry["group"] == "knives"


def test_parse_listing_entry_extracts_rarity_name() -> None:
    listing = {
        "item": {
            "market_hash_name": "AK-47 | Redline (Field-Tested)",
            "type": "skin",
            "type_name": "Skin",
            "rarity_name": "Classified",
        }
    }

    entry = parse_listing_entry(listing)

    assert entry is not None
    assert entry["r"] == "classified"


def test_build_full_catalog_target_weapon_from_schema_payload() -> None:
    schema_payload = {
        "cookies": [],
        "storage": {
            "session": {
                "ITEM_SCHEMA_V2": json.dumps(
                    {
                        "schema": {
                            "rarities": [
                                {"key": "restricted", "name": "Restricted", "value": 4},
                                {"key": "classified", "name": "Classified", "value": 5},
                            ],
                            "collections": [
                                {
                                    "key": "set_bravo_i",
                                    "name": "The Bravo Collection",
                                }
                            ],
                            "weapons": {
                                "7": {
                                    "name": "AK-47",
                                    "type": "Weapons",
                                    "paints": {
                                        "180": {
                                            "name": "Fire Serpent",
                                            "min": 0.06,
                                            "max": 0.76,
                                            "rarity": 5,
                                            "collections": ["set_bravo_i"],
                                            "stattrak": True,
                                        },
                                        "302": {
                                            "name": "Vulcan",
                                            "min": 0.00,
                                            "max": 0.90,
                                            "rarity": 4,
                                            "collections": ["set_unknown"],
                                        },
                                    },
                                }
                            },
                        }
                    }
                )
            }
        },
    }

    catalog = builder.build_full_catalog(
        schema_payload,
        target_weapon="AK-47",
    )

    assert catalog["meta"]["total_items"] == 2
    skins = catalog["weapons"]["rifle"]["ak_47"]["skins"]
    assert sorted(skins.keys()) == ["fire_serpent", "vulcan"]
    assert skins["fire_serpent"]["st"] is True
    assert skins["fire_serpent"]["w"] == ["FN", "MW", "FT", "WW", "BS"]
    assert skins["fire_serpent"]["col"] == "the_bravo_collection"
    assert skins["fire_serpent"]["r"] == "classified"
    assert skins["vulcan"]["r"] == "restricted"


def test_build_full_catalog_schema_mode_includes_non_weapon_sections() -> None:
    schema_payload = {
        "cookies": [],
        "storage": {
            "session": {
                "ITEM_SCHEMA_V2": json.dumps(
                    {
                        "schema": {
                            "collections": [
                                {
                                    "key": "set_bravo_i",
                                    "name": "The Bravo Collection",
                                }
                            ],
                            "weapons": {
                                "7": {
                                    "name": "AK-47",
                                    "type": "Weapons",
                                    "paints": {
                                        "180": {
                                            "name": "Fire Serpent",
                                            "min": 0.06,
                                            "max": 0.76,
                                            "collections": ["set_bravo_i"],
                                            "stattrak": True,
                                        }
                                    },
                                },
                                "500": {
                                    "name": "Bayonet",
                                    "type": "Knives",
                                    "paints": {
                                        "38": {
                                            "name": "Fade",
                                            "min": 0.00,
                                            "max": 0.08,
                                            "collections": ["set_bravo_i"],
                                        }
                                    },
                                },
                            },
                            "containers": {
                                "4001": {"market_hash_name": "CS:GO Weapon Case"}
                            },
                            "agents": {
                                "4613": {"market_hash_name": "Test Agent | Elite"}
                            },
                            "stickers": {
                                "1": {"market_hash_name": "Sticker | Shooter"}
                            },
                        }
                    }
                )
            }
        },
    }

    catalog = builder.build_full_catalog(schema_payload)

    assert catalog["meta"]["total_items"] == 5
    assert "ak_47" in catalog["weapons"]["rifle"]
    assert "bayonet" in catalog["knives"]
    assert "cs_go_weapon_case" in catalog["cases"]
    assert "test_agent_elite" in catalog["agents"]
    assert "sticker_shooter" in catalog["stickers"]


def test_build_full_catalog_schema_mode_maps_unmapped_weapons_to_pistol() -> None:
    schema_payload = {
        "cookies": [],
        "storage": {
            "session": {
                "ITEM_SCHEMA_V2": json.dumps(
                    {
                        "schema": {
                            "collections": [],
                            "weapons": {
                                "32": {
                                    "name": "P2000",
                                    "type": "Weapons",
                                    "paints": {
                                        "1": {
                                            "name": "Handgun",
                                            "min": 0.00,
                                            "max": 1.00,
                                        }
                                    },
                                }
                            },
                        }
                    }
                )
            }
        },
    }

    catalog = builder.build_full_catalog(schema_payload)

    assert "p2000" in catalog["weapons"]["pistol"]
