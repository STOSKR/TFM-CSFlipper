"""Domain models with Pydantic validation."""

from datetime import datetime, timezone
from typing import Optional

from pydantic import BaseModel, Field, HttpUrl


class ScrapedItem(BaseModel):
    """Complete scraped item with all calculations."""

    item_name: str = Field(..., min_length=1)
    quality: Optional[str] = None
    stattrak: bool = False
    url: Optional[HttpUrl] = None
    steam_url: Optional[HttpUrl] = None
    buff_url: Optional[HttpUrl] = None
    buff_avg_price_eur: float = Field(..., gt=0)
    steam_avg_price_eur: float = Field(..., gt=0)
    buff_volume: int = Field(default=0, ge=0)
    steam_volume: int = Field(default=0, ge=0)
    profit_eur: float
    profitability_percent: float
    profitability_ratio: float
    scraped_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    source: str = "steamdt_hanging"

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            HttpUrl: lambda v: str(v),
        }
