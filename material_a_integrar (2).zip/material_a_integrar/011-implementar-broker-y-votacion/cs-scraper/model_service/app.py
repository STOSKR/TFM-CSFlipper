from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping

import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from model_service.features import arbitrage_return, build_model_features
from model_service.recommendations import build_recommendations


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_ARTIFACTS_DIR = ROOT / "notebooksV2" / "artifacts" / "scientific_v2"


app = FastAPI(title="CS2 Market Model API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


def _json_load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"), parse_constant=lambda _value: None)


def _artifacts_dir() -> Path:
    return Path(os.getenv("ARTIFACTS_DIR", str(DEFAULT_ARTIFACTS_DIR))).resolve()


def _model_path(artifacts_dir: Path, model_id: str | None = None) -> Path:
    explicit = os.getenv("MODEL_PATH")
    if explicit:
        return Path(explicit).resolve()
    if model_id:
        candidate = artifacts_dir / "models" / f"{model_id}.joblib"
        if candidate.exists():
            return candidate
    primary = artifacts_dir / "primary_model_lightgbm.joblib"
    if primary.exists():
        return primary
    raise FileNotFoundError(f"No model artifact found in {artifacts_dir}")


@lru_cache(maxsize=1)
def _metadata() -> dict[str, Any]:
    artifacts_dir = _artifacts_dir()
    metadata_path = artifacts_dir / "candidate_model_metadata.json"
    training_path = artifacts_dir / "model_training_metadata.json"
    thresholds_path = artifacts_dir / "optimal_thresholds.json"

    metadata = _json_load(metadata_path) if metadata_path.exists() else {}
    training = _json_load(training_path) if training_path.exists() else {}
    thresholds = _json_load(thresholds_path) if thresholds_path.exists() else {}
    features = metadata.get("features") or training.get("features") or []
    primary_model_id = os.getenv("MODEL_ID") or metadata.get("primary_model") or training.get("model_id")

    return {
        "artifacts_dir": artifacts_dir,
        "features": features,
        "primary_model_id": primary_model_id,
        "thresholds": thresholds,
        "metadata": metadata,
        "training": training,
    }


@lru_cache(maxsize=8)
def _load_model(model_id: str | None = None) -> Any:
    import joblib

    info = _metadata()
    return joblib.load(_model_path(info["artifacts_dir"], model_id))


def _feature_names(model: Any) -> list[str]:
    from_model = getattr(model, "feature_names_in_", None)
    if from_model is not None:
        return [str(name) for name in from_model]
    return [str(name) for name in _metadata()["features"]]


def _probabilities(model: Any, payload: Mapping[str, Any]) -> tuple[dict[str, float], dict[str, float]]:
    features = build_model_features(payload, _feature_names(model))
    frame = pd.DataFrame([features], columns=list(features))
    raw_probabilities = model.predict_proba(frame)[0]
    labels = [str(label) for label in getattr(model, "classes_", [])]
    return dict(zip(labels, map(float, raw_probabilities), strict=True)), features


def _policy_probability(action: str, payload: Mapping[str, Any]) -> tuple[Mapping[str, Any] | None, float | None]:
    policy = (_metadata()["thresholds"] or {}).get(action)
    if not policy:
        return None, None
    model_id = str(policy.get("model_id") or _metadata()["primary_model_id"] or "")
    model = _load_model(model_id or None)
    probabilities, _features = _probabilities(model, payload)
    label = str(policy.get("label") or "")
    return policy, probabilities.get(label)


def _decide(payload: Mapping[str, Any], probabilities: Mapping[str, float]) -> dict[str, Any]:
    avoid_policy, down_risk = _policy_probability("AVOID_DOWN", payload)
    buy_policy, up_confidence = _policy_probability("BUY_UP", payload)
    margin = arbitrage_return(payload)
    model_down = float(probabilities.get("down", 0.0))
    model_up = float(probabilities.get("up", 0.0))
    effective_down = max(model_down, float(down_risk or 0.0))
    directional_edge = model_up - effective_down
    expected_return = directional_edge * 0.07

    decision = "review"
    direction = max(probabilities, key=probabilities.get) if probabilities else "hold"
    confidence = float(probabilities.get(direction, 0.0))
    reason = "El modelo no supera ningun umbral operativo."
    threshold = None
    action = None

    if avoid_policy and down_risk is not None and down_risk >= float(avoid_policy.get("threshold") or 0.0):
        decision = "reject"
        direction = "down"
        confidence = float(down_risk)
        threshold = float(avoid_policy.get("threshold") or 0.0)
        action = "AVOID_DOWN"
        reason = f"Riesgo de bajada {down_risk:.1%} por encima del umbral {threshold:.1%}."
    elif (
        buy_policy
        and up_confidence is not None
        and up_confidence >= float(buy_policy.get("threshold") or 0.0)
        and margin > 0
    ):
        decision = "buy"
        direction = "up"
        confidence = float(up_confidence)
        threshold = float(buy_policy.get("threshold") or 0.0)
        action = "BUY_UP"
        reason = f"Probabilidad de subida {up_confidence:.1%} por encima del umbral {threshold:.1%}."

    steam_price = float(payload.get("steam_price_cents") or payload.get("price_cents") or 0.0)
    expected_price_cents = round(steam_price * (1.0 + expected_return)) if steam_price > 0 else 0

    return {
        "decision": decision,
        "direction": direction,
        "confidence": confidence,
        "expected_return": expected_return,
        "arbitrage_return": margin,
        "down_risk": float(down_risk if down_risk is not None else probabilities.get("down", 0.0)),
        "expected_price_cents": expected_price_cents,
        "probabilities": dict(probabilities),
        "policy_action": action,
        "policy_threshold": threshold,
        "reason": reason,
    }


@app.get("/health")
@app.get("/api/health")
def health() -> dict[str, Any]:
    info = _metadata()
    model = _load_model(str(info["primary_model_id"]) if info["primary_model_id"] else None)
    return {
        "ok": True,
        "model_id": info["primary_model_id"],
        "artifacts_dir": str(info["artifacts_dir"]),
        "features": len(_feature_names(model)),
        "classes": [str(label) for label in getattr(model, "classes_", [])],
    }


@app.post("/predict")
@app.post("/api/predict")
def predict(payload: dict[str, Any]) -> dict[str, Any]:
    try:
        info = _metadata()
        model = _load_model(str(info["primary_model_id"]) if info["primary_model_id"] else None)
        probabilities, features = _probabilities(model, payload)
        decision = _decide(payload, probabilities)
    except Exception as exc:  # pragma: no cover - converted to an API response.
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return {
        **decision,
        "model_id": info["primary_model_id"],
        "features_used": features,
    }


@app.get("/recommendations")
@app.get("/api/recommendations")
def recommendations(
    date: str,
    limit: int = 20,
    sort: str = "hybrid",
    horizon_days: int = 7,
) -> dict[str, Any]:
    try:
        info = _metadata()
        model = _load_model(str(info["primary_model_id"]) if info["primary_model_id"] else None)
        return {
            **build_recommendations(
                selected_date=date,
                limit=limit,
                sort_by=sort,
                horizon_days=horizon_days,
                model=model,
                feature_names=_feature_names(model),
            ),
            "model_id": info["primary_model_id"],
        }
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # pragma: no cover - converted to an API response.
        raise HTTPException(status_code=500, detail=str(exc)) from exc
