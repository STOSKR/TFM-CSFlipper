from __future__ import annotations

import json
from pathlib import Path

import pytest
import requests

from scraper import price_scraper


def _http_error(status_code: int) -> requests.HTTPError:
    response = requests.Response()
    response.status_code = status_code
    return requests.HTTPError(response=response)


def test_append_price_snapshot_deduplicates(tmp_path: Path) -> None:
    snapshots = [
        {"t": 100, "w": "FN", "st": 0, "p": 1200, "vol": 3},
        {"t": 101, "w": "FN", "st": 0, "p": 1300, "vol": 1},
    ]

    first = price_scraper.append_price_snapshot(
        "rifle_ak47_redline",
        snapshots,
        tmp_path,
        item_meta={"collection": "phoenix", "rarity": "classified"},
    )
    second = price_scraper.append_price_snapshot(
        "rifle_ak47_redline",
        snapshots,
        tmp_path,
        item_meta={"collection": "phoenix", "rarity": "classified"},
    )

    assert first["written"] == 2
    assert second["written"] == 0

    expected_file = tmp_path / "items" / "rifle" / "ak" / "rifle_ak47_redline.json"
    assert first["file"] == str(expected_file)

    payload = json.loads(expected_file.read_text(encoding="utf-8"))
    assert payload["item_meta"]["collection"] == "phoenix"
    assert payload["item_meta"]["rarity"] == "classified"
    variant = payload["variants"]["FN_st0"]
    assert variant["w"] == "FN"
    assert variant["st"] == 0
    assert [row["t"] for row in variant["series"]] == [100, 101]
    assert [row["vol"] for row in variant["series"]] == [3, 1]
    assert [row["ccy"] for row in variant["series"]] == ["UNK", "UNK"]
    raw = expected_file.read_text(encoding="utf-8")
    assert raw.index('"item_meta"') < raw.index('"variants"')


def test_run_full_scrape_does_not_create_new_empty_files(
    monkeypatch, tmp_path: Path
) -> None:
    catalog = {
        "weapons": {
            "rifle": {
                "ak47": {
                    "n": "AK-47",
                    "skins": {"redline": {"col": "phoenix", "w": ["FN"], "st": True}},
                }
            },
            "sniper": {},
            "smg": {},
            "pistol": {},
            "shotgun": {},
            "heavy": {},
        }
    }

    monkeypatch.setattr(
        price_scraper, "scrape_item_prices", lambda *_args, **_kwargs: []
    )

    report = price_scraper.run_full_scrape(catalog, {}, tmp_path, max_items=1)

    assert report["processed"] == 1
    assert report["empty"] == 1
    expected_file = tmp_path / "items" / "rifle" / "ak" / "rifle_ak47_redline.json"
    assert not expected_file.exists()


def test_append_price_snapshot_does_not_create_empty_file(tmp_path: Path) -> None:
    result = price_scraper.append_price_snapshot("rifle_ak47_redline", [], tmp_path)

    expected_file = tmp_path / "items" / "rifle" / "ak" / "rifle_ak47_redline.json"
    assert result["written"] == 0
    assert not expected_file.exists()


def test_iterative_workflow_stages(monkeypatch) -> None:
    catalog = {
        "weapons": {
            "rifle": {
                "ak47": {
                    "n": "AK-47",
                    "skins": {"redline": {"col": "phoenix", "w": ["FN"], "st": True}},
                }
            },
            "sniper": {},
            "smg": {},
            "pistol": {},
            "shotgun": {},
            "heavy": {},
        }
    }

    monkeypatch.setattr(
        price_scraper,
        "scrape_item_prices",
        lambda *_args, **_kwargs: [{"t": 200, "w": "FN", "st": 0, "p": 2000, "vol": 2}],
    )
    monkeypatch.setattr(
        price_scraper,
        "append_price_snapshot",
        lambda *_args, **_kwargs: {"written": 1, "file": "x", "total_input": 1},
    )
    monkeypatch.setattr(
        price_scraper,
        "run_full_scrape",
        lambda *_args, **kwargs: {
            "processed": kwargs.get("max_items") or 99,
            "written": 1,
            "errors": [],
        },
    )

    report = price_scraper.run_iterative_validation_workflow(catalog, {}, "data/prices")

    assert report["stage_1_single"]["written"] == 1
    assert report["stage_2_batch_50"]["processed"] == 50
    assert report["stage_3_full"]["processed"] == 99


def test_iterative_workflow_stage1_requires_non_empty_snapshots(monkeypatch) -> None:
    catalog = {
        "weapons": {
            "rifle": {
                "ak47": {
                    "n": "AK-47",
                    "skins": {"redline": {"col": "phoenix", "w": ["FN"], "st": True}},
                }
            },
            "sniper": {},
            "smg": {},
            "pistol": {},
            "shotgun": {},
            "heavy": {},
        }
    }

    monkeypatch.setattr(
        price_scraper, "scrape_item_prices", lambda *_args, **_kwargs: []
    )

    with pytest.raises(RuntimeError, match="no snapshots found"):
        price_scraper.run_iterative_validation_workflow(catalog, {}, "data/prices")


def test_scrape_item_prices_requires_steam_auth_cookie() -> None:
    skin_data = {
        "weapon_name": "AK-47",
        "skin_key": "redline",
        "skin_data": {"w": ["FN"], "st": False},
    }

    with pytest.raises(RuntimeError, match="Steam authenticated session"):
        price_scraper.scrape_item_prices(
            requests.Session(), "rifle_ak47_redline", skin_data
        )


def test_scrape_item_prices_uses_schema_skin_name(monkeypatch) -> None:
    source_session = requests.Session()

    monkeypatch.setattr(price_scraper, "build_steam_session", lambda _s: source_session)
    monkeypatch.setattr(price_scraper, "has_steam_login_cookie", lambda _s: True)

    captured: dict[str, str] = {}

    def fake_resolve(_session, **kwargs):
        captured["skin_name"] = kwargs["skin_name"]
        return ["AK-47 | Redline (Factory New)"]

    monkeypatch.setattr(price_scraper, "resolve_variant_market_names", fake_resolve)
    monkeypatch.setattr(
        price_scraper,
        "fetch_pricehistory",
        lambda *_args, **_kwargs: {"prices": [["Jan 01 2024 00:00:00", "$12.34", "5"]]},
    )

    skin_data = {
        "weapon_name": "AK-47",
        "skin_key": "redline",
        "skin_data": {"n": "Redline", "w": ["FN"], "st": False},
    }

    snapshots = price_scraper.scrape_item_prices(
        source_session,
        "rifle_ak47_redline",
        skin_data,
    )

    assert captured["skin_name"] == "Redline"
    assert snapshots == [
        {"t": 1704067200, "w": "FN", "st": 0, "p": 1234, "vol": 5, "ccy": "USD"}
    ]


def test_scrape_item_prices_falls_back_to_target_currency(monkeypatch) -> None:
    source_session = requests.Session()

    monkeypatch.setattr(price_scraper, "build_steam_session", lambda _s: source_session)
    monkeypatch.setattr(price_scraper, "has_steam_login_cookie", lambda _s: True)
    monkeypatch.setattr(
        price_scraper,
        "resolve_variant_market_names",
        lambda *_args, **_kwargs: ["AK-47 | Redline (Factory New)"],
    )
    monkeypatch.setattr(price_scraper, "STEAM_TARGET_CURRENCY_CODE", "EUR")
    monkeypatch.setattr(
        price_scraper,
        "fetch_pricehistory",
        lambda *_args, **_kwargs: {"prices": [["Jan 01 2024 00:00:00", "12.34", "5"]]},
    )

    skin_data = {
        "weapon_name": "AK-47",
        "skin_key": "redline",
        "skin_data": {"n": "Redline", "w": ["FN"], "st": False},
    }

    snapshots = price_scraper.scrape_item_prices(
        source_session,
        "rifle_ak47_redline",
        skin_data,
    )

    assert snapshots == [
        {"t": 1704067200, "w": "FN", "st": 0, "p": 1234, "vol": 5, "ccy": "EUR"}
    ]


def test_scrape_item_prices_uses_playwright_fallback_on_429(monkeypatch) -> None:
    source_session = requests.Session()

    monkeypatch.setattr(price_scraper, "build_steam_session", lambda _s: source_session)
    monkeypatch.setattr(price_scraper, "has_steam_login_cookie", lambda _s: True)
    monkeypatch.setattr(
        price_scraper,
        "resolve_variant_market_names",
        lambda *_args, **_kwargs: ["AK-47 | Redline (Factory New)"],
    )
    monkeypatch.setattr(price_scraper, "_priceoverview_fallback_enabled", lambda: False)
    monkeypatch.setattr(price_scraper, "_search_fallback_enabled", lambda: False)
    monkeypatch.setattr(price_scraper, "_playwright_fallback_enabled", lambda: True)
    monkeypatch.setattr(
        price_scraper,
        "fetch_pricehistory",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(_http_error(429)),
    )

    called_names: list[str] = []

    def fake_playwright_fetch(_session, market_hash_name, **_kwargs):
        called_names.append(market_hash_name)
        return {"prices": [["Jan 01 2024 00:00:00", "$11.00", "7"]]}

    monkeypatch.setattr(
        price_scraper,
        "fetch_pricehistory_playwright",
        fake_playwright_fetch,
    )

    skin_data = {
        "weapon_name": "AK-47",
        "skin_key": "redline",
        "skin_data": {"n": "Redline", "w": ["FN"], "st": False},
    }

    snapshots = price_scraper.scrape_item_prices(
        source_session,
        "rifle_ak47_redline",
        skin_data,
    )

    assert called_names == ["AK-47 | Redline (Factory New)"]
    assert snapshots == [
        {"t": 1704067200, "w": "FN", "st": 0, "p": 1100, "vol": 7, "ccy": "USD"}
    ]


def test_backfill_item_metadata_updates_existing_files(tmp_path: Path) -> None:
    item_key = "rifle_ak47_redline"
    price_scraper.append_price_snapshot(
        item_key,
        [{"t": 100, "w": "FN", "st": 0, "p": 1200, "vol": 3}],
        tmp_path,
    )

    catalog = {
        "weapons": {
            "rifle": {
                "ak47": {
                    "n": "AK-47",
                    "skins": {
                        "redline": {
                            "n": "Redline",
                            "col": "phoenix",
                            "r": "classified",
                            "w": ["FN"],
                            "st": True,
                        }
                    },
                }
            },
            "sniper": {},
            "smg": {},
            "pistol": {},
            "shotgun": {},
            "heavy": {},
        }
    }

    report = price_scraper.backfill_item_metadata(catalog, tmp_path)

    assert report["processed"] == 1
    assert report["updated"] == 1
    expected_file = tmp_path / "items" / "rifle" / "ak" / f"{item_key}.json"
    payload = json.loads(expected_file.read_text(encoding="utf-8"))
    assert payload["item_meta"]["collection"] == "phoenix"
    assert payload["item_meta"]["rarity"] == "classified"
