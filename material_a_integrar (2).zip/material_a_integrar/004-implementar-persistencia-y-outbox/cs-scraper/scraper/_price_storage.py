from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

T_MEANING = (
    "Unix timestamp (seconds, UTC) parsed from Steam market/pricehistory bucket labels"
)
DEFAULT_CURRENCY = "UNK"
ITEMS_DIR = "items"
LEGACY_FLAT_DIR = "legacy_flat"
ITEM_META_FIELDS = (
    "category",
    "weapon_key",
    "weapon_name",
    "skin_key",
    "skin_name",
    "collection",
    "rarity",
)


def _variant_key(wear: str, stattrak: int) -> str:
    return f"{wear.upper()}_st{int(stattrak)}"


def _category_from_item_key(item_key: str) -> str:
    parts = item_key.split("_", 1)
    category = parts[0].strip().lower() if parts else ""
    return category or "misc"


def _weapon_folder_from_item_key(item_key: str) -> str:
    parts = item_key.split("_")
    token = parts[1].strip().lower() if len(parts) > 1 else ""
    for family in ("ak", "m4", "galil"):
        if token.startswith(family):
            return family
    return token or "misc"


def build_price_file_path(item_key: str, prices_dir: str | Path) -> Path:
    root = Path(prices_dir)
    category = _category_from_item_key(item_key)
    weapon = _weapon_folder_from_item_key(item_key)
    return root / ITEMS_DIR / category / weapon / f"{item_key}.json"


def _new_payload(item_key: str) -> dict[str, Any]:
    return {
        "item_key": item_key,
        "schema_version": 1,
        "t_meaning": T_MEANING,
        "item_meta": {},
        "variants": {},
    }


def _normalize_snapshot(snapshot: dict[str, Any]) -> dict[str, Any]:
    wear = str(snapshot["w"]).upper()
    stattrak = int(snapshot["st"])
    timestamp = int(snapshot["t"])
    price = int(snapshot["p"])
    volume = int(snapshot["vol"])
    currency = str(snapshot.get("ccy") or DEFAULT_CURRENCY).strip().upper()

    if stattrak not in (0, 1):
        raise ValueError(f"Invalid stattrak value in snapshot: {stattrak}")

    return {
        "t": timestamp,
        "w": wear,
        "st": stattrak,
        "p": price,
        "vol": volume,
        "ccy": currency,
    }


def _day_utc(timestamp: int) -> str:
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).strftime("%Y-%m-%d")


def _ensure_variant(
    payload: dict[str, Any], wear: str, stattrak: int
) -> dict[str, Any]:
    key = _variant_key(wear, stattrak)
    variants = payload.setdefault("variants", {})
    variant = variants.get(key)
    if not isinstance(variant, dict):
        variant = {}
    variant["w"] = wear
    variant["st"] = int(stattrak)
    series = variant.get("series")
    if not isinstance(series, list):
        series = []
    variant["series"] = series
    variants[key] = variant
    return variant


def _latest_per_variant(payload: dict[str, Any]) -> dict[str, int]:
    latest: dict[str, int] = {}
    variants = payload.get("variants")
    if not isinstance(variants, dict):
        return latest

    for key, variant in variants.items():
        if not isinstance(variant, dict):
            continue
        series = variant.get("series")
        if not isinstance(series, list):
            continue
        timestamps = [
            int(row.get("t")) for row in series if isinstance(row, dict) and "t" in row
        ]
        if timestamps:
            latest[str(key)] = max(timestamps)
    return latest


def _ingest_rows(payload: dict[str, Any], rows: list[dict[str, Any]]) -> None:
    latest = _latest_per_variant(payload)
    ordered = sorted(rows, key=lambda value: (value["t"], value["w"], value["st"]))
    for raw in ordered:
        snapshot = _normalize_snapshot(raw)
        key = _variant_key(snapshot["w"], snapshot["st"])
        if snapshot["t"] <= latest.get(key, 0):
            continue

        variant = _ensure_variant(payload, snapshot["w"], snapshot["st"])
        variant["series"].append(
            {
                "t": snapshot["t"],
                "p": snapshot["p"],
                "vol": snapshot["vol"],
                "ccy": snapshot["ccy"],
                "day": _day_utc(snapshot["t"]),
            }
        )
        latest[key] = snapshot["t"]

    variants = payload.get("variants") or {}
    for variant in variants.values():
        if isinstance(variant, dict) and isinstance(variant.get("series"), list):
            variant["series"].sort(key=lambda value: int(value.get("t", 0)))


def _load_jsonl_rows(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as stream:
        for line in stream:
            line = line.strip()
            if not line:
                continue
            payload = json.loads(line)
            if isinstance(payload, dict):
                rows.append(payload)
    return rows


def _normalize_payload(payload: dict[str, Any], item_key: str) -> dict[str, Any]:
    if not isinstance(payload, dict):
        payload = _new_payload(item_key)
    payload.setdefault("item_key", item_key)
    payload.setdefault("schema_version", 1)
    payload.setdefault("t_meaning", T_MEANING)
    payload.setdefault("item_meta", {})
    if not isinstance(payload.get("variants"), dict):
        payload["variants"] = {}
    if "item_meta" in payload and not isinstance(payload.get("item_meta"), dict):
        payload.pop("item_meta", None)
        payload["item_meta"] = {}
    return payload


def _has_points(payload: dict[str, Any]) -> bool:
    variants = payload.get("variants")
    if not isinstance(variants, dict):
        return False

    for variant in variants.values():
        if not isinstance(variant, dict):
            continue
        series = variant.get("series")
        if isinstance(series, list) and len(series) > 0:
            return True
    return False


def file_has_price_points(path: str | Path) -> bool:
    file_path = Path(path)
    if not file_path.exists():
        return False
    try:
        with file_path.open("r", encoding="utf-8") as stream:
            payload = json.load(stream)
    except (OSError, json.JSONDecodeError):
        return False
    if not isinstance(payload, dict):
        return False
    return _has_points(payload)


def _needs_key_reorder(payload: dict[str, Any]) -> bool:
    keys = list(payload.keys())
    required_prefix = ["item_key", "schema_version", "t_meaning"]
    for index, key in enumerate(required_prefix):
        if key in keys and keys.index(key) != index:
            return True

    if "item_meta" in keys and "variants" in keys:
        return keys.index("item_meta") > keys.index("variants")
    if "variants" in keys and "item_meta" not in keys:
        return True
    return False


def _ordered_payload(payload: dict[str, Any]) -> dict[str, Any]:
    ordered: dict[str, Any] = {
        "item_key": payload.get("item_key"),
        "schema_version": payload.get("schema_version"),
        "t_meaning": payload.get("t_meaning"),
        "item_meta": (
            payload.get("item_meta")
            if isinstance(payload.get("item_meta"), dict)
            else {}
        ),
        "variants": (
            payload.get("variants") if isinstance(payload.get("variants"), dict) else {}
        ),
    }

    for key, value in payload.items():
        if key not in ordered:
            ordered[key] = value
    return ordered


def _normalize_item_meta(item_meta: dict[str, Any] | None) -> dict[str, str]:
    if not isinstance(item_meta, dict):
        return {}

    normalized: dict[str, str] = {}
    for key in ITEM_META_FIELDS:
        value = item_meta.get(key)
        if isinstance(value, str):
            cleaned = value.strip()
            if cleaned:
                normalized[key] = cleaned
    return normalized


def _merge_item_meta(payload: dict[str, Any], item_meta: dict[str, Any] | None) -> bool:
    normalized = _normalize_item_meta(item_meta)
    if not normalized:
        return False

    existing = payload.get("item_meta")
    if not isinstance(existing, dict):
        payload["item_meta"] = normalized
        return True

    changed = False
    for key, value in normalized.items():
        if existing.get(key) != value:
            existing[key] = value
            changed = True
    return changed


def _rows_from_grouped_payload(payload: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    variants = payload.get("variants")
    if not isinstance(variants, dict):
        return rows

    for key, variant in variants.items():
        if not isinstance(variant, dict):
            continue
        wear = str(variant.get("w") or "").upper()
        st_value = variant.get("st")
        try:
            stattrak = int(st_value)
        except (TypeError, ValueError):
            try:
                stattrak = int(str(key).rsplit("_st", 1)[-1])
            except (TypeError, ValueError):
                continue

        series = variant.get("series")
        if not isinstance(series, list):
            continue
        for point in series:
            if not isinstance(point, dict):
                continue
            try:
                rows.append(
                    {
                        "t": int(point["t"]),
                        "w": wear,
                        "st": stattrak,
                        "p": int(point["p"]),
                        "vol": int(point["vol"]),
                        "ccy": str(point.get("ccy") or DEFAULT_CURRENCY).upper(),
                    }
                )
            except (KeyError, TypeError, ValueError):
                continue
    return rows


def _load_payload(
    file_path: Path, item_key: str, prices_root: Path
) -> tuple[dict[str, Any], bool, list[Path]]:
    payload = _new_payload(item_key)
    migrated = False
    legacy_sources: list[Path] = []

    if file_path.exists():
        with file_path.open("r", encoding="utf-8") as stream:
            payload = _normalize_payload(json.load(stream), item_key)

    legacy_json = prices_root / f"{item_key}.json"
    if legacy_json.exists() and legacy_json != file_path:
        legacy_sources.append(legacy_json)
        with legacy_json.open("r", encoding="utf-8") as stream:
            legacy_payload = _normalize_payload(json.load(stream), item_key)
        _ingest_rows(payload, _rows_from_grouped_payload(legacy_payload))
        migrated = True

    legacy_jsonl = prices_root / f"{item_key}.jsonl"
    if legacy_jsonl.exists():
        legacy_sources.append(legacy_jsonl)
        _ingest_rows(payload, _load_jsonl_rows(legacy_jsonl))
        migrated = True

    return _normalize_payload(payload, item_key), migrated, legacy_sources


def _archive_legacy_files(prices_root: Path, legacy_sources: list[Path]) -> None:
    if not legacy_sources:
        return

    archive_dir = prices_root / LEGACY_FLAT_DIR
    archive_dir.mkdir(parents=True, exist_ok=True)

    for source in legacy_sources:
        if not source.exists():
            continue
        target = archive_dir / source.name
        counter = 1
        while target.exists():
            target = archive_dir / f"{source.stem}.{counter}{source.suffix}"
            counter += 1
        source.replace(target)


def append_price_snapshot(
    item_key: str,
    snapshots: list[dict[str, Any]],
    prices_dir: str | Path,
    item_meta: dict[str, Any] | None = None,
) -> dict[str, Any]:
    output_dir = Path(prices_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    file_path = build_price_file_path(item_key, output_dir)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    payload, migrated, legacy_sources = _load_payload(file_path, item_key, output_dir)
    item_meta_updated = _merge_item_meta(payload, item_meta)
    key_reordered = _needs_key_reorder(payload)

    latest = _latest_per_variant(payload)
    written = 0
    updated_variants: set[str] = set()

    ordered = sorted(snapshots, key=lambda value: (value["t"], value["w"], value["st"]))
    for raw in ordered:
        snapshot = _normalize_snapshot(raw)
        key = _variant_key(snapshot["w"], snapshot["st"])
        if snapshot["t"] <= latest.get(key, 0):
            continue

        variant = _ensure_variant(payload, snapshot["w"], snapshot["st"])
        variant["series"].append(
            {
                "t": snapshot["t"],
                "p": snapshot["p"],
                "vol": snapshot["vol"],
                "ccy": snapshot["ccy"],
                "day": _day_utc(snapshot["t"]),
            }
        )
        latest[key] = snapshot["t"]
        written += 1
        updated_variants.add(key)

    for key in updated_variants:
        variant = payload["variants"].get(key)
        if isinstance(variant, dict):
            series = variant.get("series")
            if isinstance(series, list):
                series.sort(key=lambda value: int(value.get("t", 0)))

    if written or migrated or item_meta_updated or key_reordered:
        with file_path.open("w", encoding="utf-8") as stream:
            json.dump(_ordered_payload(payload), stream, ensure_ascii=True, indent=2)
        _archive_legacy_files(output_dir, legacy_sources)

    return {
        "file": str(file_path),
        "written": written,
        "total_input": len(snapshots),
        "variants_updated": sorted(updated_variants),
        "item_meta_updated": item_meta_updated,
        "key_reordered": key_reordered,
    }
